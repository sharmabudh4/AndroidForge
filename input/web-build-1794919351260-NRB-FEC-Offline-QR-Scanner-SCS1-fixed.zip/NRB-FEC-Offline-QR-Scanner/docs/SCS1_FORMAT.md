# SCS1 encrypted QR format

> **Status: matches the Sharma Cycle Store HTML QR Label Maker** (`encryptProduct()` in
> `Sharma_Cycle_Store_QR_Label_Maker_Print_Fixed.html`). The app's decoder, `Scs1Codec.kt`, was corrected to read
> exactly what that generator writes. The generator and its key were not modified.

## QR text

```
SCS1.<Base64URL( version[1] || nonce[12] || ciphertext || tag[16] )>
```

| Part | Value |
|------|-------|
| Text prefix | the literal text `SCS1.` (case-sensitive, must be the very first characters). It only routes a scan to the decryptor. |
| Encoding | Base64URL alphabet (`A-Z a-z 0-9 - _`), no padding when written. The app also reads padded and standard (`+ /`) Base64. |
| Byte 0 | **version, `0x01`**. Any other value is rejected as malformed. |
| Bytes 1-12 | **nonce (IV)**, 12 random bytes, new for every QR code |
| Bytes 13-end | **ciphertext followed by the 16-byte authentication tag** (what Web Crypto `AES-GCM` returns, and what Java/Android `AES/GCM/NoPadding` expects) |
| Cipher | AES-256-GCM, 128-bit tag |
| **AAD** | **the single byte `0x01`** (generator: `additionalData: Uint8Array.of(QR_VERSION)`) |
| Key | 32 bytes shared by the generator and the phone. Never placed in a QR code. |
| Plaintext | UTF-8 JSON, see below |

Anything that does **not** start with `SCS1.` is treated as an ordinary QR code and shown unchanged.
Anything that starts with `SCS1.` is never shown as plain text: it is decrypted or it is an error.

## Plaintext

The generator encrypts:

```json
{"serial_number":"1","product_name":"Cycle Tyre 26 inch","price":"450"}
```

`price` may be a string or a number; a leading `Rs`, `Rs.`, `INR` or `₹` is ignored (the app shows `₹` itself).
The app also accepts the key names `serial` / `serial_no` / `sn`, `name` / `product`, `product_price`, and the older
text line `Serial No: 1001, Product Name: LED Bulb 9W, Price: Rs. 80` (encrypted), for compatibility.
All three fields are required and non-empty (max 200 characters each).

## Key text (what you paste into the app)

Unchanged: 64 hexadecimal characters, or 43/44 characters of Base64 / Base64URL (the generator's "Generate key"
button produces 44-character Base64). Spaces and line breaks are ignored.

## What the decoder does, in order (`Scs1Codec.decrypt`)

1. Trim, require the `SCS1.` prefix and at most 4096 characters, otherwise *Malformed*.
2. Base64-decode the rest; fewer than `1 + 12 + 16 + 1` bytes is *Malformed*.
3. Byte 0 must be `0x01`, otherwise *Malformed*.
4. Nonce = bytes 1-12; ciphertext+tag = everything after.
5. AES-256-GCM decrypt with AAD = `0x01`; an authentication failure (wrong key or any altered byte) is *WrongKeyOrCorrupt*.
6. Strict UTF-8 decode; invalid UTF-8 is *Malformed*.

## Reference code and test vectors

* `tools/scs1_encrypt.py`: Python reference encoder/decoder (same format as the HTML generator).
* `tools/make_html_vectors.js`: runs the HTML generator's own script and writes
  `app/src/test/resources/html_generated_payloads.json` (real generator output, test key).
* `tools/make_test_vectors.py`: fixed-key, fixed-nonce known-answer vectors
  (`app/src/test/resources/scs1_vectors.json`).
* A QR text made with the old, incorrect assumptions (no version byte, AAD = ASCII `SCS1`) is no longer accepted.
