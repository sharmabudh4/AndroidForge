# NRB FEC QR Scanner (offline, with SCS1 decryption)

Android app (Kotlin, CameraX + bundled ML Kit, minSdk 24). It has **no INTERNET permission**; everything
happens on the phone.

## What it does

* **Scans any QR code** (live camera or from the gallery, flashlight, same scan frame and design as before).
  An ordinary QR code is shown exactly as decoded, with a Copy button. Nothing is opened automatically.
* **First launch:** one field for your AES-256 security key (the Base64 key from the QR Generator's
  "Generate key" button, or the same key as 64 hex characters).
  The key is saved encrypted (AES-GCM with a non-exportable Android Keystore key, kept in private app
  storage, excluded from backups) and is **not asked for again**. "Skip for now" is available because
  ordinary QR codes do not need a key; add it later in Settings.
* **QR codes starting with `SCS1.`** are decrypted with the saved key (AES-256-GCM). On success the app
  shows **serial number, product name and price**. A wrong key, an altered or invalid QR, or a missing key
  shows an error, never the raw text.
* **Settings:** replace or remove the saved key, version, about.
* Removed: login, registration / user management, device authorization, digital signatures (ECDSA), the
  local database, scan history and the device/QR export screens.

Read `docs/SCS1_FORMAT.md`: **the SCS1 format now matches the Sharma Cycle Store HTML QR Label Maker exactly**
(`SCS1.` + Base64URL of `0x01 || 12-byte nonce || ciphertext || 16-byte tag`, AES-256-GCM, AAD = the single byte
`0x01`). The whole format lives in `Scs1Codec.kt`.

## Build

1. Android Studio Hedgehog (2023.1) or newer, JDK 17.
2. File > Open > this folder. The first Gradle sync needs internet to download dependencies; the finished
   app does not.
3. Run on a device (the camera is needed), or `./gradlew assembleDebug`.

**Build status: Gradle not run.** The environment this project was edited in has no Android SDK and no access
to Google Maven / Maven Central, so Gradle could not be run; the Kotlin sources and unit tests were compiled
and run with a standalone Kotlin compiler instead. See "What was and was not tested" below.

## Trying it without printing labels

Easiest: use your HTML QR Label Maker (unchanged), enter the same key in the app, and scan a label.
Or, with the Python reference encoder (produces the same format as the HTML generator):
```
pip install cryptography "qrcode[pil]"
python tools/scs1_encrypt.py --gen-key                                   # a test key (64 hex) to paste into the app
python tools/scs1_encrypt.py --key <that key> --serial 1001 --name "LED Bulb 9W" --price 80 --png label.png
```
Open `label.png` on a screen and scan it. Scanning a normal QR code (a web address, plain text) should show
its text; scanning it with the wrong key (Settings > Replace Key) should show the decryption error.

## What was and was not tested

Run here (plain JVM, Kotlin 1.9.22 compiler, JUnit 4.13.2, Gson 2.10.1; Node 22; Python `cryptography`; OpenCV):

* 51 JUnit tests on the real production classes (`Scs1Codec`, `ProductParser`, `AesKeyParser`,
  `EncryptedKeyStore`, `ScanDecoder`): decryption, wrong key, tamper detection (every byte, several bits),
  truncation, wrong prefix / version byte / AAD, key storage encryption and clearing, plain vs. SCS1 routing.
* `HtmlGeneratorPayloadTest` decrypts payloads that were **produced by running the unmodified script of
  `Sharma_Cycle_Store_QR_Label_Maker_Print_Fixed.html`** (`tools/make_html_vectors.js` regenerates
  `app/src/test/resources/html_generated_payloads.json`). Those payloads also decrypt in Python `cryptography`
  with the layout above, and QR images rendered from them were scanned with OpenCV and decrypted by `ScanDecoder`.
* The new HTML-payload tests fail against the previous `Scs1Codec.kt` and pass against the fixed one.

The tests use a **test key** (bytes 1..32). Your real store key is not in this project and was not used.
Run the tests in Android Studio with `./gradlew testDebugUnitTest`.

**Not** tested: the Gradle build / APK (no Android SDK or Maven access here), any screen on a real device or
emulator, the Android Keystore and SharedPreferences storage, CameraX / ML Kit scanning, and decryption of your
actual printed labels with your actual key.
