#!/usr/bin/env node
// Produces app/src/test/resources/html_generated_payloads.json by running the *unmodified* <script> of the
// Sharma Cycle Store QR Label Maker HTML and calling its own encryptProduct(). Nothing in the HTML is changed.
//
//   node tools/make_html_vectors.js path/to/Sharma_Cycle_Store_QR_Label_Maker_Print_Fixed.html
//
// The key below is a TEST key used only for the unit-test resource. It is NOT your real store key
// (that key is never stored in this project).
const fs = require('fs'), vm = require('vm'), path = require('path'), crypto = require('crypto');
const htmlPath = process.argv[2];
if (!htmlPath) { console.error('usage: node make_html_vectors.js <generator.html>'); process.exit(1); }
const htmlBytes = fs.readFileSync(htmlPath);
const html = htmlBytes.toString('utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (scripts.length !== 1) throw new Error('expected exactly one inline <script>, found ' + scripts.length);

const TEST_KEY_BYTES = Buffer.from(Array.from({ length: 32 }, (_, i) => i + 1));
const TEST_KEY_B64 = TEST_KEY_BYTES.toString('base64');   // what btoa() in the page's "Generate key" would give
const products = [
  { serial: '1',    name: 'Cycle Tyre 26 inch',                 price: '450' },
  { serial: '2',    name: 'LED Bulb 9W',                        price: '80' },
  { serial: '3',    name: 'Brake Cable "Premium", 2-pack',      price: '99.5' },
  { serial: 'SN-७७', name: 'साइकिल घंटी é',                     price: '1250' },
  { serial: '105',  name: 'Chain & Sprocket Set (Hero/Atlas) 18" ₹ deal', price: '0' },
];

const els = {};
const el = id => els[id] ||= { value: '', textContent: '', style: { setProperty() {} }, addEventListener() {}, children: [],
  replaceChildren() {}, classList: { add() {}, remove() {} }, setAttribute() {}, appendChild() {} };
const sb = { document: { getElementById: el, createElement: () => el('x' + Math.random()), createDocumentFragment: () => el('f') },
  localStorage: { getItem: () => '[]', setItem() {} }, crypto: globalThis.crypto, TextEncoder, btoa, atob, console,
  confirm: () => true, QRCode: undefined };
sb.window = sb;
vm.createContext(sb);
vm.runInContext(scripts[0] + '\n;globalThis.__enc = encryptProduct;', sb);
el('encKey').value = TEST_KEY_B64;

(async () => {
  const items = [];
  for (let i = 0; i < products.length; i++) {
    const p = products[i];
    items.push({ serial: p.serial, name: p.name, price: p.price, qr: await sb.__enc(p, i) });
  }
  const out = {
    _comment: 'Real payloads produced by the HTML QR Label Maker\'s own encryptProduct(). Test key only.',
    html_sha256: crypto.createHash('sha256').update(htmlBytes).digest('hex'),
    key_base64: TEST_KEY_B64,
    items,
  };
  const dest = path.join(__dirname, '..', 'app', 'src', 'test', 'resources', 'html_generated_payloads.json');
  fs.writeFileSync(dest, JSON.stringify(out, null, 2) + '\n', 'utf8');
  console.log('wrote', path.normalize(dest), items.length, 'payloads');
})().catch(e => { console.error(e); process.exit(1); });
