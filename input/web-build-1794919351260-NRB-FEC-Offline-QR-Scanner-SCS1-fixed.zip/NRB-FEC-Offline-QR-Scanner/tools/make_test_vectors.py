#!/usr/bin/env python3
"""Writes app/src/test/resources/scs1_vectors.json with fixed key/nonces, made by the independent Python encoder
(same wire format as the HTML generator: version byte 0x01, nonce, ciphertext+tag, AAD 0x01)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
import scs1_encrypt as S

key = bytes(range(1, 33))
wrong = bytes(range(200, 168, -1))
plain = {
  "json_basic": json.dumps({"serial_number": "1001", "product_name": "LED Bulb 9W", "price": "80"}, separators=(",", ":")),
  "json_decimal_price_number": '{"serial_number":"1002","product_name":"LED Bulb 12W","price":99.5}',
  "json_unicode": json.dumps({"serial_number": "SN-७७", "product_name": "साइकिल घंटी \u00e9 \"bell\", 2-pack", "price": "1,250.00"}, ensure_ascii=False, separators=(",", ":")),
  "legacy_line": "Serial No: 1003, Product Name: Cycle Tyre 26\", Price: Rs. 450",
  "legacy_line_name_with_comma": "Serial No: 1004, Product Name: Bell, steel, chrome, Price: Rs. 60",
}
vectors = []
for i, (name, p) in enumerate(plain.items()):
    nonce = bytes([i + 1] * 12)  # fixed only for this known-answer file
    vectors.append({"name": name, "nonce_hex": nonce.hex(), "plaintext": p, "qr": S.encrypt(key, p.encode("utf-8"), nonce)})
out = {"key_hex": key.hex(), "wrong_key_hex": wrong.hex(), "aad_hex": "01", "version": 1, "vectors": vectors}
path = os.path.join(os.path.dirname(__file__), "..", "app", "src", "test", "resources", "scs1_vectors.json")
json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("wrote", os.path.normpath(path), len(vectors), "vectors")
