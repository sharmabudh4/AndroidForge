package com.nrb.offlineqrscanner.security

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Decrypts "SCS1." QR codes exactly as the Sharma Cycle Store HTML QR Label Maker writes them
 * (see encryptProduct() in that file and docs/SCS1_FORMAT.md). THE WHOLE WIRE FORMAT IS DEFINED IN THIS ONE FILE:
 *
 *   QR text    = "SCS1." + Base64URL( version[1] || nonce[12] || ciphertext || tag[16] )   (padding optional on read)
 *   version    = 0x01
 *   cipher     = AES-256-GCM, 128-bit tag
 *   AAD        = the single byte 0x01 (the version byte; NOT the text "SCS1")
 *   plaintext  = UTF-8 JSON {"serial_number":..., "product_name":..., "price":...}
 *
 * The text prefix "SCS1." only routes the scan to this decoder; the version byte inside the Base64 payload is
 * what is authenticated (as AAD) and checked.
 */
object Scs1Codec {
    const val PREFIX = "SCS1."
    const val VERSION: Byte = 0x01
    const val VERSION_LEN = 1
    const val NONCE_LEN = 12
    const val TAG_LEN = 16
    const val MAX_CHARS = 4096
    private const val TAG_BITS = 128
    /** AES-GCM additional authenticated data: the single version byte 0x01. */
    val AAD: ByteArray = byteArrayOf(VERSION)

    sealed class Result {
        class Decrypted(val plaintext: String) : Result()
        /** Authentication failed: wrong key, or the QR was altered / is not one of ours. */
        object WrongKeyOrCorrupt : Result()
        /** Not decodable as an SCS1 payload at all (bad Base64, too short, too long, unsupported version, not UTF-8). */
        object Malformed : Result()
    }

    fun isScs1(text: String): Boolean = text.startsWith(PREFIX)

    fun decrypt(key: ByteArray, qrText: String): Result {
        require(key.size == AesKeyParser.KEY_BYTES) { "AES-256 key must be 32 bytes" }
        val text = qrText.trim()
        if (!text.startsWith(PREFIX) || text.length > MAX_CHARS) return Result.Malformed
        val bytes = Base64Lenient.decode(text.substring(PREFIX.length)) ?: return Result.Malformed
        if (bytes.size < VERSION_LEN + NONCE_LEN + TAG_LEN + 1) return Result.Malformed
        if (bytes[0] != VERSION) return Result.Malformed // first byte must be version 0x01
        val nonce = bytes.copyOfRange(VERSION_LEN, VERSION_LEN + NONCE_LEN) // next 12 bytes
        val sealed = bytes.copyOfRange(VERSION_LEN + NONCE_LEN, bytes.size)  // the rest: ciphertext || 16-byte tag, exactly what JCE expects
        val plain = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(AAD)
            cipher.doFinal(sealed)
        } catch (e: GeneralSecurityException) {
            return Result.WrongKeyOrCorrupt
        }
        return try {
            val s = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(plain)).toString()
            Result.Decrypted(s)
        } catch (e: CharacterCodingException) {
            Result.Malformed
        } finally {
            plain.fill(0)
        }
    }
}
