package com.nrb.offlineqrscanner

import com.google.gson.JsonParser
import com.nrb.offlineqrscanner.security.AesKeyParser
import com.nrb.offlineqrscanner.security.Base64Lenient
import com.nrb.offlineqrscanner.security.Product
import com.nrb.offlineqrscanner.security.Scs1Codec
import com.nrb.offlineqrscanner.security.Scs1Codec.Result
import org.junit.Assert.*
import org.junit.Test

/**
 * Interoperability with the real generator. The payloads in src/test/resources/html_generated_payloads.json were
 * produced by running the UNMODIFIED script of Sharma_Cycle_Store_QR_Label_Maker_Print_Fixed.html and calling its own
 * encryptProduct() (see tools/make_html_vectors.js). The key is a test key, entered in the same Base64 form that the
 * page's "Generate key" button produces.
 */
class HtmlGeneratorPayloadTest {
    private val data = HtmlPayloads.load()
    private val key = AesKeyParser.parse(data.keyBase64) // existing Base64 key handling, unchanged

    @Test fun resourceHoldsRealGeneratorOutput() {
        assertTrue(data.items.size >= 5)
        assertEquals(64, data.htmlSha256.length)
        for (it in data.items) {
            assertTrue(it.qr.startsWith("SCS1."))
            val raw = Base64Lenient.decode(it.qr.removePrefix("SCS1."))!!
            assertEquals("first byte is version 0x01", 0x01.toByte(), raw[0])
            assertTrue("1 + 12 nonce + 16 tag + data", raw.size > 1 + 12 + 16)
        }
    }

    @Test fun everyHtmlGeneratedQrDecryptsToTheOriginalProductJson() {
        for (item in data.items) {
            val r = Scs1Codec.decrypt(key, item.qr)
            assertTrue("serial ${item.serial} did not decrypt: $r", r is Result.Decrypted)
            val obj = JsonParser.parseString((r as Result.Decrypted).plaintext).asJsonObject
            assertEquals(setOf("serial_number", "product_name", "price"), obj.keySet())
            assertEquals(item.serial, obj["serial_number"].asString)
            assertEquals(item.name, obj["product_name"].asString)
            assertEquals(item.price, obj["price"].asString)
        }
    }

    @Test fun scanDecoderShowsTheProductExactlyAsPrintedOnTheLabel() {
        val d = ScanDecoder(FakeKeyStore(key))
        for (item in data.items) {
            val r = d.process(item.qr)
            assertTrue("serial ${item.serial}: $r", r is ScanResult.ProductInfo)
            assertEquals(Product(item.serial, item.name, item.price), (r as ScanResult.ProductInfo).product)
        }
    }

    @Test fun sameKeyAsHexOrUrlSafeBase64WorksToo() {
        val hex = key.joinToString("") { "%02x".format(it) }
        val url = data.keyBase64.replace('+', '-').replace('/', '_').trimEnd('=')
        for (k in listOf(hex, url, "  $hex\n"))
            for (item in data.items) assertTrue(Scs1Codec.decrypt(AesKeyParser.parse(k), item.qr) is Result.Decrypted)
    }

    @Test fun wrongKeyIsRejected() {
        val wrong = key.copyOf().also { it[31] = (it[31].toInt() xor 1).toByte() }
        for (item in data.items) assertSame(Result.WrongKeyOrCorrupt, Scs1Codec.decrypt(wrong, item.qr))
    }

    @Test fun tamperingWithAHtmlGeneratedQrIsDetected() {
        val item = data.items[0]
        val raw = Base64Lenient.decode(item.qr.removePrefix("SCS1."))!!
        for (i in raw.indices) {
            val c = raw.copyOf(); c[i] = (c[i].toInt() xor 0x01).toByte()
            assertFalse("byte $i", Scs1Codec.decrypt(key, "SCS1." + TestScs1.b64u(c)) is Result.Decrypted)
        }
    }

    @Test fun kotlinEncodingOfTheSamePlaintextAndNonceIsByteIdenticalToTheHtmlOutput() {
        // Re-encrypt each HTML payload's own plaintext with its own nonce: must reproduce the HTML's QR text exactly.
        for (item in data.items) {
            val raw = Base64Lenient.decode(item.qr.removePrefix("SCS1."))!!
            val nonce = raw.copyOfRange(1, 13)
            val plain = (Scs1Codec.decrypt(key, item.qr) as Result.Decrypted).plaintext
            assertEquals(item.qr, TestScs1.encrypt(key, plain, nonce))
        }
    }
}
