package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.Scs1Codec
import com.nrb.offlineqrscanner.security.Scs1Codec.Result
import org.junit.Assert.*
import org.junit.Test

class Scs1CodecTest {
    private val v = Vectors.load()
    private val key = v.key
    private fun plain(r: Result) = (r as Result.Decrypted).plaintext

    // ---- interoperability with the independent Python implementation (same wire format as the HTML generator) ----
    @Test fun decryptsEveryVectorMadeByPythonCryptography() {
        assertTrue(v.items.size >= 5)
        for (item in v.items) assertEquals(item.name, item.plaintext, plain(Scs1Codec.decrypt(key, item.qr)))
    }
    @Test fun kotlinEncryptionIsByteIdenticalToPythonForTheSameKeyNonceAndPlaintext() {
        for (item in v.items) assertEquals(item.name, item.qr, TestScs1.encrypt(key, item.plaintext, item.nonce))
    }
    @Test fun wrongKeyIsRejectedForEveryVector() {
        for (item in v.items) assertSame(item.name, Result.WrongKeyOrCorrupt, Scs1Codec.decrypt(v.wrongKey, item.qr))
    }

    // ---- wire format ----
    @Test fun wireLayoutIsPrefixThenVersionNonceCiphertextTag() {
        val q = TestScs1.encrypt(key, "hello", ByteArray(12) { 9 })
        assertTrue(q.startsWith("SCS1."))
        val body = q.removePrefix("SCS1.")
        assertTrue(body.all { it.isLetterOrDigit() || it == '-' || it == '_' })
        val n = 1 + 12 + 5 + 16 // version + nonce + ciphertext + tag = 34 bytes
        assertEquals(n * 4 / 3 + if (n % 3 == 0) 0 else 1, body.length) // unpadded Base64 length
        val raw = com.nrb.offlineqrscanner.security.Base64Lenient.decode(body)!!
        assertEquals(n, raw.size)
        assertEquals(0x01.toByte(), raw[0])                                   // byte 0: version
        assertArrayEquals(ByteArray(12) { 9 }, raw.copyOfRange(1, 13))         // bytes 1..12: nonce
        assertEquals("hello", plain(Scs1Codec.decrypt(key, q)))
    }
    @Test fun constantsMatchTheHtmlGenerator() {
        assertEquals("SCS1.", Scs1Codec.PREFIX); assertEquals(0x01.toByte(), Scs1Codec.VERSION)
        assertEquals(12, Scs1Codec.NONCE_LEN); assertEquals(16, Scs1Codec.TAG_LEN)
        assertArrayEquals(byteArrayOf(0x01), Scs1Codec.AAD)
    }
    @Test fun versionByteMustBe0x01_evenWhenTheRestIsAuthenticForThatVersion() {
        // Encrypt with a different version byte AND matching AAD, so only the explicit version check can reject it.
        for (ver in intArrayOf(0x00, 0x02, 0x53, 0xFF)) {
            val q = TestScs1.encrypt(key, v.items[0].plaintext, aad = byteArrayOf(ver.toByte()), version = ver.toByte())
            assertSame("version $ver", Result.Malformed, Scs1Codec.decrypt(key, q))
        }
    }
    @Test fun versionByteAndAadAreNotInterchangeable() {
        // version byte 0x01 but AAD of old format / empty / different byte -> authentication must fail
        for (aad in listOf("SCS1".toByteArray(), ByteArray(0), byteArrayOf(0), byteArrayOf(2), byteArrayOf(1, 1)))
            assertSame(Result.WrongKeyOrCorrupt, Scs1Codec.decrypt(key, TestScs1.encrypt(key, v.items[0].plaintext, aad = aad)))
    }
    @Test fun oldPreFixLayoutWithoutVersionByteIsNoLongerAccepted() {
        // The layout this app used before: nonce || ciphertext || tag with AAD "SCS1" and no version byte.
        val nonce = ByteArray(12) { 5 }
        val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
        c.init(javax.crypto.Cipher.ENCRYPT_MODE, javax.crypto.spec.SecretKeySpec(key, "AES"), javax.crypto.spec.GCMParameterSpec(128, nonce))
        c.updateAAD("SCS1".toByteArray())
        val old = "SCS1." + TestScs1.b64u(nonce + c.doFinal("x".toByteArray()))
        assertFalse(Scs1Codec.decrypt(key, old) is Result.Decrypted)
    }
    @Test fun acceptsPaddedStandardAlphabetAndSurroundingWhitespace() {
        val item = v.items[0]
        val body = item.qr.removePrefix("SCS1.")
        val std = body.replace('-', '+').replace('_', '/') + "=".repeat((4 - body.length % 4) % 4)
        assertEquals(item.plaintext, plain(Scs1Codec.decrypt(key, "SCS1.$std")))
        assertEquals(item.plaintext, plain(Scs1Codec.decrypt(key, "  ${item.qr}\r\n")))
    }

    // ---- tamper / invalid input ----
    @Test fun flippingAnyBitOfAnyByteNeverDecrypts() {
        val q = TestScs1.encrypt(key, v.items[0].plaintext)
        val raw = com.nrb.offlineqrscanner.security.Base64Lenient.decode(q.removePrefix("SCS1."))!!
        var n = 0
        for (i in raw.indices) for (bit in intArrayOf(0, 3, 7)) {
            val c = raw.copyOf(); c[i] = (c[i].toInt() xor (1 shl bit)).toByte()
            assertSame("byte $i bit $bit", if (i == 0) Result.Malformed else Result.WrongKeyOrCorrupt, Scs1Codec.decrypt(key, "SCS1." + TestScs1.b64u(c))); n++
        }
        assertEquals(raw.size * 3, n); assertTrue(raw.size > 70)
        assertEquals(0x01.toByte(), raw[0])
    }
    @Test fun changingAnyCharacterNeverYieldsDifferentContent() {
        val item = v.items[0]; val alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        for (i in 5 until item.qr.length) {
            val repl = alpha[(alpha.indexOf(item.qr[i]) + 1) % 64]
            val r = Scs1Codec.decrypt(key, item.qr.substring(0, i) + repl + item.qr.substring(i + 1))
            // The only acceptable "success" is identical content (a change in the unused trailing Base64 bits).
            if (r is Result.Decrypted) assertEquals(item.plaintext, r.plaintext) else assertTrue(r === Result.WrongKeyOrCorrupt || r === Result.Malformed)
        }
    }
    @Test fun truncationExtensionAndGarbageAreRejected() {
        val item = v.items[0]; val raw = com.nrb.offlineqrscanner.security.Base64Lenient.decode(item.qr.removePrefix("SCS1."))!!
        val bad = listOf("SCS1.", "SCS1.A", "SCS1.AAAA", "SCS1.!!!!", "SCS1.ab cd", item.qr.dropLast(1), item.qr.dropLast(4), item.qr + "A",
            "SCS1." + TestScs1.b64u(raw.copyOf(raw.size - 1)), "SCS1." + TestScs1.b64u(raw + byteArrayOf(0)), "SCS1." + TestScs1.b64u(raw.copyOf(28)), "SCS1." + TestScs1.b64u(raw.copyOf(29)),
            "SCS1." + "A".repeat(5000), "SCS1.é")
        for (b in bad) assertFalse("accepted: ${b.take(30)}", Scs1Codec.decrypt(key, b) is Result.Decrypted)
    }
    @Test fun wrongPrefixIsMalformedAndIsScs1IsCaseSensitive() {
        assertSame(Result.Malformed, Scs1Codec.decrypt(key, "SCS2." + v.items[0].qr.removePrefix("SCS1.")))
        assertTrue(Scs1Codec.isScs1("SCS1.abc")); assertFalse(Scs1Codec.isScs1("scs1.abc")); assertFalse(Scs1Codec.isScs1("SCS1abc")); assertFalse(Scs1Codec.isScs1(" SCS1.abc")); assertFalse(Scs1Codec.isScs1("https://x"))
    }
    @Test fun aadIsEnforced() {
        for (aad in listOf(null, "SCS2".toByteArray(), "".toByteArray(), "SCS1.".toByteArray(), "scs1".toByteArray(), "SCS1".toByteArray(), byteArrayOf(0), byteArrayOf(2)))
            assertSame(Result.WrongKeyOrCorrupt, Scs1Codec.decrypt(key, TestScs1.encrypt(key, v.items[0].plaintext, aad = aad)))
    }
    @Test fun authenticatedButNotUtf8IsMalformed() {
        val q = "SCS1." + TestScs1.b64u(TestScs1.rawBytes(key, byteArrayOf(0x7B, 0xC3.toByte(), 0x28, 0x7D), ByteArray(12) { 3 }))
        assertSame(Result.Malformed, Scs1Codec.decrypt(key, q))
    }
    @Test fun badKeyLengthIsAProgrammingError() {
        try { Scs1Codec.decrypt(ByteArray(16), v.items[0].qr); fail() } catch (e: IllegalArgumentException) { }
    }
    @Test fun nonceIsNotRequiredToBeUniqueToDecrypt_butDistinctNoncesGiveDistinctQrs() {
        val a = TestScs1.encrypt(key, "same"); val b = TestScs1.encrypt(key, "same"); assertNotEquals(a, b)
    }
}
