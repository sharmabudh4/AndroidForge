package com.nrb.offlineqrscanner

import com.google.gson.JsonParser
import com.nrb.offlineqrscanner.security.BlobStorage
import com.nrb.offlineqrscanner.security.SecretKeyProvider
import com.nrb.offlineqrscanner.security.SecureKeyStore
import com.nrb.offlineqrscanner.security.SavedKeyUnreadableException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Software AES key standing in for the Android Keystore key (which cannot exist on a plain JVM). */
class InMemoryKeyProvider : SecretKeyProvider {
    var key: SecretKey? = null
    var deleteCalls = 0
    override fun getOrCreate(): SecretKey = key ?: KeyGenerator.getInstance("AES").apply { init(256) }.generateKey().also { key = it }
    override fun delete() { key = null; deleteCalls++ }
}

class InMemoryBlobStorage : BlobStorage {
    var blob: ByteArray? = null
    override fun read(): ByteArray? = blob?.copyOf()
    override fun write(blob: ByteArray) { this.blob = blob.copyOf() }
    override fun remove() { blob = null }
}

/** Plain double for ScanDecoder tests. */
class FakeKeyStore(var key: ByteArray? = null, var unreadable: Boolean = false) : SecureKeyStore {
    override fun hasKey() = key != null
    override fun save(key: ByteArray) { this.key = key.copyOf() }
    override fun load(): ByteArray? { if (unreadable) throw SavedKeyUnreadableException("x"); return key?.copyOf() }
    override fun clear() { key = null }
}

/** Test-side encoder written independently of the production decoder (straight from docs/SCS1_FORMAT.md / the HTML generator). */
object TestScs1 {
    private const val ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    fun b64u(b: ByteArray): String {
        val sb = StringBuilder(); var i = 0
        while (i < b.size) {
            val n = minOf(3, b.size - i)
            var v = 0
            for (k in 0 until 3) v = (v shl 8) or (if (k < n) b[i + k].toInt() and 0xFF else 0)
            for (k in 0..n) sb.append(ALPHA[(v shr (18 - 6 * k)) and 63])
            i += 3
        }
        return sb.toString()
    }
    /** version byte 0x01 || nonce || ciphertext || tag. Default AAD is the single byte 0x01, as in the HTML generator. */
    fun rawBytes(key: ByteArray, plaintext: ByteArray, nonce: ByteArray, aad: ByteArray? = byteArrayOf(1), version: Byte = 1): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        if (aad != null) c.updateAAD(aad)
        return byteArrayOf(version) + nonce + c.doFinal(plaintext)
    }
    fun encrypt(key: ByteArray, plaintext: String, nonce: ByteArray = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }, aad: ByteArray? = byteArrayOf(1), version: Byte = 1) =
        "SCS1." + b64u(rawBytes(key, plaintext.toByteArray(Charsets.UTF_8), nonce, aad, version))
}

fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

class Vectors(val key: ByteArray, val wrongKey: ByteArray, val items: List<Item>) {
    class Item(val name: String, val nonce: ByteArray, val plaintext: String, val qr: String)
    companion object {
        fun load(): Vectors {
            val text = Vectors::class.java.classLoader!!.getResource("scs1_vectors.json")!!.readText()
            val o = JsonParser.parseString(text).asJsonObject
            return Vectors(hex(o["key_hex"].asString), hex(o["wrong_key_hex"].asString),
                o["vectors"].asJsonArray.map { val v = it.asJsonObject; Item(v["name"].asString, hex(v["nonce_hex"].asString), v["plaintext"].asString, v["qr"].asString) })
        }
    }
}

/** Real QR payloads produced by the HTML QR Label Maker itself (see tools/make_html_vectors.js). */
class HtmlPayloads(val keyBase64: String, val htmlSha256: String, val items: List<Item>) {
    class Item(val serial: String, val name: String, val price: String, val qr: String)
    companion object {
        fun load(): HtmlPayloads {
            val text = HtmlPayloads::class.java.classLoader!!.getResource("html_generated_payloads.json")!!.readText()
            val o = JsonParser.parseString(text).asJsonObject
            return HtmlPayloads(o["key_base64"].asString, o["html_sha256"].asString,
                o["items"].asJsonArray.map { val v = it.asJsonObject; Item(v["serial"].asString, v["name"].asString, v["price"].asString, v["qr"].asString) })
        }
    }
}
