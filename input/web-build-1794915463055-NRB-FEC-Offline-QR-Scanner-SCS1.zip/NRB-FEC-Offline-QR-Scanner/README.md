# NRB FEC QR Scanner (offline, with SCS1 decryption)

Android app (Kotlin, CameraX + bundled ML Kit, minSdk 24). It has **no INTERNET permission**; everything
happens on the phone.

## What it does

* **Scans any QR code** (live camera or from the gallery, flashlight, same scan frame and design as before).
  An ordinary QR code is shown exactly as decoded, with a Copy button. Nothing is opened automatically.
* **First launch:** one field for your AES-256 security key (64 hex characters from the QR Generator).
  The key is saved encrypted (AES-GCM with a non-exportable Android Keystore key, kept in private app
  storage, excluded from backups) and is **not asked for again**. "Skip for now" is available because
  ordinary QR codes do not need a key; add it later in Settings.
* **QR codes starting with `SCS1.`** are decrypted with the saved key (AES-256-GCM). On success the app
  shows **serial number, product name and price**. A wrong key, an altered or invalid QR, or a missing key
  shows an error, never the raw text.
* **Settings:** replace or remove the saved key, version, about.
* Removed: login, registration / user management, device authorization, digital signatures (ECDSA), the
  local database, scan history and the device/QR export screens.

Read `docs/SCS1_FORMAT.md` first: **the SCS1 byte format is defined by this app because the generator you
supplied does not encrypt anything.** Your generator must produce that format (or `Scs1Codec.kt` must be
changed to match it).

## Build

1. Android Studio Hedgehog (2023.1) or newer, JDK 17.
2. File > Open > this folder. The first Gradle sync needs internet to download dependencies; the finished
   app does not.
3. Run on a device (the camera is needed), or `./gradlew assembleDebug`.

**Build status: not verified.** The environment this project was edited in has no Android SDK and no access
to Google Maven / Maven Central, so Gradle could not be run. See "What was and was not tested" below.

## Trying it without your generator

```
pip install cryptography "qrcode[pil]"
python tools/scs1_encrypt.py --gen-key                                   # a test key to paste into the app
python tools/scs1_encrypt.py --key <that key> --serial 1001 --name "LED Bulb 9W" --price 80 --png label.png
```
Open `label.png` on a screen and scan it. Scanning a normal QR code (a web address, plain text) should show
its text; scanning it with the wrong key (Settings > Replace Key) should show the decryption error.

## What was and was not tested

Run here (plain JVM, Kotlin 1.9.22 compiler; Node 22; Python `cryptography`; OpenCV):

* 40 JUnit tests on the real production classes (`Scs1Codec`, `ProductParser`, `AesKeyParser`,
  `EncryptedKeyStore`, `ScanDecoder`): decryption, wrong key, tamper detection (every byte, several bits),
  truncation, wrong prefix/AAD, key storage encryption and clearing, plain vs. SCS1 routing.
  Run them in Android Studio with `./gradlew testDebugUnitTest` (not run through Gradle here).
* Cross-implementation checks between Kotlin/JCE, Node Web Crypto and Python `cryptography` (see
  `docs/SCS1_FORMAT.md`), and decoding a rendered SCS1 QR image with OpenCV.
* A static checker confirmed that every `R.*`, `@string/...`, view-binding field, manifest activity and
  import resolves after the deletions (and was shown to catch deliberately injected faults).

**Not** tested: the Gradle build / APK, any screen on a real device or emulator, the Android Keystore
and SharedPreferences storage, CameraX / ML Kit scanning, and compatibility with your QR Generator.
