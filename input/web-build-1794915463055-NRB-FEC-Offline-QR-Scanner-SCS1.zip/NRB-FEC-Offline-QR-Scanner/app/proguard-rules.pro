# Release builds currently run with minifyEnabled false. If you enable minification, the app needs
# no extra rules for its own code (Gson is only used on plain JsonObject trees, never reflection-mapped
# classes); CameraX and ML Kit ship their own consumer rules.
