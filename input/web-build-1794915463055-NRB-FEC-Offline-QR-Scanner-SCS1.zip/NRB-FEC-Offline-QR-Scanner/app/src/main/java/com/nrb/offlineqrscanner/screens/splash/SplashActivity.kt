package com.nrb.offlineqrscanner.screens.splash

import android.content.Intent
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.databinding.ActivitySplashBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.keysetup.KeySetupActivity

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ivAppIcon.scaleX = 0.4f
        binding.ivAppIcon.scaleY = 0.4f
        binding.ivAppIcon.alpha = 0f
        binding.tvAppName.alpha = 0f
        binding.tvAppSubtitle.alpha = 0f

        binding.ivAppIcon.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(500).setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                binding.tvAppName.animate().alpha(1f).setDuration(300).start()
                binding.tvAppSubtitle.animate().alpha(1f).setDuration(300).setStartDelay(100)
                    .withEndAction { proceed() }.start()
            }.start()
    }

    private fun proceed() {
        binding.root.postDelayed({
            // First launch only: ask for the security key once. After it is saved (or the user chose
            // "Skip for now") this screen goes straight to Home on every later launch.
            val needsKeySetup = !nrbApp.keyStore.hasKey() && !nrbApp.prefs.keySetupHandled
            val target = if (needsKeySetup) KeySetupActivity::class.java else HomeActivity::class.java
            startActivity(Intent(this, target).apply { if (needsKeySetup) putExtra(KeySetupActivity.EXTRA_FIRST_RUN, true) })
            finish()
        }, 500)
    }
}
