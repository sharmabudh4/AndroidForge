package com.nrb.offlineqrscanner.security

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/** What a decrypted SCS1 QR code says about a product. [price] is the bare amount (no currency symbol). */
data class Product(val serial: String, val name: String, val price: String)

/**
 * Reads the decrypted text. Two shapes are accepted:
 *  1. JSON object: {"serial":"1001","name":"LED Bulb 9W","price":"80"}  (also serial_no / serial_number,
 *     product_name, product_price as alternative key names; price may be a string or a number)
 *  2. The legacy generator line: "Serial No: 1001, Product Name: LED Bulb 9W, Price: Rs. 80"
 * Anything else, or any missing field, returns null (never a half-filled record).
 */
object ProductParser {
    private const val MAX_FIELD = 200
    private val LINE = Regex("""^Serial No:\s*(.+?)\s*,\s*Product Name:\s*(.+)\s*,\s*Price:\s*(.+?)\s*$""", RegexOption.IGNORE_CASE)
    private val CURRENCY = Regex("""^(?:rs\.?|inr|₹)\s*""", RegexOption.IGNORE_CASE)

    fun parse(plaintext: String): Product? {
        val t = plaintext.trim()
        return if (t.startsWith("{")) fromJson(t) else fromLine(t)
    }

    private fun fromLine(t: String): Product? {
        val m = LINE.matchEntire(t) ?: return null
        return build(m.groupValues[1], m.groupValues[2], m.groupValues[3])
    }

    private fun fromJson(t: String): Product? {
        val obj: JsonObject = try {
            val e = JsonParser.parseString(t)
            if (!e.isJsonObject) return null
            e.asJsonObject
        } catch (e: Exception) {
            return null
        }
        return build(
            field(obj, "serial", "serial_no", "serial_number", "sn"),
            field(obj, "name", "product_name", "product"),
            field(obj, "price", "product_price")
        )
    }

    private fun field(o: JsonObject, vararg keys: String): String? {
        for (k in keys) {
            val e: JsonElement = o.get(k) ?: continue
            if (e.isJsonPrimitive) return e.asString
        }
        return null
    }

    private fun build(serial: String?, name: String?, price: String?): Product? {
        val s = serial?.trim().orEmpty()
        val n = name?.trim().orEmpty()
        val p = price?.trim()?.replace(CURRENCY, "")?.trim().orEmpty()
        if (s.isEmpty() || n.isEmpty() || p.isEmpty()) return null
        if (s.length > MAX_FIELD || n.length > MAX_FIELD || p.length > MAX_FIELD) return null
        return Product(s, n, p)
    }
}
