package com.nrb.offlineqrscanner.security

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Decrypts "SCS1." QR codes. THE WHOLE WIRE FORMAT IS DEFINED IN THIS ONE FILE (see docs/SCS1_FORMAT.md):
 *
 *   QR text    = "SCS1." + Base64URL( nonce[12] || ciphertext || tag[16] )     (padding optional on read)
 *   cipher     = AES-256-GCM, 128-bit tag
 *   AAD        = ASCII "SCS1"   (binds the version/prefix to the ciphertext)
 *   plaintext  = UTF-8 text (JSON object, or the legacy "Serial No: ..., Product Name: ..., Price: Rs. ..." line)
 *
 * If your QR Generator uses different constants, change them here and nowhere else.
 */
object Scs1Codec {
    const val PREFIX = "SCS1."
    const val NONCE_LEN = 12
    const val TAG_LEN = 16
    const val MAX_CHARS = 4096
    private const val TAG_BITS = 128
    val AAD: ByteArray = "SCS1".toByteArray(Charsets.US_ASCII)

    sealed class Result {
        class Decrypted(val plaintext: String) : Result()
        /** Authentication failed: wrong key, or the QR was altered / is not one of ours. */
        object WrongKeyOrCorrupt : Result()
        /** Not decodable as an SCS1 payload at all (bad Base64, too short, too long, not UTF-8). */
        object Malformed : Result()
    }

    fun isScs1(text: String): Boolean = text.startsWith(PREFIX)

    fun decrypt(key: ByteArray, qrText: String): Result {
        require(key.size == AesKeyParser.KEY_BYTES) { "AES-256 key must be 32 bytes" }
        val text = qrText.trim()
        if (!text.startsWith(PREFIX) || text.length > MAX_CHARS) return Result.Malformed
        val bytes = Base64Lenient.decode(text.substring(PREFIX.length)) ?: return Result.Malformed
        if (bytes.size < NONCE_LEN + TAG_LEN + 1) return Result.Malformed
        val nonce = bytes.copyOfRange(0, NONCE_LEN)
        val sealed = bytes.copyOfRange(NONCE_LEN, bytes.size) // ciphertext || tag, exactly what JCE expects
        val plain = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
            cipher.updateAAD(AAD)
            cipher.doFinal(sealed)
        } catch (e: GeneralSecurityException) {
            return Result.WrongKeyOrCorrupt
        }
        return try {
            val s = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(plain)).toString()
            Result.Decrypted(s)
        } catch (e: CharacterCodingException) {
            Result.Malformed
        } finally {
            plain.fill(0)
        }
    }
}
