package com.nrb.offlineqrscanner.security

import android.content.Context
import android.util.Base64

/** Stores the already-encrypted security-key blob in this app's private SharedPreferences (excluded from backup). */
class PrefsBlobStorage(context: Context) : BlobStorage {
    private val prefs = context.applicationContext.getSharedPreferences("scs_secure_key", Context.MODE_PRIVATE)

    override fun read(): ByteArray? {
        val text = prefs.getString(KEY, null) ?: return null
        return try { Base64.decode(text, Base64.NO_WRAP) } catch (e: IllegalArgumentException) { ByteArray(0) } // unreadable -> decrypt fails -> cleared
    }

    override fun write(blob: ByteArray) {
        // commit() (synchronous) so the key is definitely on disk before we report success
        if (!prefs.edit().putString(KEY, Base64.encodeToString(blob, Base64.NO_WRAP)).commit())
            throw java.io.IOException("Could not persist the security key")
    }

    override fun remove() {
        prefs.edit().remove(KEY).commit()
    }

    private companion object { const val KEY = "blob" }
}
