package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.Product
import com.nrb.offlineqrscanner.security.ProductParser
import com.nrb.offlineqrscanner.security.SavedKeyUnreadableException
import com.nrb.offlineqrscanner.security.Scs1Codec
import com.nrb.offlineqrscanner.security.SecureKeyStore

sealed class ScanResult {
    /** An ordinary QR code: shown exactly as decoded. */
    class Plain(val text: String) : ScanResult()
    /** A valid SCS1 QR code that decrypted with the saved key. */
    class ProductInfo(val product: Product) : ScanResult()
    class Failure(val kind: Kind) : ScanResult()

    enum class Kind { NO_KEY, KEY_UNREADABLE, WRONG_KEY_OR_INVALID, MALFORMED, NOT_PRODUCT }
}

/**
 * Decides what a scanned QR is. Anything that does not start with "SCS1." is an ordinary QR code and is
 * returned untouched. "SCS1." codes are decrypted with the saved key; they never fall back to being
 * shown as plain text, so a wrong key can never leak the (unreadable) payload as if it were content.
 */
class ScanDecoder(private val keys: SecureKeyStore) {
    fun process(raw: String): ScanResult {
        if (!Scs1Codec.isScs1(raw)) return ScanResult.Plain(raw)
        val key = try {
            keys.load()
        } catch (e: SavedKeyUnreadableException) {
            return ScanResult.Failure(ScanResult.Kind.KEY_UNREADABLE)
        } ?: return ScanResult.Failure(ScanResult.Kind.NO_KEY)
        try {
            return when (val r = Scs1Codec.decrypt(key, raw)) {
                is Scs1Codec.Result.Decrypted -> {
                    val product = ProductParser.parse(r.plaintext)
                    if (product != null) ScanResult.ProductInfo(product) else ScanResult.Failure(ScanResult.Kind.NOT_PRODUCT)
                }
                Scs1Codec.Result.WrongKeyOrCorrupt -> ScanResult.Failure(ScanResult.Kind.WRONG_KEY_OR_INVALID)
                Scs1Codec.Result.Malformed -> ScanResult.Failure(ScanResult.Kind.MALFORMED)
            }
        } finally {
            key.fill(0)
        }
    }
}
