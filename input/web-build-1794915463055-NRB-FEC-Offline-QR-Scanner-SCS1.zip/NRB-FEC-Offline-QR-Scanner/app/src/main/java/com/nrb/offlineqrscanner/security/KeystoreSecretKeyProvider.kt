package com.nrb.offlineqrscanner.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * AES-256 key held in the Android Keystore (hardware-backed where the device supports it). The key
 * material is non-exportable: this app can use it to encrypt/decrypt, but cannot read it out, and it
 * is not included in backups or device transfer. No user-authentication prompt is required, because
 * the saved key must be usable silently at launch.
 */
class KeystoreSecretKeyProvider(private val alias: String = "scs_key_wrapper") : SecretKeyProvider {
    private companion object { const val PROVIDER = "AndroidKeyStore" }

    @Synchronized
    override fun getOrCreate(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    @Synchronized
    override fun delete() {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        if (ks.containsAlias(alias)) ks.deleteEntry(alias)
    }
}
