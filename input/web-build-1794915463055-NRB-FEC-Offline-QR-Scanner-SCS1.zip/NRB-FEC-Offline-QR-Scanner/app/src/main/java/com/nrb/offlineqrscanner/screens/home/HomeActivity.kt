package com.nrb.offlineqrscanner.screens.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityHomeBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.screens.settings.SettingsActivity
import com.nrb.offlineqrscanner.utils.setupBottomNav

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupBottomNav(binding.bottomNav, R.id.nav_home)
        binding.ivSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnScanQr.setOnClickListener { startActivity(Intent(this, ScanQRActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        binding.tvKeyStatus.setText(if (nrbApp.keyStore.hasKey()) R.string.key_status_saved_short else R.string.key_status_none_short)
    }
}
