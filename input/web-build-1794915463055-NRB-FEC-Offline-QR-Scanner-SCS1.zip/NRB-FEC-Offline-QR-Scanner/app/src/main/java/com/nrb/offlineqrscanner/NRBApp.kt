package com.nrb.offlineqrscanner

import android.app.Application
import android.content.Context
import com.nrb.offlineqrscanner.security.AesGcmCipher
import com.nrb.offlineqrscanner.security.EncryptedKeyStore
import com.nrb.offlineqrscanner.security.KeystoreSecretKeyProvider
import com.nrb.offlineqrscanner.security.PrefsBlobStorage
import com.nrb.offlineqrscanner.security.SecureKeyStore

/** Application class doubling as a tiny service locator (no DI framework needed for this size). */
class NRBApp : Application() {
    /** The AES-256 security key: AES-GCM encrypted with a non-exportable Android Keystore key. */
    val keyStore: SecureKeyStore by lazy { EncryptedKeyStore(PrefsBlobStorage(this), AesGcmCipher(KeystoreSecretKeyProvider())) }
    val decoder: ScanDecoder by lazy { ScanDecoder(keyStore) }
    val prefs: AppPrefs by lazy { AppPrefs(this) }
}

val Context.nrbApp: NRBApp get() = applicationContext as NRBApp

/** Remembers that the first-launch key screen has been dealt with, so it is never shown on every launch. */
class AppPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("scs_app", Context.MODE_PRIVATE)
    var keySetupHandled: Boolean
        get() = sp.getBoolean("key_setup_handled", false)
        set(v) { sp.edit().putBoolean("key_setup_handled", v).apply() }
}
