package com.nrb.offlineqrscanner.screens.keysetup

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityKeySetupBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.security.AesKeyParser

/**
 * One field for the AES-256 security key from the QR Generator. Shown once on first launch; also
 * reused from Settings to replace the key. The key is only ever stored encrypted (see NRBApp.keyStore).
 */
class KeySetupActivity : AppCompatActivity() {
    companion object { const val EXTRA_FIRST_RUN = "first_run" }

    private lateinit var binding: ActivityKeySetupBinding
    private val firstRun by lazy { intent.getBooleanExtra(EXTRA_FIRST_RUN, false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The key is a secret: keep it out of screenshots and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityKeySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvTitle.setText(if (firstRun) R.string.key_setup_title else R.string.key_replace_title)
        binding.btnSkip.setText(if (firstRun) R.string.skip_for_now else R.string.cancel)
        binding.btnSave.setOnClickListener { save() }
        binding.btnSkip.setOnClickListener { finishScreen(saved = false) }
    }

    private fun save() {
        binding.tvError.visibility = View.GONE
        var key: ByteArray? = null
        try {
            key = AesKeyParser.parse(binding.etKey.text?.toString().orEmpty())
            nrbApp.keyStore.save(key)
            binding.etKey.setText("") // do not leave the key sitting in the field
            finishScreen(saved = true)
        } catch (e: IllegalArgumentException) {
            showError(e.message ?: getString(R.string.key_invalid))
        } catch (e: Exception) {
            showError(getString(R.string.key_save_failed))
        } finally {
            key?.fill(0)
        }
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
    }

    private fun finishScreen(saved: Boolean) {
        if (firstRun) {
            nrbApp.prefs.keySetupHandled = true
            startActivity(Intent(this, HomeActivity::class.java))
        }
        finish()
    }
}
