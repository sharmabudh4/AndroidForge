package com.nrb.offlineqrscanner.screens.scanner

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.ScanResult
import com.nrb.offlineqrscanner.databinding.ActivityScanBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.result.ScanResultActivity
import com.nrb.offlineqrscanner.utils.setupBottomNav
import com.nrb.offlineqrscanner.utils.toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Live camera scanning (CameraX + bundled ML Kit model: works fully offline), plus a gallery fallback. Any QR code is accepted; see ScanDecoder for what happens next. */
class ScanQRActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScanBinding
    private lateinit var analysisExecutor: ExecutorService
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var torchOn = false
    private val busy = AtomicBoolean(false)
    private var lineAnimator: android.animation.ValueAnimator? = null

    private val scanner by lazy {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else binding.tvStatus.setText(R.string.camera_permission_denied)
    }

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let(::decodeFromGallery)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNav(binding.bottomNav, R.id.nav_scanner)
        analysisExecutor = Executors.newSingleThreadExecutor()
        binding.btnBack.setOnClickListener { finish() }
        binding.btnGallery.setOnClickListener { galleryPicker.launch("image/*") }
        binding.btnFlash.setOnClickListener { toggleTorch() }
        binding.tvStatus.setText(R.string.scan_hint)
        startScanLineAnimation()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startScanLineAnimation() {
        val frameHeight = 260 * resources.displayMetrics.density
        lineAnimator = android.animation.ValueAnimator.ofFloat(0f, frameHeight).apply {
            duration = 1800
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.RESTART
            addUpdateListener { binding.scanLine.translationY = it.animatedValue as Float }
            start()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(analysisExecutor, ::analyze) }
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                binding.tvStatus.setText(R.string.camera_error)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleTorch() {
        val cam = camera ?: return
        if (cam.cameraInfo.hasFlashUnit()) {
            torchOn = !torchOn
            cam.cameraControl.enableTorch(torchOn)
        }
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || busy.get()) {
            proxy.close()
            return
        }
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(input)
            .addOnSuccessListener { codes -> codes.firstNotNullOfOrNull { it.rawValue }?.let(::onQrDecoded) }
            .addOnCompleteListener { proxy.close() }
    }

    private fun decodeFromGallery(uri: Uri) {
        val input = try { InputImage.fromFilePath(this, uri) } catch (e: Exception) { null }
        if (input == null) { toast(getString(R.string.no_qr_found_in_image)); return }
        scanner.process(input)
            .addOnSuccessListener { codes ->
                val value = codes.firstNotNullOfOrNull { it.rawValue }
                if (value == null) toast(getString(R.string.no_qr_found_in_image)) else onQrDecoded(value)
            }
            .addOnFailureListener { toast(getString(R.string.no_qr_found_in_image)) }
    }

    private fun onQrDecoded(raw: String) {
        if (!busy.compareAndSet(false, true)) return
        // Everything happens on this phone: ordinary QR codes are shown as-is, "SCS1." codes are
        // decrypted with the saved key. Decryption of one tiny payload is instant, so no background thread is needed.
        val result = try {
            nrbApp.decoder.process(raw)
        } catch (e: Exception) {
            ScanResult.Failure(ScanResult.Kind.MALFORMED)
        }
        ScanResultActivity.launch(this, result)
        finish()
    }

    override fun onDestroy() {
        lineAnimator?.cancel()
        cameraProvider?.unbindAll()
        scanner.close() // `scanner` is `by lazy`, so accessing it here is always safe even if scanning never started
        analysisExecutor.shutdown()
        super.onDestroy()
    }
}
