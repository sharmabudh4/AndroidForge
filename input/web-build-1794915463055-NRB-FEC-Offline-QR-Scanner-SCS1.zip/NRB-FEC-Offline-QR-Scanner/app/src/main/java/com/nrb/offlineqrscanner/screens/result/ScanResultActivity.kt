package com.nrb.offlineqrscanner.screens.result

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.ScanResult
import com.nrb.offlineqrscanner.databinding.ActivityScanResultBinding
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.utils.toast

/** Shows one scan result: product details (decrypted SCS1), the plain content of an ordinary QR code, or an error. */
class ScanResultActivity : AppCompatActivity() {
    companion object {
        private const val KIND = "kind"          // "plain" | "product" | "error"
        private const val TEXT = "text"
        private const val SERIAL = "serial"
        private const val NAME = "name"
        private const val PRICE = "price"
        private const val ERROR = "error"

        fun launch(context: Context, result: ScanResult) {
            val i = Intent(context, ScanResultActivity::class.java)
            when (result) {
                is ScanResult.Plain -> i.putExtra(KIND, "plain").putExtra(TEXT, result.text)
                is ScanResult.ProductInfo -> i.putExtra(KIND, "product")
                    .putExtra(SERIAL, result.product.serial).putExtra(NAME, result.product.name).putExtra(PRICE, result.product.price)
                is ScanResult.Failure -> i.putExtra(KIND, "error").putExtra(ERROR, result.kind.name)
            }
            context.startActivity(i)
        }

        private fun errorMessage(kind: String?): Int = when (kind) {
            ScanResult.Kind.NO_KEY.name -> R.string.err_no_key
            ScanResult.Kind.KEY_UNREADABLE.name -> R.string.err_key_unreadable
            ScanResult.Kind.WRONG_KEY_OR_INVALID.name -> R.string.err_wrong_key
            ScanResult.Kind.NOT_PRODUCT.name -> R.string.err_not_product
            else -> R.string.err_malformed
        }
    }

    private lateinit var binding: ActivityScanResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnScanAgain.setOnClickListener { startActivity(Intent(this, ScanQRActivity::class.java)); finish() }
        binding.btnHome.setOnClickListener { startActivity(Intent(this, HomeActivity::class.java)); finish() }

        when (intent.getStringExtra(KIND)) {
            "product" -> showProduct()
            "plain" -> showPlain(intent.getStringExtra(TEXT).orEmpty())
            else -> showError(errorMessage(intent.getStringExtra(ERROR)))
        }
    }

    private fun showProduct() {
        binding.ivStatus.setImageResource(R.drawable.ic_check_circle)
        binding.tvTitle.setText(R.string.product_details)
        binding.tvTitle.setTextColor(getColor(R.color.success_primary))
        binding.card.setCardBackgroundColor(getColor(R.color.success_card))
        binding.layoutProduct.visibility = View.VISIBLE
        binding.tvSerial.text = intent.getStringExtra(SERIAL).orEmpty()
        binding.tvProductName.text = intent.getStringExtra(NAME).orEmpty()
        binding.tvPrice.text = getString(R.string.price_fmt, intent.getStringExtra(PRICE).orEmpty())
    }

    private fun showPlain(text: String) {
        binding.ivStatus.setImageResource(R.drawable.ic_qr_scan)
        binding.tvTitle.setText(R.string.qr_content)
        binding.tvTitle.setTextColor(getColor(R.color.text_primary))
        binding.card.setCardBackgroundColor(getColor(R.color.bg_secondary))
        binding.tvContent.visibility = View.VISIBLE
        binding.tvContent.text = text
        binding.btnCopy.visibility = View.VISIBLE
        binding.btnCopy.setOnClickListener {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("QR content", text))
            toast(getString(R.string.copied))
        }
    }

    private fun showError(messageRes: Int) {
        binding.ivStatus.setImageResource(R.drawable.ic_cancel)
        binding.tvTitle.setText(R.string.cannot_read_qr)
        binding.tvTitle.setTextColor(getColor(R.color.denied_primary))
        binding.card.setCardBackgroundColor(getColor(R.color.denied_card))
        binding.tvContent.visibility = View.VISIBLE
        binding.tvContent.setText(messageRes)
    }
}
