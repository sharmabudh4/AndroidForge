package com.nrb.offlineqrscanner.security

/** Turns the text the user types or pastes into a 32-byte AES-256 key. */
object AesKeyParser {
    const val KEY_BYTES = 32

    /**
     * Accepts 64 hex characters, or 43/44 characters of Base64 (standard or URL-safe, padding optional).
     * Whitespace anywhere is ignored (so a key pasted across several lines works).
     * @throws IllegalArgumentException with a message that is safe to show to the user.
     */
    fun parse(input: String): ByteArray {
        val t = input.filterNot { it.isWhitespace() }
        if (t.isEmpty()) throw IllegalArgumentException("Enter your security key.")
        val raw: ByteArray = when {
            t.length == 64 && t.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' } ->
                ByteArray(32) { i -> t.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
            t.length in 43..44 -> Base64Lenient.decode(t)
                ?: throw IllegalArgumentException("That is not a valid key. Use the 64-character key from the QR Generator.")
            else -> throw IllegalArgumentException("A key is 64 hex characters (or 43 Base64 characters). Check that it was copied completely.")
        }
        if (raw.size != KEY_BYTES) throw IllegalArgumentException("The key must be exactly 256 bits (32 bytes).")
        if (raw.all { it == 0.toByte() }) throw IllegalArgumentException("That is not a valid key.")
        return raw
    }
}

/**
 * Base64 decoder with no Android / Java 8 dependency (java.util.Base64 needs API 26; this app's minSdk is 24).
 * Accepts both the standard (+ /) and URL-safe (- _) alphabets, with or without '=' padding.
 */
object Base64Lenient {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    private val REVERSE = IntArray(128) { -1 }.also { r ->
        ALPHABET.forEachIndexed { i, c -> r[c.code] = i }
        r['+'.code] = 62; r['-'.code] = 62; r['/'.code] = 63; r['_'.code] = 63
    }

    /** Returns null for any character outside the alphabet or an impossible length. */
    fun decode(input: String): ByteArray? {
        val s = input.trimEnd('=')
        if (s.isEmpty() || s.length % 4 == 1) return null
        val out = ByteArray(s.length * 6 / 8)
        var buf = 0
        var bits = 0
        var n = 0
        for (ch in s) {
            val v = if (ch.code < 128) REVERSE[ch.code] else -1
            if (v < 0) return null
            buf = (buf shl 6) or v
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out[n++] = ((buf shr bits) and 0xFF).toByte()
            }
            buf = buf and ((1 shl bits) - 1)
        }
        return out
    }
}
