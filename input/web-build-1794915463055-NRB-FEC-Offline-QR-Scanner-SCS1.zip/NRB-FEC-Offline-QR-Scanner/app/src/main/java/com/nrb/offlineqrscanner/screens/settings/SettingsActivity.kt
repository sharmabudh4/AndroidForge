package com.nrb.offlineqrscanner.screens.settings

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivitySettingsBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.keysetup.KeySetupActivity
import com.nrb.offlineqrscanner.utils.setupBottomNav
import com.nrb.offlineqrscanner.utils.toast

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupBottomNav(binding.bottomNav, R.id.nav_settings)

        binding.btnReplaceKey.setOnClickListener { startActivity(Intent(this, KeySetupActivity::class.java)) }
        binding.btnRemoveKey.setOnClickListener { confirmRemoveKey() }
        binding.tvAppVersion.text = getString(R.string.app_version_fmt, packageManager.getPackageInfo(packageName, 0).versionName)
    }

    override fun onResume() {
        super.onResume()
        refreshKeyStatus()
    }

    private fun refreshKeyStatus() {
        val has = nrbApp.keyStore.hasKey()
        binding.tvKeyStatus.setText(if (has) R.string.key_status_saved else R.string.key_status_none)
        binding.btnReplaceKey.setText(if (has) R.string.replace_key else R.string.add_key)
        binding.btnRemoveKey.isEnabled = has
    }

    private fun confirmRemoveKey() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.remove_key)
            .setMessage(R.string.remove_key_confirm)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.remove_key) { _, _ ->
                try {
                    nrbApp.keyStore.clear()
                    toast(getString(R.string.key_removed))
                } catch (e: Exception) {
                    toast(getString(R.string.key_remove_failed))
                }
                refreshKeyStatus()
            }
            .show()
    }
}
