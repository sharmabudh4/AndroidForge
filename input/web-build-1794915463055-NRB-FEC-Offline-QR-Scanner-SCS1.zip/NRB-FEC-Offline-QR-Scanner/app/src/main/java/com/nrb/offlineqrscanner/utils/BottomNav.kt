package com.nrb.offlineqrscanner.utils

import android.app.Activity
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.screens.settings.SettingsActivity

/** Wires the shared bottom navigation bar used by Home, Scanner and Settings. */
fun Activity.setupBottomNav(view: BottomNavigationView, current: Int) {
    view.selectedItemId = current
    view.setOnItemSelectedListener { item ->
        if (item.itemId == current) return@setOnItemSelectedListener true
        val target = when (item.itemId) {
            R.id.nav_home -> HomeActivity::class.java
            R.id.nav_scanner -> ScanQRActivity::class.java
            R.id.nav_settings -> SettingsActivity::class.java
            else -> return@setOnItemSelectedListener false
        }
        startActivity(Intent(this, target))
        if (target != ScanQRActivity::class.java) {
            overridePendingTransition(0, 0)
            finish()
        }
        true
    }
}
