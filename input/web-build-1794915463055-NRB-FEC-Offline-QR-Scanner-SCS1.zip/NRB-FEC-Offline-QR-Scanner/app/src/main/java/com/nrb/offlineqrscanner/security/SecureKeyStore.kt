package com.nrb.offlineqrscanner.security

/** Raw persistence of one opaque (already encrypted) blob, e.g. a private SharedPreferences entry. */
interface BlobStorage {
    fun read(): ByteArray?
    fun write(blob: ByteArray)
    fun remove()
}

/** Thrown by [SecureKeyStore.load] when a key is stored but can no longer be read back. */
class SavedKeyUnreadableException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** Holds the one AES-256 security key the user entered. */
interface SecureKeyStore {
    fun hasKey(): Boolean
    /** @param key exactly 32 bytes. */
    fun save(key: ByteArray)
    /** Returns null if no key is saved; throws [SavedKeyUnreadableException] if it cannot be decrypted. Caller should zero the result. */
    fun load(): ByteArray?
    /** Deletes the saved key (and the Keystore key that protects it). */
    fun clear()
}

/**
 * The AES key is only ever stored as an AES-GCM encrypted blob, protected by a non-exportable
 * Android Keystore key (see [KeystoreSecretKeyProvider]). Entirely local; nothing is transmitted.
 */
class EncryptedKeyStore(
    private val storage: BlobStorage,
    private val cipher: SecretCipher
) : SecureKeyStore {

    override fun hasKey(): Boolean = storage.read() != null

    override fun save(key: ByteArray) {
        require(key.size == AesKeyParser.KEY_BYTES) { "AES-256 key must be 32 bytes" }
        storage.write(cipher.encrypt(key))
    }

    override fun load(): ByteArray? {
        val blob = storage.read() ?: return null
        val plain = try {
            cipher.decrypt(blob)
        } catch (e: SecretDecryptionException) {
            throw SavedKeyUnreadableException("Saved key cannot be decrypted", e)
        }
        if (plain.size != AesKeyParser.KEY_BYTES) {
            plain.fill(0)
            throw SavedKeyUnreadableException("Saved key has the wrong length")
        }
        return plain
    }

    override fun clear() {
        try {
            storage.remove()
        } finally {
            cipher.destroyKey() // even if removal failed, the blob becomes undecryptable
        }
    }
}
