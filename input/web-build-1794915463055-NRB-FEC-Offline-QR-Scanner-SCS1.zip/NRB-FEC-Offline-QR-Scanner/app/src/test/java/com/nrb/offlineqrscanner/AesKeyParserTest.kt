package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.AesKeyParser
import com.nrb.offlineqrscanner.security.Base64Lenient
import org.junit.Assert.*
import org.junit.Test

class AesKeyParserTest {
    private val key = ByteArray(32) { (it + 1).toByte() }
    private val hexKey = key.joinToString("") { "%02x".format(it) }
    @Test fun parsesHexAnyCaseAndWhitespace() {
        assertArrayEquals(key, AesKeyParser.parse(hexKey)); assertArrayEquals(key, AesKeyParser.parse(hexKey.uppercase()))
        assertArrayEquals(key, AesKeyParser.parse("  ${hexKey.take(32)}\r\n${hexKey.drop(32)}\n "))
    }
    @Test fun parsesBase64StandardUrlSafeAndPadded() {
        val url = TestScs1.b64u(key); assertEquals(43, url.length)
        assertArrayEquals(key, AesKeyParser.parse(url)); assertArrayEquals(key, AesKeyParser.parse(url + "="))
        assertArrayEquals(key, AesKeyParser.parse(url.replace('-', '+').replace('_', '/')))
        assertArrayEquals(key, AesKeyParser.parse(java.util.Base64.getEncoder().encodeToString(key)))
    }
    @Test fun rejectsBadKeysWithAUserMessage() {
        for (bad in listOf("", "   ", "abc", hexKey.drop(1), hexKey + "0", "z".repeat(64), "0".repeat(64), "A".repeat(43) .replace('A','!'), hexKey.take(40)))
            try { AesKeyParser.parse(bad); fail("accepted '$bad'") } catch (e: IllegalArgumentException) { assertTrue(e.message!!.isNotBlank()) }
    }
    @Test fun base64DecoderMatchesJavaForManyLengths() {
        val r = java.util.Random(1)
        for (len in 1..70) { val b = ByteArray(len).also { r.nextBytes(it) }
            assertArrayEquals(b, Base64Lenient.decode(java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(b)))
            assertArrayEquals(b, Base64Lenient.decode(java.util.Base64.getEncoder().encodeToString(b))) }
        assertNull(Base64Lenient.decode("")); assertNull(Base64Lenient.decode("A")); assertNull(Base64Lenient.decode("AAAAA")); assertNull(Base64Lenient.decode("AA*A"))
    }
}
