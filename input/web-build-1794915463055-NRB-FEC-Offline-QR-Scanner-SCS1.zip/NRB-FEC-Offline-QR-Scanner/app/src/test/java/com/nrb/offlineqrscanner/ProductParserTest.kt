package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.Product
import com.nrb.offlineqrscanner.security.ProductParser
import org.junit.Assert.*
import org.junit.Test

class ProductParserTest {
    @Test fun parsesJson() = assertEquals(Product("1001", "LED Bulb 9W", "80"), ProductParser.parse("""{"serial":"1001","name":"LED Bulb 9W","price":"80"}"""))
    @Test fun parsesNumericPriceAndAlternateKeys() {
        assertEquals(Product("7", "Bell", "99.5"), ProductParser.parse("""{"serial_number":7,"product_name":"Bell","price":99.5}"""))
        assertEquals(Product("S1", "Tyre", "450"), ProductParser.parse("""{"serial_no":"S1","product":"Tyre","product_price":"450"}"""))
    }
    @Test fun parsesLegacyLineAndStripsCurrency() {
        assertEquals(Product("1003", "Cycle Tyre 26\"", "450"), ProductParser.parse("Serial No: 1003, Product Name: Cycle Tyre 26\", Price: Rs. 450"))
        assertEquals(Product("1", "A", "80"), ProductParser.parse("Serial No: 1, Product Name: A, Price: ₹80"))
        assertEquals(Product("1", "A", "80"), ProductParser.parse("Serial No: 1, Product Name: A, Price: 80"))
        assertEquals(Product("1", "A", "80"), ProductParser.parse("""{"serial":"1","name":"A","price":"Rs 80"}"""))
    }
    @Test fun legacyLineKeepsCommasInsideTheName() =
        assertEquals(Product("1004", "Bell, steel, chrome", "60"), ProductParser.parse("Serial No: 1004, Product Name: Bell, steel, chrome, Price: Rs. 60"))
    @Test fun keepsUnicode() = assertEquals(Product("SN-७७", "साइकिल घंटी é", "1,250.00"), ProductParser.parse("""{"serial":"SN-७७","name":"साइकिल घंटी é","price":"1,250.00"}"""))
    @Test fun rejectsMissingEmptyOrWrongShapes() {
        for (bad in listOf("", "hello", "[]", "{}", "{", """{"serial":"1","name":"A"}""", """{"serial":"","name":"A","price":"1"}""", """{"serial":"1","name":"  ","price":"1"}""",
            """{"serial":"1","name":"A","price":""}""", """{"serial":["1"],"name":"A","price":"1"}""", """{"serial":{"x":1},"name":"A","price":"1"}""", "Serial No: 1, Product Name: A", "Serial No: , Product Name: A, Price: 1",
            """{"serial":"${"x".repeat(201)}","name":"A","price":"1"}"""))
            assertNull("accepted: $bad", ProductParser.parse(bad))
    }
}
