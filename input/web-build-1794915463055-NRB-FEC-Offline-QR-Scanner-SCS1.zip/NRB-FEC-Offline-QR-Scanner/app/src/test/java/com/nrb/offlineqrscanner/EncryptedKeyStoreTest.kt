package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.*
import org.junit.Assert.*
import org.junit.Test

class EncryptedKeyStoreTest {
    private val keys = InMemoryKeyProvider(); private val storage = InMemoryBlobStorage()
    private val store = EncryptedKeyStore(storage, AesGcmCipher(keys))
    private val key = ByteArray(32) { (it * 7 + 3).toByte() }
    private fun contains(hay: ByteArray, needle: ByteArray) = String(hay, Charsets.ISO_8859_1).contains(String(needle, Charsets.ISO_8859_1))

    @Test fun nothingSavedMeansNoKey() { assertFalse(store.hasKey()); assertNull(store.load()) }
    @Test fun saveThenLoadRoundTripsAndHasKey() { store.save(key); assertTrue(store.hasKey()); assertArrayEquals(key, store.load()) }
    @Test fun storedBytesAreEncrypted_noPlaintextKeyAnywhere() {
        store.save(key); val raw = storage.blob!!
        assertFalse(contains(raw, key)); assertFalse(contains(raw, key.copyOf(16))); assertFalse(contains(raw, key.copyOfRange(16, 32)))
        assertFalse(contains(raw, key.joinToString("") { "%02x".format(it) }.toByteArray()))
    }
    @Test fun freshIvEachSave() { store.save(key); val a = storage.blob!!; store.save(key); assertFalse(a.contentEquals(storage.blob!!)) }
    @Test fun replaceKey() { store.save(key); val k2 = ByteArray(32) { 9 }; store.save(k2); assertArrayEquals(k2, store.load()) }
    @Test fun clearDeletesBlobAndWrappingKey() {
        store.save(key); val old = storage.blob!!; store.clear()
        assertFalse(store.hasKey()); assertNull(store.load()); assertEquals(1, keys.deleteCalls)
        try { AesGcmCipher(keys).decrypt(old); fail() } catch (e: SecretDecryptionException) { }
        store.save(key); assertArrayEquals(key, store.load()) // can save again after clear
    }
    @Test fun tamperedLostKeyAndGarbageAreReportedUnreadable() {
        store.save(key); val b = storage.blob!!; b[b.size - 1] = (b[b.size - 1].toInt() xor 1).toByte(); storage.blob = b
        try { store.load(); fail() } catch (e: SavedKeyUnreadableException) { }
        store.save(key); keys.key = null
        try { store.load(); fail() } catch (e: SavedKeyUnreadableException) { }
        for (junk in listOf(ByteArray(0), byteArrayOf(1), ByteArray(60) { 5 })) { storage.blob = junk
            try { store.load(); fail() } catch (e: SavedKeyUnreadableException) { } }
    }
    @Test fun onlyExactly32BytesAreAccepted() {
        for (n in intArrayOf(0, 16, 31, 33, 64)) try { store.save(ByteArray(n)); fail("saved $n bytes") } catch (e: IllegalArgumentException) { }
        // an authentic blob holding the wrong length is "unreadable", not a short key
        storage.blob = AesGcmCipher(keys).encrypt(ByteArray(10) { 1 })
        try { store.load(); fail() } catch (e: SavedKeyUnreadableException) { }
    }
}
