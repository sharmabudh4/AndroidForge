package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.ScanResult.Kind
import com.nrb.offlineqrscanner.security.AesGcmCipher
import com.nrb.offlineqrscanner.security.EncryptedKeyStore
import com.nrb.offlineqrscanner.security.Product
import org.junit.Assert.*
import org.junit.Test

class ScanDecoderTest {
    private val v = Vectors.load()
    private fun plainText(r: ScanResult) = (r as ScanResult.Plain).text
    private fun failure(r: ScanResult) = (r as ScanResult.Failure).kind

    @Test fun ordinaryQrCodesAreShownUnchanged_evenWithoutAKey() {
        val d = ScanDecoder(FakeKeyStore())
        for (t in listOf("https://example.com/a?b=1", "hello world", "WIFI:T:WPA;S:net;P:pw;;", "BEGIN:VCARD\nFN:A\nEND:VCARD", """{"a":1}""", "Serial No: 1, Product Name: A, Price: Rs. 5",
            "scs1.lowercase", "SCS1", "SCS1x", " SCS1.leading-space", "", "ünïcødé ✓", "x".repeat(3000)))
            assertEquals(t, plainText(d.process(t)))
    }
    @Test fun scs1DecryptsToProductDetails() {
        val d = ScanDecoder(FakeKeyStore(v.key))
        val r = d.process(v.items[0].qr) as ScanResult.ProductInfo
        assertEquals(Product("1001", "LED Bulb 9W", "80"), r.product)
        assertEquals(Product("1004", "Bell, steel, chrome", "60"), (d.process(v.items[4].qr) as ScanResult.ProductInfo).product)
    }
    @Test fun scs1WithoutKeyIsAnErrorNotPlainText() = assertEquals(Kind.NO_KEY, failure(ScanDecoder(FakeKeyStore()).process(v.items[0].qr)))
    @Test fun scs1WithWrongKeyIsAnErrorAndNeverEchoesThePayload() {
        val r = ScanDecoder(FakeKeyStore(v.wrongKey)).process(v.items[0].qr)
        assertEquals(Kind.WRONG_KEY_OR_INVALID, failure(r))
    }
    @Test fun invalidAndTamperedScs1AreErrors() {
        val d = ScanDecoder(FakeKeyStore(v.key))
        assertEquals(Kind.MALFORMED, failure(d.process("SCS1.")))
        assertEquals(Kind.MALFORMED, failure(d.process("SCS1.not base64 !!")))
        assertEquals(Kind.WRONG_KEY_OR_INVALID, failure(d.process(v.items[0].qr.dropLast(3) + "AAA")))
    }
    @Test fun decryptedButNotAProductIsReportedAsSuch() {
        val d = ScanDecoder(FakeKeyStore(v.key))
        assertEquals(Kind.NOT_PRODUCT, failure(d.process(TestScs1.encrypt(v.key, """{"hello":"world"}"""))))
        assertEquals(Kind.NOT_PRODUCT, failure(d.process(TestScs1.encrypt(v.key, "just text"))))
    }
    @Test fun unreadableSavedKeyIsReported() = assertEquals(Kind.KEY_UNREADABLE, failure(ScanDecoder(FakeKeyStore(v.key, unreadable = true)).process(v.items[0].qr)))
    @Test fun worksEndToEndWithTheRealEncryptedKeyStore() {
        val store = EncryptedKeyStore(InMemoryBlobStorage(), AesGcmCipher(InMemoryKeyProvider()))
        val d = ScanDecoder(store)
        assertEquals(Kind.NO_KEY, failure(d.process(v.items[0].qr)))
        store.save(v.key)
        assertEquals("1001", (d.process(v.items[0].qr) as ScanResult.ProductInfo).product.serial)
        store.save(v.wrongKey)
        assertEquals(Kind.WRONG_KEY_OR_INVALID, failure(d.process(v.items[0].qr)))
        store.clear()
        assertEquals(Kind.NO_KEY, failure(d.process(v.items[0].qr)))
        assertEquals("plain", plainText(d.process("plain"))) // ordinary QR codes unaffected by key state
    }
    @Test fun decoderDoesNotRetainOrCorruptTheStoredKey() {
        val store = FakeKeyStore(v.key); val d = ScanDecoder(store)
        repeat(3) { d.process(v.items[0].qr) }
        assertArrayEquals(v.key, store.key)
    }
}
