#!/usr/bin/env python3
"""
Reference encoder for the SCS1 QR format read by this Android app (see docs/SCS1_FORMAT.md).

It exists so you can make test QR codes for the phone and so the format is checkable with a crypto
library that is independent of the app. It is NOT your QR Generator and does not replace it.

  QR text = "SCS1." + Base64URL(nonce[12] || ciphertext || tag[16])   (no padding)
  cipher  = AES-256-GCM, 128-bit tag, AAD = ASCII "SCS1", fresh random 12-byte nonce per QR

Examples
  python scs1_encrypt.py --gen-key                              # new random 64-hex-character key
  python scs1_encrypt.py --key <64 hex> --serial 1001 --name "LED Bulb 9W" --price 80
  python scs1_encrypt.py --key <64 hex> --serial 1001 --name "LED Bulb 9W" --price 80 --png label.png
  python scs1_encrypt.py --key <64 hex> --decrypt "SCS1.xxxxx"  # check a QR text
Needs:  pip install cryptography      (and, only for --png:  pip install "qrcode[pil]")
"""
import argparse, base64, json, os, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

PREFIX = "SCS1."
AAD = b"SCS1"


def parse_key(text: str) -> bytes:
    t = "".join(text.split())
    if len(t) == 64:
        key = bytes.fromhex(t)
    elif len(t) in (43, 44):
        key = base64.urlsafe_b64decode(t.replace("+", "-").replace("/", "_").rstrip("=") + "=" * (-len(t.rstrip("=")) % 4))
    else:
        raise ValueError("key must be 64 hex characters (or 43 Base64 characters)")
    if len(key) != 32:
        raise ValueError("key must be 32 bytes")
    return key


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def encrypt(key: bytes, plaintext: bytes, nonce: bytes = None) -> str:
    nonce = nonce if nonce is not None else os.urandom(12)   # nonce is only injectable for known-answer tests
    assert len(nonce) == 12
    return PREFIX + b64u(nonce + AESGCM(key).encrypt(nonce, plaintext, AAD))


def decrypt(key: bytes, qr: str) -> bytes:
    if not qr.startswith(PREFIX):
        raise ValueError("not an SCS1 QR")
    body = qr[len(PREFIX):]
    raw = base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
    return AESGCM(key).decrypt(raw[:12], raw[12:], AAD)   # raises InvalidTag on wrong key / tampering


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gen-key", action="store_true")
    ap.add_argument("--key"); ap.add_argument("--key-file")
    ap.add_argument("--serial"); ap.add_argument("--name"); ap.add_argument("--price")
    ap.add_argument("--legacy-line", action="store_true", help='encrypt "Serial No: .., Product Name: .., Price: Rs. .." instead of JSON')
    ap.add_argument("--decrypt", metavar="QR_TEXT"); ap.add_argument("--png")
    a = ap.parse_args()
    if a.gen_key:
        print(os.urandom(32).hex()); return
    key = parse_key(a.key if a.key else open(a.key_file).read()) if (a.key or a.key_file) else sys.exit("give --key or --key-file")
    if a.decrypt:
        print(decrypt(key, a.decrypt).decode("utf-8")); return
    if not (a.serial and a.name and a.price):
        sys.exit("give --serial, --name and --price")
    plain = (f"Serial No: {a.serial}, Product Name: {a.name}, Price: Rs. {a.price}" if a.legacy_line
             else json.dumps({"serial": a.serial, "name": a.name, "price": a.price}, ensure_ascii=False, separators=(",", ":")))
    text = encrypt(key, plain.encode("utf-8"))
    print(text)
    if a.png:
        try:
            import qrcode
        except ImportError:
            sys.exit('--png needs:  pip install "qrcode[pil]"   (or paste the text above into any QR generator)')
        qrcode.make(text).save(a.png); print("saved", a.png, file=sys.stderr)


if __name__ == "__main__":
    main()
