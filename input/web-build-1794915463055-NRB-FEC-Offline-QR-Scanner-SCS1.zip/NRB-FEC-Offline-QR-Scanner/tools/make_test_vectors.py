#!/usr/bin/env python3
"""Writes app/src/test/resources/scs1_vectors.json with fixed key/nonces, made by the independent Python encoder."""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
import scs1_encrypt as S

key = bytes(range(1, 33))
wrong = bytes(range(200, 168, -1))
plain = {
  "json_basic": json.dumps({"serial": "1001", "name": "LED Bulb 9W", "price": "80"}, separators=(",", ":")),
  "json_decimal_price_number": '{"serial":"1002","name":"LED Bulb 12W","price":99.5}',
  "json_unicode": json.dumps({"serial": "SN-७७", "name": "साइकिल घंटी \u00e9 \"bell\", 2-pack", "price": "1,250.00"}, ensure_ascii=False, separators=(",", ":")),
  "legacy_line": "Serial No: 1003, Product Name: Cycle Tyre 26\", Price: Rs. 450",
  "legacy_line_name_with_comma": "Serial No: 1004, Product Name: Bell, steel, chrome, Price: Rs. 60",
}
vectors = []
for i, (name, p) in enumerate(plain.items()):
    nonce = bytes([i + 1] * 12)  # fixed only for this known-answer file
    vectors.append({"name": name, "nonce_hex": nonce.hex(), "plaintext": p, "qr": S.encrypt(key, p.encode("utf-8"), nonce)})
out = {"key_hex": key.hex(), "wrong_key_hex": wrong.hex(), "aad": "SCS1", "vectors": vectors}
path = os.path.join(os.path.dirname(__file__), "..", "app", "src", "test", "resources", "scs1_vectors.json")
json.dump(out, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("wrote", os.path.normpath(path), len(vectors), "vectors")
