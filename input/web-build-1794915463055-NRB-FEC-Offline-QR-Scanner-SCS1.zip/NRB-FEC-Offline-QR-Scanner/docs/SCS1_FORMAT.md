# SCS1 encrypted QR format

> **Status: this format is defined by this app, not read from your QR Generator.**
> The Sharma Cycle Store QR Generator HTML file that was supplied produces *plain-text* QR codes
> (`Serial No: 1001, Product Name: LED Bulb 9W, Price: Rs. 80`). It contains no encryption, no key and no
> `SCS1.` prefix, so there was no existing encryption format to copy. The values below are therefore a
> specification chosen for this app. The generator must produce exactly this to work with the app, or the
> constants in `Scs1Codec.kt` must be changed to match the generator (see "If your generator differs").

## QR text

```
SCS1.<Base64URL( nonce[12] || ciphertext || tag[16] )>
```

| Part | Value |
|------|-------|
| Version / prefix | the literal text `SCS1.` (case-sensitive, must be the very first characters) |
| Encoding | Base64URL alphabet (`A-Z a-z 0-9 - _`), no padding when writing. The app also reads padded and standard (`+ /`) Base64. |
| Cipher | AES-256-GCM, 128-bit authentication tag |
| Key | 32 bytes, shared by the generator and the phone. Never placed in a QR code. |
| Nonce (IV) | 12 random bytes, a new one for every QR code, stored first in the payload |
| Ciphertext + tag | exactly what Web Crypto `AES-GCM` returns (ciphertext followed by the 16-byte tag), which is also what Java/Android `AES/GCM/NoPadding` expects |
| AAD (additional authenticated data) | the 4 ASCII bytes `SCS1` (no dot, no terminator) |
| Plaintext | UTF-8, either a JSON object (preferred) or the legacy line, see below |

Anything that does **not** start with `SCS1.` is treated as an ordinary QR code and shown unchanged.
Anything that starts with `SCS1.` is never shown as plain text: it is decrypted or it is an error.

## Plaintext

JSON object (preferred; `price` may be a string or a number):

```json
{"serial":"1001","name":"LED Bulb 9W","price":"80"}
```

Also accepted as key names: `serial_no` / `serial_number` / `sn`, `product_name` / `product`, `product_price`.
A leading `Rs`, `Rs.`, `INR` or `₹` in the price is ignored (the app shows `₹` itself).

Legacy line (the text your current generator puts into its plain QR codes, encrypted instead):

```
Serial No: 1001, Product Name: LED Bulb 9W, Price: Rs. 80
```

All three fields are required and non-empty (max 200 characters each); otherwise the app reports that the
decrypted QR does not contain a serial number, product name and price.

## Key text (what you paste into the app)

64 hexadecimal characters, or 43/44 characters of Base64 / Base64URL. Spaces and line breaks are ignored.

## Reference code and test vectors

* `tools/scs1_encrypt.py` is a reference encoder (Python `cryptography`) for making test QR codes.
* `app/src/test/resources/scs1_vectors.json` holds fixed-key, fixed-nonce vectors from that encoder.
* Verified here, on a plain JVM / Node / Python (not on a phone and not with your generator):
  the app's decoder decrypts the Python vectors; Node Web Crypto output is byte-identical to Python's for the
  same key/nonce/plaintext; QR texts made by Node Web Crypto and by Kotlin/JCE decrypt in the app's decoder
  and in Python; a wrong key, any flipped bit, truncation, a different AAD or a different prefix is rejected.

## If your generator differs

Everything that defines the wire format is in one file, `app/src/main/java/com/nrb/offlineqrscanner/security/Scs1Codec.kt`
(prefix, nonce length, tag length, AAD, Base64 alphabet). If your real generator uses a different layout
(for example a different AAD, the nonce after the ciphertext, or Base64 with padding), send me its source or
its exact byte layout and only that file and the test vectors need to change.
