package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.AesGcmCipher
import com.nrb.offlineqrscanner.service.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

/** Tasks 1-4: save after login, silent restore, ask only when needed, logout clears. Real AuthService + UserService. */
class AuthServiceTest {
    private class Env(val store: CredentialStore = FakeCredentialStore()) {
        val users = UserService(FakeUserRepo())
        val session = Session()
        val auth = AuthService(users, store, session)
    }

    private fun env(store: CredentialStore = FakeCredentialStore()) = Env(store).also {
        runBlocking {
            it.users.createFirstAdmin("admin", "admin-pass-1".toCharArray())
            it.users.createUser("alice", "alice-pass-1".toCharArray(), isAdmin = false)
            it.users.changePassword("alice", "alice-pass-1".toCharArray()) // clears must-change
        }
    }

    @Test fun firstSuccessfulLoginSavesCredentialsAndStartsSession() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        assertNull(store.saved)
        assertEquals(LoginResult.Success(false, false), e.auth.login(" alice ", "alice-pass-1".toCharArray()))
        assertEquals("alice" to "alice-pass-1", store.saved)
        assertEquals("alice", e.session.userId)
    }

    @Test fun failedLoginSavesNothingAndStartsNoSession() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        assertEquals(LoginResult.InvalidCredentials, e.auth.login("alice", "wrong-password".toCharArray()))
        assertNull(store.saved); assertFalse(e.session.isLoggedIn)
        e.users.setActive("admin", "alice", false)
        assertEquals(LoginResult.AccountDeactivated, e.auth.login("alice", "alice-pass-1".toCharArray()))
        assertNull(store.saved); assertFalse(e.session.isLoggedIn)
    }

    @Test fun temporaryPasswordIsNotSavedUntilItIsChanged() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.users.createUser("bob", "temp-pass-1".toCharArray(), false) // must change at first login
        val r = e.auth.login("bob", "temp-pass-1".toCharArray()) as LoginResult.Success
        assertTrue(r.mustChangePassword)
        assertNull(store.saved)
        e.users.changePassword("bob", "bobs-own-pass".toCharArray())
        e.auth.onPasswordChanged("bob", "bobs-own-pass".toCharArray())
        assertEquals("bob" to "bobs-own-pass", store.saved)
    }

    @Test fun nothingSavedMeansLoginFormIsNeeded() = runBlocking {
        assertEquals(RestoreResult.NoSavedCredentials, env().auth.restoreSession())
    }

    @Test fun nextLaunchRestoresWithoutAskingForCredentials() = runBlocking {
        val e = env()
        e.auth.login("alice", "alice-pass-1".toCharArray())
        // "app restart": a brand-new in-memory Session, same persisted store + same account DB
        val relaunch = AuthService(e.users, e.store, Session())
        val session2 = Session(); val auth2 = AuthService(e.users, e.store, session2)
        assertEquals(RestoreResult.Restored(isAdmin = false, mustChangePassword = false), auth2.restoreSession())
        assertEquals("alice", session2.userId); assertFalse(session2.isAdmin)
        assertNotNull(relaunch)
    }

    @Test fun restoredAdminKeepsAdminRole() = runBlocking {
        val e = env(); e.auth.login("admin", "admin-pass-1".toCharArray())
        val s = Session()
        assertEquals(RestoreResult.Restored(true, false), AuthService(e.users, e.store, s).restoreSession())
        assertTrue(s.isAdmin)
    }

    @Test fun restoreFailsAndClearsWhenPasswordWasChangedElsewhere() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        e.users.resetPassword("alice", "admin-set-temp".toCharArray()) // admin reset
        val s = Session()
        assertEquals(RestoreResult.Failed(RestoreFailure.INVALID_CREDENTIALS), AuthService(e.users, store, s).restoreSession())
        assertNull(store.saved); assertFalse(s.isLoggedIn)
        assertEquals(RestoreResult.NoSavedCredentials, AuthService(e.users, store, Session()).restoreSession()) // asks only once
    }

    @Test fun restoreFailsAndClearsWhenAccountDeactivated() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        e.users.setActive("admin", "alice", false)
        val s = Session()
        assertEquals(RestoreResult.Failed(RestoreFailure.ACCOUNT_DEACTIVATED), AuthService(e.users, store, s).restoreSession())
        assertNull(store.saved); assertFalse(s.isLoggedIn)
    }

    @Test fun unreadableSavedLoginIsClearedAndUserIsAsked() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        store.unreadable = true
        val s = Session()
        assertEquals(RestoreResult.Failed(RestoreFailure.SAVED_LOGIN_UNREADABLE), AuthService(e.users, store, s).restoreSession())
        assertTrue(store.clearCalls > 0); assertFalse(s.isLoggedIn)
    }

    @Test fun logoutEndsSessionAndDeletesSavedLogin() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        e.auth.logout()
        assertFalse(e.session.isLoggedIn); assertNull(store.saved)
        assertEquals(RestoreResult.NoSavedCredentials, AuthService(e.users, store, Session()).restoreSession())
    }

    @Test fun logoutStillEndsSessionIfClearingStorageThrows() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        store.failClear = true
        e.auth.logout()
        assertFalse(e.session.isLoggedIn)
    }

    @Test fun loginStillWorksIfSecureStorageIsUnavailable() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        store.failSave = true
        assertTrue(e.auth.login("alice", "alice-pass-1".toCharArray()) is LoginResult.Success)
        assertTrue(e.session.isLoggedIn); assertNull(store.saved)
    }

    @Test fun changingOwnPasswordUpdatesSavedLoginSoNextLaunchStillRestores() = runBlocking {
        val e = env(); val store = e.store as FakeCredentialStore
        e.auth.login("alice", "alice-pass-1".toCharArray())
        e.users.changePassword("alice", "alice-new-pass".toCharArray())
        e.auth.onPasswordChanged("alice", "alice-new-pass".toCharArray())
        assertTrue(AuthService(e.users, store, Session()).restoreSession() is RestoreResult.Restored)
    }

    @Test fun restoreWhenSessionAlreadyActiveDoesNotTouchStore() = runBlocking {
        val e = env(); e.auth.login("alice", "alice-pass-1".toCharArray())
        assertEquals(RestoreResult.AlreadyLoggedIn(false), e.auth.restoreSession())
    }

    @Test fun endToEndWithRealEncryptedStore() = runBlocking {
        val storage = InMemoryBlobStorage(); val keys = InMemoryKeyProvider()
        val real = EncryptedCredentialStore(storage, AesGcmCipher(keys))
        val e = env(real)
        e.auth.login("alice", "alice-pass-1".toCharArray())
        assertNotNull(storage.blob)
        assertFalse(String(storage.blob!!, Charsets.ISO_8859_1).contains("alice-pass-1"))
        val s = Session()
        assertTrue(AuthService(e.users, real, s).restoreSession() is RestoreResult.Restored)
        assertEquals("alice", s.userId)
        AuthService(e.users, real, s).logout()
        assertNull(storage.blob); assertNull(keys.key)
    }
}
