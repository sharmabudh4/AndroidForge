package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.service.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.util.Base64

/**
 * Task 5/6: a session restored from the saved login is authorized exactly like a typed login - only the
 * logged-in User ID vs the device's authorized User ID decides; signature/registration/active checks unchanged.
 */
class RestoredSessionAuthorizationTest {
    private val b64: (String) -> ByteArray = { Base64.getMimeDecoder().decode(it) }
    private val res = { n: String -> javaClass.classLoader!!.getResource(n)!!.readText() }
    private val key by lazy { PemUtils.parsePublicKey(res("public.pem"), b64) }

    private class Fixture(val mgr: AuthorizationManager, val devices: FakeDeviceRepo, val audit: FakeScanAuditRepo)
    private fun fixture(authorized: String, active: Boolean = true, register: Boolean = true): Fixture {
        val devices = FakeDeviceRepo(); val audit = FakeScanAuditRepo()
        if (register) runBlocking { devices.insert(DeviceRegistration("NRB-DEV-001", "POS", authorized, null, null, emptyList(), "admin", 0, null, active)) }
        return Fixture(AuthorizationManager(devices, audit, FakeKeyStore(key), FakeSettings(false), PayloadAuthenticator(SignatureVerifier(b64))), devices, audit)
    }

    private suspend fun restoredUser(userId: String): String {
        val users = UserService(FakeUserRepo()); users.createFirstAdmin("admin", "admin-pass-1".toCharArray())
        users.createUser(userId, "user-pass-1".toCharArray(), false); users.changePassword(userId, "user-pass-1".toCharArray())
        val store = FakeCredentialStore()
        AuthService(users, store, Session()).login(userId, "user-pass-1".toCharArray())
        val s = Session(); AuthService(users, store, s).restoreSession()
        return s.userId!!
    }

    @Test fun restoredUserMatchingDeviceUserIsGranted() = runBlocking {
        val f = fixture("alice")
        assertTrue(f.mgr.authorize(res("qr_signed.json"), restoredUser("alice")) is ScanOutcome.Granted)
    }

    @Test fun restoredUserNotMatchingDeviceUserIsDenied() = runBlocking {
        val f = fixture("bob")
        val d = f.mgr.authorize(res("qr_signed.json"), restoredUser("alice")) as ScanOutcome.Denied
        assertEquals("User ID does not match the authorized User ID", d.reason)
    }

    @Test fun unchangedChecks_unregisteredAndDeactivatedDevicesStillDenied() = runBlocking {
        val u = restoredUser("alice")
        assertTrue(fixture("alice", register = false).mgr.authorize(res("qr_signed.json"), u) is ScanOutcome.Denied)
        assertTrue(fixture("alice", active = false).mgr.authorize(res("qr_signed.json"), u) is ScanOutcome.Denied)
    }

    @Test fun unchangedChecks_tamperedSignatureStillDeniedForMatchingUser() = runBlocking {
        val f = fixture("alice")
        val tampered = res("qr_signed.json").replace("Point-of-Sale Terminal", "Evil Terminal")
        assertNotEquals(res("qr_signed.json"), tampered)
        assertTrue(f.mgr.authorize(tampered, restoredUser("alice")) is ScanOutcome.Denied)
    }
}
