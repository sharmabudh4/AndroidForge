package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.AesGcmCipher
import com.nrb.offlineqrscanner.security.SecretDecryptionException
import com.nrb.offlineqrscanner.service.CredentialStoreException
import com.nrb.offlineqrscanner.service.EncryptedCredentialStore
import com.nrb.offlineqrscanner.service.SavedCredentials
import org.junit.Assert.*
import org.junit.Test

/** Task 1: saved login is stored encrypted - exercised on the real AesGcmCipher / EncryptedCredentialStore. */
class EncryptedCredentialStoreTest {
    private val keys = InMemoryKeyProvider()
    private val storage = InMemoryBlobStorage()
    private val store = EncryptedCredentialStore(storage, AesGcmCipher(keys))

    private fun contains(hay: ByteArray, needle: String) =
        String(hay, Charsets.ISO_8859_1).contains(String(needle.toByteArray(), Charsets.ISO_8859_1))

    @Test fun roundTripsUserIdAndPassword() {
        store.save("alice.k", "p@ss w0rd ünïcode✓".toCharArray())
        val loaded = store.load()!!
        assertEquals("alice.k", loaded.userId)
        assertEquals("p@ss w0rd ünïcode✓", String(loaded.password))
    }

    @Test fun nothingSavedLoadsNull() { assertNull(store.load()) }

    @Test fun persistedBytesContainNeitherUserIdNorPasswordInPlaintext() {
        store.save("alice.k", "SuperSecret-123".toCharArray())
        val raw = storage.blob!!
        assertFalse(contains(raw, "alice.k"))
        assertFalse(contains(raw, "SuperSecret-123"))
        assertFalse(contains(raw, "SuperSecret"))
    }

    @Test fun eachEncryptionUsesAFreshIv() {
        store.save("alice", "same-password".toCharArray()); val a = storage.blob!!
        store.save("alice", "same-password".toCharArray()); val b = storage.blob!!
        assertFalse(a.contentEquals(b))
    }

    @Test fun saveOverwritesPreviousLogin() {
        store.save("alice", "old-password".toCharArray())
        store.save("alice", "new-password".toCharArray())
        assertEquals("new-password", String(store.load()!!.password))
    }

    @Test fun clearRemovesBlobAndDestroysKey() {
        store.save("alice", "pw-123456".toCharArray())
        val oldBlob = storage.blob!!
        store.clear()
        assertNull(storage.blob)
        assertNull(store.load())
        assertEquals(1, keys.deleteCalls)
        // Even a copy of the old blob is now undecryptable (key gone; a new key is generated on demand).
        try { AesGcmCipher(keys).decrypt(oldBlob); fail("old blob must not decrypt after clear()") } catch (e: SecretDecryptionException) { }
    }

    @Test fun tamperedBlobIsRejectedNotSilentlyAccepted() {
        store.save("alice", "pw-123456".toCharArray())
        val blob = storage.blob!!
        blob[blob.size - 1] = (blob[blob.size - 1].toInt() xor 1).toByte() // flip a bit in the GCM tag
        storage.blob = blob
        try { store.load(); fail("expected CredentialStoreException") } catch (e: CredentialStoreException) { }
    }

    @Test fun blobFromADifferentKeyCannotBeRead() {
        store.save("alice", "pw-123456".toCharArray())
        keys.key = null // simulates the Keystore key being lost/invalidated (new key generated on next use)
        try { store.load(); fail("expected CredentialStoreException") } catch (e: CredentialStoreException) { }
    }

    @Test fun garbageAndTruncatedBlobsAreRejected() {
        for (junk in listOf(ByteArray(0), byteArrayOf(1), byteArrayOf(9, 12, 1, 2, 3), ByteArray(64) { 7 })) {
            storage.blob = junk
            try { store.load(); fail("expected CredentialStoreException for ${junk.size} bytes") } catch (e: CredentialStoreException) { }
        }
    }

    @Test fun savedCredentialsToStringNeverShowsThePassword() {
        assertFalse(SavedCredentials("alice", "hunter2hunter2".toCharArray()).toString().contains("hunter2"))
    }
}
