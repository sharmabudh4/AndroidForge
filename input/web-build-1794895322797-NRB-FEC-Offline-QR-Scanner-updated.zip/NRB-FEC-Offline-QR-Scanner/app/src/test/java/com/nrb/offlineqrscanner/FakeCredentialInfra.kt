package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.SecretKeyProvider
import com.nrb.offlineqrscanner.service.BlobStorage
import com.nrb.offlineqrscanner.service.CredentialStore
import com.nrb.offlineqrscanner.service.SavedCredentials
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/** Software AES key standing in for the Android Keystore key (which cannot exist on a plain JVM). */
class InMemoryKeyProvider : SecretKeyProvider {
    var key: SecretKey? = null
    var deleteCalls = 0
    override fun getOrCreate(): SecretKey = key ?: KeyGenerator.getInstance("AES").apply { init(256) }.generateKey().also { key = it }
    override fun delete() { key = null; deleteCalls++ }
}

/** Stands in for the private SharedPreferences entry. */
class InMemoryBlobStorage : BlobStorage {
    var blob: ByteArray? = null
    override fun read(): ByteArray? = blob?.copyOf()
    override fun write(blob: ByteArray) { this.blob = blob.copyOf() }
    override fun remove() { blob = null }
}

/** Simple store double for AuthService tests, with switches to simulate storage failures. */
class FakeCredentialStore : CredentialStore {
    var saved: Pair<String, String>? = null
    var failSave = false
    var failClear = false
    var unreadable = false
    var clearCalls = 0
    override fun save(userId: String, password: CharArray) {
        if (failSave) throw java.io.IOException("keystore unavailable")
        saved = userId to String(password)
    }
    override fun load(): SavedCredentials? {
        if (unreadable) throw com.nrb.offlineqrscanner.service.CredentialStoreException("unreadable")
        return saved?.let { SavedCredentials(it.first, it.second.toCharArray()) }
    }
    override fun clear() { clearCalls++; if (failClear) throw java.io.IOException("boom"); saved = null }
}
