package com.nrb.offlineqrscanner.utils

import android.app.Activity
import android.content.Intent
import com.nrb.offlineqrscanner.screens.changepassword.ChangePasswordActivity
import com.nrb.offlineqrscanner.screens.home.HomeActivity

/** Opens Home - or the forced Change Password screen - after a login or a silent restore, then closes this screen. */
fun Activity.continueAfterLogin(mustChangePassword: Boolean) {
    if (mustChangePassword) {
        startActivity(Intent(this, ChangePasswordActivity::class.java).putExtra("required", true))
    } else {
        startActivity(Intent(this, HomeActivity::class.java))
    }
    finish()
}
