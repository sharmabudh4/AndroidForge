package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.security.SecretCipher
import com.nrb.offlineqrscanner.security.SecretDecryptionException
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/** Login saved on this phone after a successful sign-in. [toString] never reveals the password. */
class SavedCredentials(val userId: String, val password: CharArray) {
    override fun toString() = "SavedCredentials(userId=$userId, password=***)"
}

/** Thrown by [CredentialStore.load] when something is stored but cannot be read back. */
class CredentialStoreException(message: String, cause: Throwable? = null) : Exception(message, cause)

interface CredentialStore {
    fun save(userId: String, password: CharArray)
    /** Returns null if nothing is saved; throws [CredentialStoreException] if the saved data is unreadable. */
    fun load(): SavedCredentials?
    /** Removes the saved login (and the encryption key behind it). */
    fun clear()
}

/** Raw persistence of one opaque (already encrypted) blob, e.g. a private SharedPreferences entry. */
interface BlobStorage {
    fun read(): ByteArray?
    fun write(blob: ByteArray)
    fun remove()
}

/**
 * Keeps User ID + password only as an AES-GCM encrypted blob; plaintext exists only transiently in
 * memory. Fully local - no network involved.
 */
class EncryptedCredentialStore(
    private val storage: BlobStorage,
    private val cipher: SecretCipher
) : CredentialStore {

    override fun save(userId: String, password: CharArray) {
        val bytes = ByteArrayOutputStream()
        DataOutputStream(bytes).use { out ->
            out.writeByte(1) // format version
            out.writeUTF(userId)
            out.writeUTF(String(password))
        }
        val plain = bytes.toByteArray()
        try {
            storage.write(cipher.encrypt(plain))
        } finally {
            plain.fill(0)
        }
    }

    override fun load(): SavedCredentials? {
        val blob = storage.read() ?: return null
        val plain = try {
            cipher.decrypt(blob)
        } catch (e: SecretDecryptionException) {
            throw CredentialStoreException("Saved login cannot be decrypted", e)
        }
        try {
            DataInputStream(ByteArrayInputStream(plain)).use { input ->
                if (input.readByte().toInt() != 1) throw CredentialStoreException("Unknown saved-login format")
                val userId = input.readUTF()
                val password = input.readUTF().toCharArray()
                if (userId.isEmpty() || password.isEmpty()) throw CredentialStoreException("Saved login is empty")
                return SavedCredentials(userId, password)
            }
        } catch (e: CredentialStoreException) {
            throw e
        } catch (e: java.io.IOException) {
            throw CredentialStoreException("Saved login is corrupted", e)
        } finally {
            plain.fill(0)
        }
    }

    override fun clear() {
        try {
            storage.remove()
        } finally {
            cipher.destroyKey() // even if removal failed, the blob becomes undecryptable
        }
    }
}
