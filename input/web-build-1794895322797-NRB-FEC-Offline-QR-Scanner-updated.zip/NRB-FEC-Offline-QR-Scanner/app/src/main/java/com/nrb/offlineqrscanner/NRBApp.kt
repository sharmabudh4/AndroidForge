package com.nrb.offlineqrscanner

import android.app.Application
import android.content.Context
import com.nrb.offlineqrscanner.database.AppDatabase
import com.nrb.offlineqrscanner.database.dao.RoomDeviceRepo
import com.nrb.offlineqrscanner.database.dao.RoomScanAuditRepo
import com.nrb.offlineqrscanner.database.dao.RoomUserRepo
import com.nrb.offlineqrscanner.security.AesGcmCipher
import com.nrb.offlineqrscanner.security.KeystoreSecretKeyProvider
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.PrefsBlobStorage
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.security.TrustedKeyStore
import com.nrb.offlineqrscanner.security.androidBase64
import com.nrb.offlineqrscanner.service.AppSettings
import com.nrb.offlineqrscanner.service.AuthService
import com.nrb.offlineqrscanner.service.AuthorizationManager
import com.nrb.offlineqrscanner.service.CredentialStore
import com.nrb.offlineqrscanner.service.DeviceService
import com.nrb.offlineqrscanner.service.DuplicateScanManager
import com.nrb.offlineqrscanner.service.EncryptedCredentialStore
import com.nrb.offlineqrscanner.service.Session
import com.nrb.offlineqrscanner.service.UserService

/**
 * Application class doubling as a tiny service locator (no DI framework needed for this size).
 * No account is seeded here - the very first account is created through the secure first-run
 * setup screen (screens.firstrun.FirstRunSetupActivity) instead of a hardcoded default.
 */
class NRBApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val settings: AppSettings by lazy { AppSettings(this) }
    val keyStore: TrustedKeyStore by lazy { TrustedKeyStore(this) }
    val duplicates = DuplicateScanManager()
    val session = Session()

    val userService: UserService by lazy { UserService(RoomUserRepo(database.userDao())) }
    val deviceService: DeviceService by lazy { DeviceService(RoomDeviceRepo(database.deviceDao())) }

    /** Saved login: AES-GCM encrypted with an Android Keystore key, stored in private app storage. */
    val credentialStore: CredentialStore by lazy {
        EncryptedCredentialStore(PrefsBlobStorage(this), AesGcmCipher(KeystoreSecretKeyProvider()))
    }
    val auth: AuthService by lazy { AuthService(userService, credentialStore, session) }

    private val authenticator by lazy { PayloadAuthenticator(SignatureVerifier(androidBase64)) }
    val authorization: AuthorizationManager by lazy {
        AuthorizationManager(RoomDeviceRepo(database.deviceDao()), RoomScanAuditRepo(database.scanHistoryDao()), keyStore, settings, authenticator)
    }
}

val Context.nrbApp: NRBApp get() = applicationContext as NRBApp
