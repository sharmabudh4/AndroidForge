package com.nrb.offlineqrscanner.screens.changepassword

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityChangePasswordBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.service.LoginResult
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

/** Used both for the forced first-login change and for a voluntary change from Settings. */
class ChangePasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChangePasswordBinding
    private var required = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        binding = ActivityChangePasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)
        required = intent.getBooleanExtra("required", false)

        if (required) {
            binding.toolbar.navigationIcon = null
            binding.tvRequiredHint.visibility = android.view.View.VISIBLE
            binding.containerCurrentPassword.visibility = android.view.View.GONE
        } else {
            binding.toolbar.setNavigationOnClickListener { finish() }
        }

        binding.btnSave.setOnClickListener { submit() }
    }

    private fun submit() {
        val userId = requireLoggedInUserOrRedirect() ?: return
        val current = binding.etCurrentPassword.text.toString()
        val newPass = binding.etNewPassword.text.toString()
        val confirm = binding.etConfirmPassword.text.toString()

        if (newPass.length < 6) {
            toast(getString(R.string.error_general)); return
        }
        if (newPass != confirm) {
            toast(getString(R.string.password_mismatch)); return
        }

        lifecycleScope.launch {
            if (!required) {
                val verifyResult = nrbApp.userService.login(userId, current.toCharArray())
                if (verifyResult !is LoginResult.Success) {
                    toast(getString(R.string.wrong_current_password))
                    return@launch
                }
            }
            nrbApp.userService.changePassword(userId, newPass.toCharArray())
            nrbApp.auth.onPasswordChanged(userId, newPass.toCharArray()) // keep the saved login in step
            toast(getString(R.string.password_changed))
            if (required) {
                startActivity(Intent(this@ChangePasswordActivity, HomeActivity::class.java))
            }
            finish()
        }
    }
}
