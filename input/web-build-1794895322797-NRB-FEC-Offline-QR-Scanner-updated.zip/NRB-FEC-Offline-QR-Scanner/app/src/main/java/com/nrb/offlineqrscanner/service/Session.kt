package com.nrb.offlineqrscanner.service

/**
 * In-memory only. The session itself is never persisted; on a fresh launch it is re-created from the
 * encrypted saved login by service.AuthService.restoreSession(), and logout deletes that saved login.
 */
class Session {
    var userId: String? = null
        private set
    var isAdmin: Boolean = false
        private set

    val isLoggedIn: Boolean get() = userId != null

    fun start(userId: String, isAdmin: Boolean) {
        this.userId = userId
        this.isAdmin = isAdmin
    }

    fun clear() {
        userId = null
        isAdmin = false
    }
}
