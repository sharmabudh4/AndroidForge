package com.nrb.offlineqrscanner.screens.login

import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityLoginBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.service.LoginResult
import com.nrb.offlineqrscanner.service.RestoreFailure
import com.nrb.offlineqrscanner.service.RestoreResult
import com.nrb.offlineqrscanner.utils.continueAfterLogin
import kotlinx.coroutines.launch

/**
 * The login form is only shown when there is no saved login or the saved login no longer works.
 * If a saved login exists (e.g. this screen was reached because the app process was recreated),
 * it is restored silently first and the form stays hidden while that happens.
 */
class LoginActivity : AppCompatActivity() {
    companion object {
        /** Optional string-resource id of a notice to show above the form (e.g. "saved login no longer valid"). */
        const val EXTRA_NOTICE_RES = "notice_res"

        @StringRes
        fun noticeFor(failure: RestoreFailure): Int? = when (failure) {
            RestoreFailure.INVALID_CREDENTIALS -> R.string.saved_login_invalid
            RestoreFailure.ACCOUNT_DEACTIVATED -> R.string.account_deactivated
            RestoreFailure.SAVED_LOGIN_UNREADABLE -> null
        }
    }

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnLogin.setOnClickListener { attemptLogin() }

        val notice = intent.getIntExtra(EXTRA_NOTICE_RES, 0)
        if (notice != 0) showError(getString(notice))

        // Hide the form while a saved login (if any) is being checked, so it never flashes.
        binding.root.visibility = View.INVISIBLE
        lifecycleScope.launch {
            when (val restored = nrbApp.auth.restoreSession()) {
                is RestoreResult.Restored -> continueAfterLogin(restored.mustChangePassword)
                is RestoreResult.AlreadyLoggedIn -> continueAfterLogin(false)
                is RestoreResult.Failed -> {
                    noticeFor(restored.reason)?.let { showError(getString(it)) }
                    binding.root.visibility = View.VISIBLE
                }
                RestoreResult.NoSavedCredentials -> { binding.root.visibility = View.VISIBLE }
            }
        }
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
    }

    private fun attemptLogin() {
        val userId = binding.etUserId.text.toString().trim()
        val password = binding.etPassword.text.toString()
        if (userId.isEmpty() || password.isEmpty()) {
            showError(getString(R.string.invalid_credentials))
            return
        }
        binding.btnLogin.isEnabled = false
        binding.tvError.visibility = View.GONE

        lifecycleScope.launch {
            // AuthService starts the session and saves the login (encrypted) after a successful sign-in.
            when (val result = nrbApp.auth.login(userId, password.toCharArray())) {
                is LoginResult.Success -> continueAfterLogin(result.mustChangePassword)
                LoginResult.InvalidCredentials -> {
                    binding.btnLogin.isEnabled = true
                    showError(getString(R.string.invalid_credentials))
                }
                LoginResult.AccountDeactivated -> {
                    binding.btnLogin.isEnabled = true
                    showError(getString(R.string.account_deactivated))
                }
            }
        }
    }
}
