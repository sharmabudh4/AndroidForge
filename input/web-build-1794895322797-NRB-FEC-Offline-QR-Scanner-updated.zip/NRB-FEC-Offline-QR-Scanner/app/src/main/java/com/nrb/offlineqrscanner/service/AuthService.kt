package com.nrb.offlineqrscanner.service

/** Why a silent sign-in with the saved login did not succeed. */
enum class RestoreFailure { INVALID_CREDENTIALS, ACCOUNT_DEACTIVATED, SAVED_LOGIN_UNREADABLE }

sealed class RestoreResult {
    /** Nothing saved: show the login form. */
    object NoSavedCredentials : RestoreResult()
    /** A session is already active in this process. */
    data class AlreadyLoggedIn(val isAdmin: Boolean) : RestoreResult()
    /** Saved login verified against the local account database; session started. */
    data class Restored(val isAdmin: Boolean, val mustChangePassword: Boolean) : RestoreResult()
    /** Saved login no longer works. It has been deleted; show the login form. */
    data class Failed(val reason: RestoreFailure) : RestoreResult()
}

/**
 * Login lifecycle on top of [UserService] (local accounts) and [CredentialStore] (encrypted saved login):
 *  - [login]: normal sign-in; saves the login after the first successful one (and every later one).
 *  - [restoreSession]: silent sign-in on app start - the saved login is re-verified against the local
 *    account table every time, so a changed password or a deactivated account is noticed.
 *  - [logout]: ends the session AND deletes the saved login.
 * Nothing here touches the network.
 */
class AuthService(
    private val userService: UserService,
    private val store: CredentialStore,
    private val session: Session
) {
    suspend fun login(userId: String, password: CharArray): LoginResult {
        val id = userId.trim()
        val result = userService.login(id, password)
        if (result is LoginResult.Success) {
            session.start(id, result.isAdmin)
            if (result.mustChangePassword) {
                // A temporary password is not worth keeping; the new one is saved by onPasswordChanged().
                safeClear()
            } else {
                trySave(id, password)
            }
        }
        return result
    }

    suspend fun restoreSession(): RestoreResult {
        if (session.isLoggedIn) return RestoreResult.AlreadyLoggedIn(session.isAdmin)
        val saved = try {
            store.load()
        } catch (e: CredentialStoreException) {
            safeClear()
            return RestoreResult.Failed(RestoreFailure.SAVED_LOGIN_UNREADABLE)
        } ?: return RestoreResult.NoSavedCredentials

        try {
            return when (val r = userService.login(saved.userId, saved.password)) {
                is LoginResult.Success -> {
                    session.start(saved.userId, r.isAdmin)
                    RestoreResult.Restored(r.isAdmin, r.mustChangePassword)
                }
                LoginResult.InvalidCredentials -> { safeClear(); RestoreResult.Failed(RestoreFailure.INVALID_CREDENTIALS) }
                LoginResult.AccountDeactivated -> { safeClear(); RestoreResult.Failed(RestoreFailure.ACCOUNT_DEACTIVATED) }
            }
        } finally {
            saved.password.fill('\u0000')
        }
    }

    /** Keeps the saved login in step after the user changes their own password. */
    fun onPasswordChanged(userId: String, newPassword: CharArray) {
        if (session.userId?.equals(userId, ignoreCase = true) == true) trySave(userId, newPassword)
    }

    fun logout() {
        try {
            session.clear()
        } finally {
            safeClear()
        }
    }

    /** Saving is a convenience: if secure storage is unavailable, login still works (and is asked for again next launch). */
    private fun trySave(userId: String, password: CharArray) {
        try { store.save(userId, password) } catch (e: Exception) { safeClear() }
    }

    private fun safeClear() {
        try { store.clear() } catch (e: Exception) { /* nothing more we can do; blob is undecryptable once key is gone */ }
    }
}
