# NRB FEC Offline QR Scanner - Build Instructions

## Android Studio Build Instructions (Release APK)

### Prerequisites

- Android Studio Flamingo or newer
- JDK 17 or newer
- Android SDK Platform 34
- Kotlin 1.9.22 or newer

### Step 1: Clone or Download the Project

```bash
git clone <repository-url>
cd NRB-FEC-Offline-QR-Scanner
```

### Step 2: Configure Local Properties

Edit `local.properties` (project root, not committed) to point to your Android SDK:

```properties
sdk.dir=/path/to/android/sdk
```

### Step 3: Open in Android Studio

1. Launch Android Studio
2. Select "Open" and navigate to the project directory
3. Wait for Gradle synchronization to complete

### Step 4: Build the Release APK

#### Using Android Studio:

1. Go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**
2. The APK will be generated in `app/build/outputs/apk/release/`

#### Using Command Line:

```bash
cd /path/to/NRB-FEC-Offline-QR-Scanner

# Make the script executable
chmod +x gradlew

# Build the release APK
./gradlew assembleRelease
```

The release APK will be generated at:
```
app/build/outputs/apk/release/app-release.apk
```

### Step 5: Sign the Release APK

For production distribution, sign the APK:

#### Generate a Signing Key:

```bash
keytool -genkey -v -keystore nrb_fec_keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias nrb_fec_key -storetype JKS
```

#### Configure Signing in build.gradle:

```gradle
android {
    signingConfigs {
        release {
            keyAlias 'nrb_fec_key'
            keyPassword 'your_key_password'
            storeFile file('nrb_fec_keystore.jks')
            storePassword 'your_store_password'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

### Step 6: Install and Test

```bash
adb install app/build/outputs/apk/release/app-release.apk
```

## Debug APK Build Instructions

### Using Android Studio:

1. Select **Build** > **Build Bundle(s) / APK(s)** > **Build Debug APK**
2. The APK will be generated in `app/build/outputs/apk/debug/`

### Using Command Line:

```bash
./gradlew assembleDebug
```

Debug APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Install Debug APK:

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Build Variants

| Variant | Description | Location |
|---------|-------------|----------|
| Debug | Development build with debugging enabled | `app/build/outputs/apk/debug/` |
| Release | Optimized production build | `app/build/outputs/apk/release/` |

## Gradle Properties

| Property | Value |
|----------|-------|
| minSdk | 24 (Android 7.0) |
| targetSdk | 34 (Android 14) |
| compileSdk | 34 (Android 14) |
| Kotlin | 1.9.22 |
| buildTools | 34.0.0 |

## Troubleshooting

### Q: Gradle sync fails with "Could not find" errors
A: Check your internet connection and ensure all dependencies are available. Try:
```bash
./gradlew --refresh-dependencies
```

### Q: Build fails with Java version errors
A: Ensure you're using JDK 17 or newer.

### Q: SDK not found error
A: Set `sdk.dir` in `local.properties` (project root, not committed) or set the `ANDROID_HOME` environment variable.

## Source Code Structure

```
app/src/main/
├── java/com/nrb/offlineqrscanner/
│   ├── NRBApp.kt                    # Application class
│   ├── models/                      # Data models
│   ├── database/                    # Room database
│   ├── service/                     # Business logic
│   ├── screens/                     # UI screens
│   ├── utils/                       # Utilities
│   └── di/                          # Dependency injection
├── res/
│   ├── layout/                      # XML layouts
│   ├── values/                      # Strings, colors, themes
│   └── drawable/                    # Drawable resources
└── AndroidManifest.xml              # App manifest
```
