# NRB FEC Offline QR Scanner - Architecture Overview

## 1. System Architecture

The application follows a clean architecture pattern with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────────┐
│                    UI Layer (Activities/Fragments)              │
│  SplashActivity → HomeActivity → [ScanActivity, DeviceInfo,    │
│                AccessGranted, AccessDenied, Import, Settings]   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Presentation Layer (ViewModels)              │
│  HomeViewModel, ScanViewModel, ImportViewModel, etc.            │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Domain Layer (Services)                      │
│  QRScannerService │ AuthorizationManager │ ImportService        │
│  DuplicateScanManager │ ExportService                          │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Data Layer (Repository)                      │
│  DeviceRepository │ ImportRepository │ ScanHistoryRepository    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Persistence Layer (Room Database)            │
│  DeviceDao │ ImportRecordDao │ ScanHistoryDao │ AppDatabase    │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    Utilities (File, Crypto, Date, Extensions)   │
└─────────────────────────────────────────────────────────────────┘
```

## 2. Key Components

### 2.1 Models (`models/`)

| File | Purpose |
|------|---------|
| `QRDataModel.kt` | QR code data structure |
| `PermissionModel.kt` | Permission enum |
| `DeviceModel.kt` | Device record structure |
| `ImportFileModel.kt` | Import file structure |
| `ScannedQRModel.kt` | Scanned QR code result |

### 2.2 Database (`database/`)

| File | Purpose |
|------|---------|
| `AppDatabase.kt` | Room database with 5 DAOs |
| `entities/DatabaseEntities.kt` | Room entities |

### 2.3 Services (`service/`)

| File | Purpose |
|------|---------|
| `QRScannerService.kt` | QR code scanning engine |
| `AuthorizationManager.kt` | Authorization verification |
| `ImportService.kt` | Import file processing |
| `ExportService.kt` | Export file generation |

### 2.4 Screens (`screens/`)

| Folder | Contains |
|--------|----------|
| `splash/` | Splash screen |
| `home/` | Home dashboard |
| `scanner/` | QR scanner activity |
| `deviceinfo/` | Device information screen |
| `granted/` | Access granted screen |
| `accessdenied/` | Access denied screen |
| `importeddevices/` | Imported devices list |
| `import/` | Import database screen |
| `scanhistory/` | Scan history screen |
| `settings/` | Settings screen |

## 3. Data Flow

### 3.1 QR Scan Flow

```
1. User opens Scan Activity
2. Camera preview starts (ML Kit)
3. User points camera at QR code
4. ML Kit detects QR pattern
5. QR data decoded to JSON
6. Parse JSON to QRDataModel
7. Check duplicate scan (cooldown period)
8. Verify QR format and signature
9. AuthorizationManager.verified()
10. Check local database for device
11. Check user permissions
12. Record scan in history
13. Navigate to AccessGranted or AccessDenied
```

### 3.2 Import Flow

```
1. User selects import file
2. File read from external storage
3. Parse JSON to ImportFileModel
4. Validate format version
5. Verify SHA-256 checksum
6. Verify digital signature
7. Validate all device records
8. Begin database transaction
9. Insert import record (pending)
10. Insert each device record
11. Update import record (success)
12. Show success message
```

### 3.3 Export Flow (PC side)

```
1. PC application reads authorized device records
2. Compile JSON with permission data
3. Compute SHA-256 checksum
4. Sign with private key
5. Export with timestamped filename
```

## 4. Offline-First Design

- **No network calls** for authorization verification
- **Local SQLite database** for all data storage
- **Camera-only** QR scanning (no server round-trip)
- **No login required** - direct device access
- **Storage**: All data lives in app's private database

## 5. Key Architecture Decisions

| Decision | Rationale |
|----------|-----------|
| Room over raw SQLite | Type-safe queries, easy migrations, coroutine support |
| ML Kit over ZXing | Better camera integration, ML optimizations |
| MVVM architecture | Clean separation, testable, lifecycle-aware |
| JSON format | Human readable, easy to generate manually |
| Digital signatures | Prevents QR code tampering |

## 6. Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| AndroidX Core | 1.12.0 | Core Android APIs |
| AndroidX Lifecycle | 2.7.0 | Lifecycle-aware components |
| Room | 2.6.1 | SQLite object mapping |
| ML Kit Barcode | 17.2.0 | QR code scanning |
| GSON | 2.10.1 | JSON parsing |
| Material Components | 1.11.0 | Material Design 3 UI |

## 7. Database Schema

```
devices                        import_records                scan_history
┌──────────────────┐           ┌──────────────────┐          ┌──────────────────┐
│ id (PK)          │──────────▶│ id (PK)          │          │ rowId (PK)       │
│ name             │           │ fileName         │          │ deviceId         │
│ authorizedUsern  │           │ fileSize         │          │ deviceName       │
│ permissionsJson  │           │ importTime       │◀─────────│ scanTime         │
│ qrPresents       │           │ deviceCount      │          │ scanResult       │
│ authStatus       │           │ status           │          │ permissionLevel  │
│ createdAt        │           │ message          │          │ ipAddress        │
│ lastAuthCheck    │           │ └───references───┘          │                  │
│ dbVersion        │           └──────────────────┘          │                  │
│ isActive         │                                         └──────────────────┘
│ qrSource         │
└──────────────────┘
```

## 8. Screenshot Flow Diagram

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Splash     │────▶│  Home       │────▶│  Scan       │
│  Screen     │     │  Dashboard  │     │  Scanner    │
└─────────────┘     └─────────────┘     └─────────────┘
                              │
                    ┌─────────┴─────────┐
                    ▼                   ▼
              ┌─────────────┐     ┌─────────────┐
              │ Import Data │     │ Access      │
              │             │     │ Granted     │
              └─────────────┘     └─────────────┘
```

## 9. Testing Strategy

- Unit tests for AuthorizationManager
- Unit tests for ImportService
- Unit tests for QRDataModel parsing
- Integration test for full QR scan flow
- UI tests for critical user paths

| `dao/DaoInterfaces.kt` | Data access objects |
