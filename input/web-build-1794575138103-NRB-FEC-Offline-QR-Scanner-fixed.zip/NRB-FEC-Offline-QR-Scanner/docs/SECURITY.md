# NRB FEC Offline QR Scanner - Security Guide

## 1. Security Requirements Summary

The NRB FEC Offline QR Scanner is designed for offline, local operation with the following security guarantees:

- **No internet connection required** for operation or authorization checks
- **No cloud server** for data storage or validation
- **Local database-only** authorization verification
- **Digital signature verification** for imported files
- **Permission-based access control** enforced locally

## 2. QR Code Security

### 2.1 Data Protection

- **Do not store sensitive data** directly in the QR code
- The QR code contains only:
  - Device ID
  - Device Name
  - Authorized Username
  - Permission codes (optional)
  - Digital signature (optional)

### 2.2 Signature Verification

```mermaid
sequenceDiagram
    participant PC as PC QR Generator
    participant Phone as Android Scanner
    PC->>Phone: QR Code (signed)
    Phone->>Phone: Parse QR data
    Phone->>Phone: Verify signature
    alt Valid signature
        Phone->>Phone: Check device in local DB
        Phone->>Phone: Verify permissions
        Phone->>Phone: Grant/deny access
    else Invalid signature
        Phone->>Phone: Reject QR code
    end
```

### 2.3 Anti-Replay Protection

- QR codes include issue timestamps
- Device may reject QR codes from the future or too far in the past
- Expired QR codes are rejected

## 3. Local Database Security

### 3.1 Data at rest

- The Room/SQLite database lives in the app-private directory (protected by Android's per-app sandbox and device encryption). It is **not** additionally encrypted by the app; on a rooted device or with the screen lock disabled it can be read. Consider SQLCipher if that is in your threat model.
- No data is transmitted: the app declares no INTERNET permission.
- Raw QR contents are never stored; scan history keeps only device ID, name, time, outcome and reason.

### 3.2 Backup exclusions

`android:allowBackup="false"`, plus `data_extraction_rules.xml` excluding cloud backup and device transfer, so the database and trusted key never leave the device.

### 3.3 Trusted key

The trust anchor is one public key, installed via Settings (the user must confirm its SHA-256 fingerprint against the PC application) or bundled as `assets/trusted_public_key.pem`. Anyone with unlocked physical access can replace it; protect the device accordingly.

## 4. Import File Security

### 4.1 Digital Signatures

Import files are signed with a private key on the PC:

- **Algorithm**: ECDSA-P256 or RSA-2048 (HMAC is not supported)
- **Verification**: Public key or shared secret on Android
- **Rejection**: Corrupted or invalid signatures are rejected

### 4.2 File Integrity

- SHA-256 checksum provided in the import file
- Android verifies checksum before processing
- All-or-nothing import: no partial imports

### 4.3 Validation Rules

The Android application MUST:
1. Verify format identifier (`NRB-FEC-IMPORT-1.0`)
2. Validate device ID format (`NRB-DEV-\d{3,5}`)
3. Check all required fields are present
4. Verify permission codes are supported
5. Reject duplicate device IDs
6. Verify signature if present
7. Verify checksum if provided

## 5. Authorization Verification Flow

```
Scan QR Code
    ↓
Parse JSON
    ↓
Check format version
    ↓
Verify signature (if present)
    ↓
Look up device in local database
    ↓
Check if device is active
    ↓
Check if user has permission
    ↓
Record authorization attempt
    ↓
Grant or deny access
```

## 6. Permission Enforcement

Permissions are enforced at the device level:

| Permission | Enforcement |
|------------|-------------|
| View Device Information | Always granted after authorization |
| View Technical Specifications | Checked against device permissions |
| View Documents & Manuals | Checked against device permissions |
| Download/Export Files | Checked against device permissions |
| View Other Device Information | Checked against device permissions |

## 7. Security Best Practices for PC Generator

1. Use strong, unique device IDs
2. Keep private keys secure
3. Require password to generate QR codes
4. Log all QR code generations
5. Set sensible expiration times
6. Use HTTPS/TLS for PC backup (optional)
7. Regularly rotate signing keys

## 8. Security Best Practices for Android App

1. Never log QR data in debug logs
2. Clear sensitive data on app exit
3. Use Android's secure storage APIs
4. Do not store passwords in shared preferences
5. Validate all imported data thoroughly
6. Do not grant wildcard access unless explicitly configured

## 9. Common Security Pitfalls

| Pitfall | Solution |
|---------|----------|
| Storing passwords in QR code | Hash and salt passwords; private fields only |
| Accepting unsigned QR codes | Require signature verification |
| Soft-deleted devices | Mark as inactive, don't delete |
| Trusting QR data blindly | Always validate against local DB |
| Insecure database backup | Use encryption and backup exclusions |

## 10. Threat Model

| Threat | Mitigation |
|--------|------------|
| QR code tampering | Digital signature verification |
| Database extraction | App sandbox + backups disabled (database itself not encrypted) |
| Unauthorized access | Permission-based enforcement |
| Replay attacks | Timestamp validation |
| Import file manipulation | Digital signature verification |
| Malformed file import | Strict validation |
| Device with stolen credentials | Limit device-level access |

## 11. Compliance Notes

This application is designed for:
- Offline operation
- Data privacy compliance
- Security-conscious environments
- Device authorization and access control

This is not a consumer authentication system.
