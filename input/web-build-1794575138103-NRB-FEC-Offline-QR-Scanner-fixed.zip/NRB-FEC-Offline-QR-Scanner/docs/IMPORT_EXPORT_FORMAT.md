# NRB FEC Offline QR Scanner - Import/Export File Format Specification

## Version 1.0

## 1. Overview
This document specifies the authorization database file format exported by the PC QR Generator and imported by the Android NRB FEC QR Scanner.

## 2. Import File Format

The import file is a JSON document containing multiple device records:

```json
{
  "format": "NRB-FEC-IMPORT-1.0",
  "version": 1,
  "generated_at": 1704067200,
  "app_version": "1.0.0",
  "devices": [
    {
      "device_id": "NRB-DEV-001",
      "device_name": "Point-of-Sale Terminal A",
      "authorized_user": "alice",
      "permissions": ["view_device_info", "view_tech_spec"],
      "device_address": "192.168.1.100",
      "device_serial": "SN-2024-001"
    },
    {
      "device_id": "NRB-DEV-002",
      "device_name": "Server Room Terminal",
      "authorized_user": "admin",
      "permissions": ["*"],
      "device_address": "192.168.1.101",
      "device_serial": "SN-2024-002"
    }
  ],
  "algorithm": "ECDSA-P256",
  "sha256": "a3f5c8e9b2d1...",
  "signature": "base64_der_signature"
}
```

## 3. Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `format` | string | Yes | Import format identifier: "NRB-FEC-IMPORT-1.0" |
| `version` | integer | Yes | File format version (1) |
| `generated_at` | integer | Yes | Generation timestamp (Unix epoch seconds) |
| `app_version` | string | Yes | PC application version that generated the file |
| `devices` | array | Yes | List of device authorization records |
| `algorithm` | string | With signature | `ECDSA-P256` (or `RSA-2048`); must match the installed trusted key. It is part of the signed data |
| `sha256` | string | No | Lower-case hex SHA-256 of the canonical JSON (see below). Integrity only, not authenticity |
| `signature` | string | Yes (unless demo mode) | Base64 signature over the canonical JSON |

## 4. Device Record Fields

Each object in the `devices` array contains:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `device_id` | string | Yes | Unique device identifier (NRB-DEV-XXXX format) |
| `device_name` | string | Yes | Human-readable device name |
| `authorized_user` | string | Yes | Authorized username for this device |
| `permissions` | array | Yes | List of permission codes |
| `device_address` | string | No | Device IP address |
| `device_serial` | string | No | Device serial number |

## 5. Validation Rules

The Android application MUST validate imported files as follows:

1. **Format Check**: Verify `format` field equals "NRB-FEC-IMPORT-1.0"
2. **Required Fields**: Verify all required fields are present and valid
3. **Device ID Format**: Validate `device_id` matches pattern `NRB-DEV-\d{3,5}`
4. **Permissions**: Verify permission codes are from the known list
5. **Duplicate Check**: Reject devices with duplicate `device_id`
6. **Checksum**: If `sha256` is provided it must match the canonical JSON
7. **Signature**: Required. Verified with the trusted public key installed in Settings; unsigned files are rejected unless demo mode is on
8. **Rollback**: `generated_at` older than the last imported file is rejected
9. **Empty**: a file with no devices is rejected

## 6. Error Handling

If validation fails, the Android application MUST:
- Reject the file with a descriptive error message
- Log the failure in the import records table
- NOT import any partial data (all-or-nothing approach)
- Allow the user to retry with a corrected file

## 7. Export Process (PC Application)

The PC QR Generator MUST:
1. Read all authorized device records from its database
2. Compile them into the JSON format above
3. Optionally compute SHA-256 checksum
4. Optionally sign the file with a private key
5. Export the file with `.json` extension
6. Track the export timestamp and application version

## 8. Import Process (Android Application)

The Android application MUST:
1. Read the file from external storage (via file picker or USB)
2. Parse the JSON content
3. Validate the file format and data
4. Verify checksum and signature (if present)
5. Insert device records into the local SQLite database
6. Log the import in the import records table
7. Notify the user of success or failure

## 9. File Naming Convention

- Import files: `nrb_fec_import_YYYYMMDD_HHMMSS.json`
- Export files: `nrb_fec_import_YYYYMMDD_HHMMSS.json`
- QR code files: `nrb_fec_qr_XXXX.json` (per device)

## 10. Interoperability

Both the PC QR Generator and Android Scanner MUST:
- Use the exact same JSON field names and structure
- Support the same permission codes
- Use the same signature algorithm
- Support the same version identifier

## 11. Canonical JSON and import semantics

Signed bytes and `sha256` input = canonical JSON of the whole file **without** `signature` and `sha256` (keys sorted at every level, no whitespace, UTF-8, integers only) - see `docs/QR_FORMAT.md` section 5 and `tools/nrb_sign.py`.

An import is a **full snapshot**: every device not present in the file is deactivated (revoked) and devices in the file are inserted or updated. The whole import is a single database transaction.
