# NRB FEC Offline QR Scanner - QR Code Format Specification

## Version 1.0

## 1. Overview
This document specifies the QR code format used by the NRB FEC Offline QR Scanner Android application and the companion PC QR Generator application.

## 2. QR Code Data Format

The QR code contains a JSON object with the following structure:

```json
{
  "format": "NRB-FEC-QR-1.0",
  "version": 1,
  "device_id": "NRB-DEV-001",
  "device_name": "Point-of-Sale Terminal A",
  "authorized_user": "alice",
  "permissions": [
    "view_device_info",
    "view_tech_spec",
    "view_docs",
    "download_export"
  ],
  "signature": "base64_encoded_signature",
  "issued_at": 1704067200,
  "expires_at": 0,
  "device_address": "192.168.1.100",
  "device_serial": "SN-2024-001"
}
```

## 3. Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `format` | string | Yes | QR format identifier: "NRB-FEC-QR-1.0" |
| `version` | integer | Yes | QR data format version (1) |
| `device_id` | string | Yes | Unique device identifier. Format: `NRB-DEV-XXXX` where XXXX is 3-5 digits |
| `device_name` | string | Yes | Human-readable device name |
| `authorized_user` | string | Yes | Username authorized to access this device |
| `permissions` | array | No | List of permission codes granted by this QR code |
| `signature` | string | No | Base64-encoded digital signature for verification |
| `issued_at` | integer | No | Issue timestamp (Unix epoch seconds) |
| `expires_at` | integer | No | Expiration timestamp (Unix epoch seconds). 0 = no expiration |
| `device_address` | string | No | Device IP address or hostname |
| `device_serial` | string | No | Device serial number |

## 4. Permission Codes

| Code | Label | Description |
|------|-------|-------------|
| `view_device_info` | View Device Information | View basic device information |
| `view_tech_spec` | View Technical Specifications | View hardware specs, firmware versions |
| `view_docs` | View Documents & Manuals | View user manuals, documents |
| `download_export` | Download / Export Files | Download or export permitted files |
| `view_device_related` | View Other Device Information | View device-related information |

A permission code of `*` may be used to indicate full access.

## 5. Signature and Security

- `signature` = Base64 of an **ECDSA P-256 / SHA-256** signature (DER encoded, as produced by OpenSSL, Python `cryptography`, Java `SHA256withECDSA`). RSA-2048 (`SHA256withRSA`) is also accepted if the installed trusted key is an RSA key.
- **Signed bytes** = canonical JSON of the QR object *without* its `signature` (and `sha256`) field: keys sorted ascending at every level, no whitespace (`separators=(",", ":")`), UTF-8, `ensure_ascii=False`, integers only (no floats). Python: `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`.
- `tools/nrb_sign.py` is the reference signer; `docs/examples/` contains a signed sample and its public key.
- The scanner is **fail-closed**: a QR without a valid signature, or any QR when no trusted key is installed, is denied. The only exception is the explicit *Allow unsigned data (demo mode)* switch in Settings (off by default). A signature that is present but wrong is always rejected.
- A valid signature is not enough for access: the device must exist and be active in the locally imported database, `authorized_user` must match, and the effective permissions are the **intersection** of the QR's and the database's permissions (a QR can never grant more than the database).
- `expires_at` (non-zero) is enforced; `issued_at` more than 5 minutes in the future is rejected. These checks rely on the phone's clock.

## 6. QR Code Encoding Requirements

- Minimum QR code version: 2 (can hold up to 1,600 characters)
- Error correction level: H (High, 30%)
- Standard encoding: UTF-8
- DO NOT embed sensitive data in plaintext QR codes

## 7. QR Code Examples

### Basic QR Code (View Device Information only)
```json
{
  "format": "NRB-FEC-QR-1.0",
  "version": 1,
  "device_id": "NRB-DEV-001",
  "device_name": "Cash Register",
  "authorized_user": "alice",
  "permissions": ["view_device_info"],
  "issued_at": 1704067200,
  "expires_at": 0
}
```

### Full-Access QR Code (All Permissions)
```json
{
  "format": "NRB-FEC-QR-1.0",
  "version": 1,
  "device_id": "NRB-DEV-002",
  "device_name": "Server Room Terminal",
  "authorized_user": "admin",
  "permissions": ["*", "download_export"],
  "issued_at": 1704067200,
  "expires_at": 1735603200
}
```

## 8. QR Code Format Interoperability

Both the PC QR Generator and Android Scanner MUST use exactly this format:
- Same JSON field names
- Same permission codes
- Same signature algorithm and encoding
- Same version identifier

This ensures interoperability between the two applications.
