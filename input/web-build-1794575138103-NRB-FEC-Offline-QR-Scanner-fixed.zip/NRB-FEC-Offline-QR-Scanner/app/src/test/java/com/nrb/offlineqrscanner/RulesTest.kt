package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.models.PermissionModel
import com.nrb.offlineqrscanner.models.QrPayload
import com.nrb.offlineqrscanner.service.AuthorizationEngine
import com.nrb.offlineqrscanner.service.Decision
import com.nrb.offlineqrscanner.service.DeviceRecord
import com.nrb.offlineqrscanner.service.DuplicateScanManager
import com.nrb.offlineqrscanner.service.ScanResultCode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RulesTest {
    private val now = 1_800_000_000L
    private fun qr(perms: List<String> = listOf("view_device_info"), user: String = "alice",
                   issued: Long = now - 10, expires: Long = 0) =
        QrPayload("NRB-DEV-001", "POS", user, perms, issued, expires, null, null)
    private fun dev(perms: List<String> = listOf("view_device_info", "view_docs"), active: Boolean = true) =
        DeviceRecord("NRB-DEV-001", "POS", "alice", perms, active)

    @Test fun grantsIntersection() {
        val d = AuthorizationEngine.decide(qr(listOf("view_device_info", "download_export")), dev(), now)
        assertEquals(setOf(PermissionModel.VIEW_DEVICE_INFO), (d as Decision.Grant).permissions)
    }

    @Test fun qrCannotEscalateWithWildcard() {
        val d = AuthorizationEngine.decide(qr(listOf("*")), dev(), now) as Decision.Grant
        assertEquals(setOf(PermissionModel.VIEW_DEVICE_INFO, PermissionModel.VIEW_DOCS), d.permissions)
    }

    @Test fun wildcardOnBothSidesGrantsAll() {
        val d = AuthorizationEngine.decide(qr(listOf("*")), dev(listOf("*")), now) as Decision.Grant
        assertEquals(PermissionModel.values().toSet(), d.permissions)
    }

    @Test fun deniesUnknownInactiveWrongUserExpiredFuture() {
        assertEquals(ScanResultCode.UNKNOWN, (AuthorizationEngine.decide(qr(), null, now) as Decision.Deny).resultCode)
        assertTrue(AuthorizationEngine.decide(qr(), dev(active = false), now) is Decision.Deny)
        assertTrue(AuthorizationEngine.decide(qr(user = "bob"), dev(), now) is Decision.Deny)
        assertEquals(ScanResultCode.EXPIRED, (AuthorizationEngine.decide(qr(expires = now - 1), dev(), now) as Decision.Deny).resultCode)
        assertTrue(AuthorizationEngine.decide(qr(issued = now + 10_000), dev(), now) is Decision.Deny)
        assertTrue(AuthorizationEngine.decide(qr(perms = listOf("view_docs", "download_export")), dev(listOf("view_device_info")), now) is Decision.Deny)
    }

    @Test fun userMatchIsCaseInsensitive() {
        assertTrue(AuthorizationEngine.decide(qr(user = "ALICE"), dev(), now) is Decision.Grant)
    }

    @Test fun duplicateCooldown() {
        var t = 0L
        val m = DuplicateScanManager(3000) { t }
        assertFalse(m.isDuplicate("a"))
        t = 1000; assertTrue(m.isDuplicate("a")); assertFalse(m.isDuplicate("b"))
        t = 3500; assertFalse(m.isDuplicate("a"))
    }
}
