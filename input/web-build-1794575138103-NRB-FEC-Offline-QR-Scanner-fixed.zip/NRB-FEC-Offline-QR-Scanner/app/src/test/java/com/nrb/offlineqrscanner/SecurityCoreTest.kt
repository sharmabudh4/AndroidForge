package com.nrb.offlineqrscanner

import com.google.gson.JsonObject
import com.nrb.offlineqrscanner.models.PayloadException
import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.security.CanonicalJson
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.security.Verification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

/** Uses vectors produced by tools/nrb_sign.py so the Kotlin and Python implementations stay in sync. */
class SecurityCoreTest {
    private val b64: (String) -> ByteArray = { Base64.getMimeDecoder().decode(it) }
    private val key by lazy { PemUtils.parsePublicKey(resource("public.pem"), b64) }
    private val auth = PayloadAuthenticator(SignatureVerifier(b64))

    private fun resource(name: String) =
        javaClass.classLoader!!.getResource(name)!!.readText()

    private fun obj(name: String): JsonObject = PayloadParser.parseObject(resource(name))

    @Test fun canonicalJsonSortsKeysAndEscapes() {
        val o = PayloadParser.parseObject("""{"b":1,"a":{"z":[true,null,"x\"y\n"],"y":"é"},"signature":"s"}""")
        assertEquals("""{"a":{"y":"é","z":[true,null,"x\"y\n"]},"b":1}""".replace("\n", "\\n"),
            CanonicalJson.serialize(o, setOf("signature")))
    }

    @Test fun pythonSignedQrVerifies() {
        assertEquals(Verification.Verified, auth.authenticate(obj("qr_signed.json"), key, false))
    }

    @Test fun pythonSignedImportVerifiesWithChecksum() {
        assertEquals(Verification.Verified, auth.authenticate(obj("import_signed.json"), key, false))
        val imp = PayloadParser.parseImport(obj("import_signed.json"))
        assertEquals(2, imp.devices.size)
    }

    @Test fun tamperedQrIsRejected() {
        val o = obj("qr_signed.json")
        o.addProperty("authorized_user", "mallory")
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
        // demo mode must NOT bypass a signature that is present but wrong
        assertTrue(auth.authenticate(o, key, true) is Verification.Rejected)
    }

    @Test fun tamperedImportFailsChecksum() {
        val o = obj("import_signed.json")
        o.getAsJsonArray("devices")[1].asJsonObject.addProperty("authorized_user", "mallory")
        val r = auth.authenticate(o, key, false)
        assertTrue(r is Verification.Rejected && r.reason.contains("Checksum"))
    }

    @Test fun recomputedChecksumStillFailsSignature() {
        val o = obj("import_signed.json")
        o.getAsJsonArray("devices")[1].asJsonObject.addProperty("authorized_user", "mallory")
        o.addProperty("sha256", com.nrb.offlineqrscanner.utils.CryptoUtils.sha256Hex(
            CanonicalJson.toBytes(o, PayloadAuthenticator.EXCLUDED_FIELDS)))
        val r = auth.authenticate(o, key, false)
        assertTrue(r is Verification.Rejected && r.reason.contains("signature"))
    }

    @Test fun unsignedRejectedUnlessDemoMode() {
        val o = obj("qr_signed.json").also { it.remove("signature") }
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
        assertEquals(Verification.UnsignedAccepted, auth.authenticate(o, key, true))
    }

    @Test fun noTrustedKeyRejectsSignedPayload() {
        assertTrue(auth.authenticate(obj("qr_signed.json"), null, false) is Verification.Rejected)
    }

    @Test fun algorithmMismatchRejected() {
        val o = obj("import_signed.json").also { it.addProperty("algorithm", "RSA-2048") }
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
    }

    @Test fun parserRejectsBadInput() {
        fun bad(json: String) {
            try { PayloadParser.parseQr(PayloadParser.parseObject(json)); fail("accepted: $json") }
            catch (e: PayloadException) { /* expected */ }
        }
        val base = """"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001","device_name":"x","authorized_user":"a""""
        bad("{}")
        bad("[1]")
        bad("{$base,\"permissions\":[\"root\"]}".replace("\"authorized_user\":\"a\"", "\"authorized_user\":\"a\""))
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"BAD","device_name":"x","authorized_user":"a"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001","device_name":"x"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001","device_name":"x","authorized_user":"a","expires_at":1.5}""")
    }

    @Test fun importRejectsDuplicateIds() {
        val o = obj("import_signed.json")
        o.getAsJsonArray("devices")[1].asJsonObject.addProperty("device_id", "NRB-DEV-001")
        try { PayloadParser.parseImport(o); fail() } catch (e: PayloadException) { assertTrue(e.message!!.contains("Duplicate")) }
    }
}
