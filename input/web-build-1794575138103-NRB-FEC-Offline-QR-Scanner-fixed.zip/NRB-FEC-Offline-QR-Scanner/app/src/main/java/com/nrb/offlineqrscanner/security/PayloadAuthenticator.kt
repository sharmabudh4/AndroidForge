package com.nrb.offlineqrscanner.security

import com.google.gson.JsonObject
import com.nrb.offlineqrscanner.utils.CryptoUtils
import java.security.PublicKey

sealed class Verification {
    /** Signature present and valid for the trusted key. */
    object Verified : Verification()

    /** No verifiable signature, accepted only because "allow unsigned" demo mode is on. */
    object UnsignedAccepted : Verification()

    data class Rejected(val reason: String) : Verification()
}

/**
 * Authenticates a QR code or import file.
 * Signed bytes = canonical JSON of the object without its `signature` and `sha256` fields.
 */
class PayloadAuthenticator(private val verifier: SignatureVerifier) {

    companion object {
        val EXCLUDED_FIELDS = setOf("signature", "sha256")
    }

    fun authenticate(obj: JsonObject, key: PublicKey?, allowUnsigned: Boolean): Verification {
        val canonical = CanonicalJson.toBytes(obj, EXCLUDED_FIELDS)

        val sha = obj.get("sha256")
        if (sha != null && !sha.isJsonNull) {
            if (!sha.isJsonPrimitive || !sha.asJsonPrimitive.isString) return Verification.Rejected("Invalid checksum field")
            if (!sha.asString.equals(CryptoUtils.sha256Hex(canonical), ignoreCase = true))
                return Verification.Rejected("Checksum mismatch - file is corrupted or was modified")
        }

        val sigEl = obj.get("signature")
        val signature = if (sigEl == null || sigEl.isJsonNull) null else {
            if (!sigEl.isJsonPrimitive || !sigEl.asJsonPrimitive.isString) return Verification.Rejected("Invalid signature field")
            sigEl.asString.ifBlank { null }
        }

        if (signature == null) {
            return if (allowUnsigned) Verification.UnsignedAccepted else Verification.Rejected("Missing digital signature")
        }
        if (key == null) {
            return if (allowUnsigned) Verification.UnsignedAccepted
            else Verification.Rejected("No trusted public key installed (Settings > Install trusted key)")
        }

        val algEl = obj.get("algorithm")
        if (algEl != null && !algEl.isJsonNull) {
            val declared = if (algEl.isJsonPrimitive) algEl.asString else ""
            if (declared != PemUtils.algorithmName(key))
                return Verification.Rejected("Signature algorithm '$declared' does not match the trusted key")
        }

        return if (verifier.verify(canonical, signature, key)) Verification.Verified
        else Verification.Rejected("Invalid digital signature")
    }
}
