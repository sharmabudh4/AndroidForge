package com.nrb.offlineqrscanner.screens.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity
import com.nrb.offlineqrscanner.databinding.ItemScanHistoryBinding
import com.nrb.offlineqrscanner.service.ScanResultCode
import com.nrb.offlineqrscanner.utils.formatDateTime

class ScanHistoryAdapter :
    ListAdapter<ScanHistoryEntity, ScanHistoryAdapter.Holder>(object : DiffUtil.ItemCallback<ScanHistoryEntity>() {
        override fun areItemsTheSame(a: ScanHistoryEntity, b: ScanHistoryEntity) = a.rowId == b.rowId
        override fun areContentsTheSame(a: ScanHistoryEntity, b: ScanHistoryEntity) = a == b
    }) {

    class Holder(val binding: ItemScanHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemScanHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val s = getItem(position)
        with(holder.binding) {
            tvDeviceName.text = s.deviceName
            tvDeviceId.text = s.deviceId
            tvReason.text = s.reason
            tvDeviceTime.text = formatDateTime(s.scanTime)
            tvResultIcon.text = when (s.result) {
                ScanResultCode.SUCCESS -> "\u2713"
                ScanResultCode.DUPLICATE -> "\u26A0"
                else -> "\u2715"
            }
        }
    }
}
