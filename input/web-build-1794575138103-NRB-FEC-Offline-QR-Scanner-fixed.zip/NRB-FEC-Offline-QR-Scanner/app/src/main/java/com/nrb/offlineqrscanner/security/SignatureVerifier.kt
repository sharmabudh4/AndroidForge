package com.nrb.offlineqrscanner.security

import com.nrb.offlineqrscanner.utils.CryptoUtils
import java.security.KeyFactory
import java.security.PublicKey
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.X509EncodedKeySpec

/** Decodes standard Base64 (padding and line breaks tolerated). Injected so the logic is JVM-testable. */
typealias Base64Decoder = (String) -> ByteArray

/** ECDSA-P256 / RSA-2048 signature verification (SHA-256, DER-encoded ECDSA signatures). */
class SignatureVerifier(private val base64: Base64Decoder) {

    fun verify(data: ByteArray, signatureB64: String, key: PublicKey): Boolean {
        val algorithm = when (key) {
            is ECPublicKey -> "SHA256withECDSA"
            is RSAPublicKey -> "SHA256withRSA"
            else -> return false
        }
        return try {
            val sig = Signature.getInstance(algorithm)
            sig.initVerify(key)
            sig.update(data)
            sig.verify(base64(signatureB64.trim()))
        } catch (e: Exception) {
            false
        }
    }
}

/** Parsing and fingerprinting of PEM ("BEGIN PUBLIC KEY", X.509 SubjectPublicKeyInfo) keys. */
object PemUtils {

    fun parsePublicKey(pem: String, base64: Base64Decoder): PublicKey {
        val body = pem.lineSequence()
            .filterNot { it.startsWith("-----") }
            .joinToString("") { it.trim() }
        require(body.isNotEmpty()) { "Empty key" }
        val spec = X509EncodedKeySpec(base64(body))
        val key = listOf("EC", "RSA").firstNotNullOfOrNull { alg ->
            try { KeyFactory.getInstance(alg).generatePublic(spec) } catch (e: Exception) { null }
        } ?: throw IllegalArgumentException("Not a supported public key (EC P-256 or RSA-2048+)")
        when (key) {
            is ECPublicKey -> require(key.params.curve.field.fieldSize == 256) { "EC key must be P-256" }
            is RSAPublicKey -> require(key.modulus.bitLength() >= 2048) { "RSA key must be at least 2048 bits" }
        }
        return key
    }

    /** SHA-256 of the DER-encoded key, shown to the user to compare with the PC application. */
    fun fingerprint(key: PublicKey): String = CryptoUtils.sha256Hex(key.encoded)

    fun algorithmName(key: PublicKey): String = when (key) {
        is ECPublicKey -> "ECDSA-P256"
        is RSAPublicKey -> "RSA-2048"
        else -> "UNKNOWN"
    }
}
