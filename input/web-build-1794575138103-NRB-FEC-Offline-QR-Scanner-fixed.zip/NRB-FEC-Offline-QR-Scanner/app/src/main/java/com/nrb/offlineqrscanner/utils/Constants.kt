package com.nrb.offlineqrscanner.utils

/** Intent extra keys shared between screens. */
object Extras {
    const val DEVICE_ID = "device_id"
    const val DEVICE_NAME = "device_name"
    const val AUTHORIZED_USER = "authorized_user"
    const val PERMISSIONS = "permissions"
    const val REASON = "reason"
    const val UNSIGNED_DEMO = "unsigned_demo"
}
