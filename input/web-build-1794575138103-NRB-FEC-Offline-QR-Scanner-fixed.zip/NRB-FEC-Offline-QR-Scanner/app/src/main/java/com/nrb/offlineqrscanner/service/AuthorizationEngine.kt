package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.models.PermissionModel
import com.nrb.offlineqrscanner.models.QrPayload

/** Result codes stored in scan_history.result. */
object ScanResultCode {
    const val SUCCESS = 0
    const val DUPLICATE = 1
    const val FAILURE = 2
    const val EXPIRED = 3
    const val UNKNOWN = 4
}

/** Local authorization record (decoupled from Room so the rules are unit-testable). */
data class DeviceRecord(
    val id: String,
    val name: String,
    val authorizedUser: String,
    val permissions: List<String>,
    val isActive: Boolean
)

sealed class Decision {
    data class Grant(val permissions: Set<PermissionModel>) : Decision()
    data class Deny(val reason: String, val resultCode: Int) : Decision()
}

object AuthorizationEngine {
    const val CLOCK_SKEW_SECONDS = 300L

    /**
     * The QR can only ever narrow access: effective permissions are the intersection of what the
     * QR claims and what the locally imported (signed) database allows.
     */
    fun decide(qr: QrPayload, device: DeviceRecord?, nowSeconds: Long): Decision {
        if (qr.expiresAt != 0L && nowSeconds > qr.expiresAt)
            return Decision.Deny("QR code has expired", ScanResultCode.EXPIRED)
        if (qr.issuedAt > nowSeconds + CLOCK_SKEW_SECONDS)
            return Decision.Deny("QR code is dated in the future (check this device's clock)", ScanResultCode.FAILURE)
        if (device == null)
            return Decision.Deny("Device is not in the local authorization database", ScanResultCode.UNKNOWN)
        if (!device.isActive)
            return Decision.Deny("Authorization for this device has been revoked", ScanResultCode.FAILURE)
        if (!device.authorizedUser.equals(qr.authorizedUser, ignoreCase = true))
            return Decision.Deny("User is not authorized for this device", ScanResultCode.FAILURE)

        val effective = PermissionModel.expand(qr.permissions).intersect(PermissionModel.expand(device.permissions))
        if (effective.isEmpty())
            return Decision.Deny("No permissions granted for this device", ScanResultCode.FAILURE)
        return Decision.Grant(effective)
    }
}
