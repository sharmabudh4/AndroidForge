package com.nrb.offlineqrscanner.screens.scanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityScanBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.denied.AccessDeniedActivity
import com.nrb.offlineqrscanner.screens.granted.AccessGrantedActivity
import com.nrb.offlineqrscanner.service.ScanOutcome
import com.nrb.offlineqrscanner.utils.CryptoUtils
import com.nrb.offlineqrscanner.utils.Extras
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Live camera scanning (CameraX + ML Kit). On a decoded QR it runs the full offline authorization pipeline. */
class ScanQRActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScanBinding
    private lateinit var analysisExecutor: ExecutorService
    private var cameraProvider: ProcessCameraProvider? = null
    private val busy = AtomicBoolean(false)

    private val scanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        )
    }

    private val cameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else binding.tvStatus.setText(R.string.camera_permission_denied)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        analysisExecutor = Executors.newSingleThreadExecutor()
        binding.btnClose.setOnClickListener { finish() }
        binding.tvStatus.setText(R.string.scan_hint)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(analysisExecutor, ::analyze) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                binding.tvStatus.setText(R.string.camera_error)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || busy.get()) {
            proxy.close()
            return
        }
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(input)
            .addOnSuccessListener { codes ->
                codes.firstNotNullOfOrNull { it.rawValue }?.let(::onQrDecoded) // main thread
            }
            .addOnCompleteListener { proxy.close() }
    }

    private fun onQrDecoded(raw: String) {
        if (!busy.compareAndSet(false, true)) return
        if (nrbApp.duplicates.isDuplicate(CryptoUtils.sha256Hex(raw))) {
            binding.tvStatus.setText(R.string.duplicate_scan)
            busy.set(false)
            return
        }
        binding.tvStatus.setText(R.string.verifying)
        lifecycleScope.launch {
            val outcome = try {
                nrbApp.authorization.authorize(raw)
            } catch (e: Exception) {
                ScanOutcome.Denied(null, null, getString(R.string.error_general))
            }
            when (outcome) {
                is ScanOutcome.Granted -> startActivity(Intent(this@ScanQRActivity, AccessGrantedActivity::class.java).apply {
                    putExtra(Extras.DEVICE_ID, outcome.deviceId)
                    putExtra(Extras.DEVICE_NAME, outcome.deviceName)
                    putExtra(Extras.AUTHORIZED_USER, outcome.authorizedUser)
                    putStringArrayListExtra(Extras.PERMISSIONS, ArrayList(outcome.permissionCodes))
                    putExtra(Extras.UNSIGNED_DEMO, outcome.unsignedDemo)
                })
                is ScanOutcome.Denied -> startActivity(Intent(this@ScanQRActivity, AccessDeniedActivity::class.java).apply {
                    putExtra(Extras.DEVICE_ID, outcome.deviceId)
                    putExtra(Extras.DEVICE_NAME, outcome.deviceName)
                    putExtra(Extras.REASON, outcome.reason)
                })
            }
            finish()
        }
    }

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        scanner.close()
        analysisExecutor.shutdown()
        super.onDestroy()
    }
}
