package com.nrb.offlineqrscanner.screens.importdata

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityImportBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.importeddevices.ImportedDevicesActivity
import com.nrb.offlineqrscanner.service.ImportResult
import com.nrb.offlineqrscanner.service.ImportService
import com.nrb.offlineqrscanner.utils.readLimited
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Picks the authorization file exported by the PC application (Storage Access Framework, no storage permission needed). */
class ImportDatabaseActivity : AppCompatActivity() {
    private lateinit var binding: ActivityImportBinding

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runImport(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSelectFile.setOnClickListener { picker.launch(arrayOf("*/*")) }
        binding.btnViewDevices.setOnClickListener {
            startActivity(Intent(this, ImportedDevicesActivity::class.java))
            finish()
        }
    }

    private fun runImport(uri: Uri) {
        binding.cardResult.visibility = View.GONE
        binding.progressImport.visibility = View.VISIBLE
        binding.btnSelectFile.isEnabled = false

        lifecycleScope.launch {
            val name = displayName(uri)
            val result = withContext(Dispatchers.IO) {
                val bytes = try {
                    contentResolver.openInputStream(uri)?.use { it.readLimited(ImportService.MAX_IMPORT_BYTES) }
                } catch (e: Exception) {
                    null
                }
                when {
                    bytes == null -> ImportResult.Error(getString(R.string.import_read_error))
                    else -> nrbApp.importService.importFile(bytes, name)
                }
            }
            binding.progressImport.visibility = View.GONE
            binding.btnSelectFile.isEnabled = true
            binding.cardResult.visibility = View.VISIBLE
            when (result) {
                is ImportResult.Success -> {
                    binding.tvResultTitle.setText(R.string.import_success)
                    binding.tvResultMessage.text = buildString {
                        append(resources.getQuantityString(R.plurals.devices_imported_msg, result.deviceCount, result.deviceCount))
                        if (result.unsignedDemo) append("\n").append(getString(R.string.unsigned_demo_warning))
                    }
                    binding.btnViewDevices.visibility = View.VISIBLE
                }
                is ImportResult.Error -> {
                    binding.tvResultTitle.setText(R.string.import_failed)
                    binding.tvResultMessage.text = result.message
                    binding.btnViewDevices.visibility = View.GONE
                }
            }
        }
    }

    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    } ?: "import.json"
}
