package com.nrb.offlineqrscanner.screens.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityHomeBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.history.ScanHistoryActivity
import com.nrb.offlineqrscanner.screens.importdata.ImportDatabaseActivity
import com.nrb.offlineqrscanner.screens.importeddevices.ImportedDevicesActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.screens.settings.SettingsActivity
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnScanQr.setOnClickListener { startActivity(Intent(this, ScanQRActivity::class.java)) }
        binding.btnImport.setOnClickListener { startActivity(Intent(this, ImportDatabaseActivity::class.java)) }
        binding.btnViewDevices.setOnClickListener { startActivity(Intent(this, ImportedDevicesActivity::class.java)) }
        binding.btnViewHistory.setOnClickListener { startActivity(Intent(this, ScanHistoryActivity::class.java)) }
        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val devices = nrbApp.database.deviceDao().countActive()
            val scans = nrbApp.database.scanHistoryDao().count()
            binding.tvDeviceCount.text = resources.getQuantityString(R.plurals.devices_imported, devices, devices)
            binding.tvHistoryCount.text = resources.getQuantityString(R.plurals.scans_recorded, scans, scans)
        }
        val hasKey = nrbApp.keyStore.load() != null
        binding.tvSecurityStatus.text = when {
            hasKey -> getString(R.string.status_key_installed)
            nrbApp.settings.allowUnsigned -> getString(R.string.status_demo_mode)
            else -> getString(R.string.status_no_key)
        }
    }
}
