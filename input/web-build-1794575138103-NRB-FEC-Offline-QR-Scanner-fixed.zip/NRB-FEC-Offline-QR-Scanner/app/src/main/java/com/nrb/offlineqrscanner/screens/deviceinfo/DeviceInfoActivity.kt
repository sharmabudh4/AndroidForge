package com.nrb.offlineqrscanner.screens.deviceinfo

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityDeviceInfoBinding
import com.nrb.offlineqrscanner.models.PermissionModel
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.formatDateTime
import kotlinx.coroutines.launch

/**
 * Device details. When opened right after a scan, [Extras.PERMISSIONS] holds the permissions granted
 * for that scan and technical fields are only shown if view_tech_spec was granted.
 */
class DeviceInfoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDeviceInfoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeviceInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val deviceId = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        val grantedForScan = intent.getStringArrayListExtra(Extras.PERMISSIONS)

        lifecycleScope.launch {
            val device = nrbApp.database.deviceDao().getById(deviceId)
            if (device == null) {
                binding.tvDeviceName.setText(R.string.unknown_device)
                return@launch
            }
            val stored: List<String> = Gson().fromJson(device.permissionsJson, object : TypeToken<List<String>>() {}.type)
            val shown = grantedForScan ?: PermissionModel.expand(stored).map { it.code }

            binding.tvDeviceName.text = device.name
            binding.tvDeviceId.text = device.id
            binding.tvAuthorizedUser.text = device.authorizedUsername
            binding.tvStatus.setText(if (device.isActive) R.string.status_active else R.string.status_revoked)
            binding.tvCreatedAt.text = formatDateTime(device.importedAt)
            shown.forEach { binding.chipGroupPermissions.addView(Chip(this@DeviceInfoActivity).apply { text = PermissionModel.fromCode(it)?.label ?: it }) }

            val techAllowed = grantedForScan == null || PermissionModel.VIEW_TECH_SPEC.code in grantedForScan
            binding.containerTech.visibility = if (techAllowed) View.VISIBLE else View.GONE
            binding.tvAddress.text = device.deviceAddress ?: getString(R.string.not_available)
            binding.tvSerial.text = device.deviceSerial ?: getString(R.string.not_available)
        }
    }
}
