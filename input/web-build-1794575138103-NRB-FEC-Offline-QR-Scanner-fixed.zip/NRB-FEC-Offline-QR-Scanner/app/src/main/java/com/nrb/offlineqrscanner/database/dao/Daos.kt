package com.nrb.offlineqrscanner.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ImportRecordEntity
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity

@Dao
interface DeviceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(devices: List<DeviceEntity>)

    @Query("SELECT * FROM devices WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DeviceEntity?

    @Query("SELECT * FROM devices ORDER BY name COLLATE NOCASE ASC")
    suspend fun getAll(): List<DeviceEntity>

    @Query("SELECT COUNT(*) FROM devices WHERE isActive = 1")
    suspend fun countActive(): Int

    @Query("UPDATE devices SET isActive = 0")
    suspend fun deactivateAll()

    @Query("DELETE FROM devices")
    suspend fun deleteAll()
}

@Dao
interface ImportRecordDao {
    @Insert
    suspend fun insert(record: ImportRecordEntity)

    @Query("DELETE FROM import_records")
    suspend fun deleteAll()
}

@Dao
interface ScanHistoryDao {
    @Insert
    suspend fun insert(entity: ScanHistoryEntity)

    @Query("SELECT * FROM scan_history ORDER BY scanTime DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<ScanHistoryEntity>

    @Query("SELECT COUNT(*) FROM scan_history")
    suspend fun count(): Int

    @Query("DELETE FROM scan_history")
    suspend fun clearAll()
}
