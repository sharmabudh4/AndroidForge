package com.nrb.offlineqrscanner.screens.history

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityScanHistoryBinding
import com.nrb.offlineqrscanner.nrbApp
import kotlinx.coroutines.launch

class ScanHistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScanHistoryBinding
    private val adapter = ScanHistoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = adapter

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.confirm_clear_history)
                .setPositiveButton(R.string.clear_history) { _, _ ->
                    lifecycleScope.launch {
                        nrbApp.database.scanHistoryDao().clearAll()
                        load()
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { load() }
    }

    private suspend fun load() {
        val scans = nrbApp.database.scanHistoryDao().getRecent(500)
        adapter.submitList(scans)
        binding.tvEmpty.visibility = if (scans.isEmpty()) View.VISIBLE else View.GONE
    }
}
