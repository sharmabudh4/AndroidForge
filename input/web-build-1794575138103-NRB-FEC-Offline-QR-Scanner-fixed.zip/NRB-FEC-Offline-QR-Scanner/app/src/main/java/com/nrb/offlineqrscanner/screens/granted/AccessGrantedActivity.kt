package com.nrb.offlineqrscanner.screens.granted

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAccessGrantedBinding
import com.nrb.offlineqrscanner.models.PermissionModel
import com.nrb.offlineqrscanner.screens.deviceinfo.DeviceInfoActivity
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.utils.Extras

class AccessGrantedActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAccessGrantedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccessGrantedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val deviceId = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        val permissions = intent.getStringArrayListExtra(Extras.PERMISSIONS) ?: arrayListOf()

        binding.tvDeviceName.text = intent.getStringExtra(Extras.DEVICE_NAME)
        binding.tvDeviceId.text = deviceId
        binding.tvAuthorizedUser.text = getString(R.string.authorized_user_fmt, intent.getStringExtra(Extras.AUTHORIZED_USER))
        if (intent.getBooleanExtra(Extras.UNSIGNED_DEMO, false)) binding.tvSubtitle.setText(R.string.unsigned_demo_warning)

        for (code in permissions) {
            binding.chipGroupPermissions.addView(Chip(this).apply { text = PermissionModel.fromCode(code)?.label ?: code })
        }

        binding.btnViewDevice.setOnClickListener {
            startActivity(Intent(this, DeviceInfoActivity::class.java).apply {
                putExtra(Extras.DEVICE_ID, deviceId)
                putStringArrayListExtra(Extras.PERMISSIONS, permissions)
            })
        }
        binding.btnScanAgain.setOnClickListener {
            startActivity(Intent(this, ScanQRActivity::class.java))
            finish()
        }
        binding.btnHome.setOnClickListener { goHome() }
    }

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}
