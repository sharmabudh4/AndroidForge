package com.nrb.offlineqrscanner.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One imported device authorization. [permissionsJson] is a JSON array of permission codes. */
@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val authorizedUsername: String,
    val permissionsJson: String,
    val deviceAddress: String? = null,
    val deviceSerial: String? = null,
    val importedAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)

@Entity(tableName = "import_records")
data class ImportRecordEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val fileName: String,
    val importTime: Long = System.currentTimeMillis(),
    val deviceCount: Int,
    val success: Boolean,
    val message: String
)

/** Audit trail of scan attempts. [result] uses [com.nrb.offlineqrscanner.service.ScanResultCode]. */
@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val deviceId: String,
    val deviceName: String,
    val scanTime: Long = System.currentTimeMillis(),
    val result: Int,
    val reason: String
)
