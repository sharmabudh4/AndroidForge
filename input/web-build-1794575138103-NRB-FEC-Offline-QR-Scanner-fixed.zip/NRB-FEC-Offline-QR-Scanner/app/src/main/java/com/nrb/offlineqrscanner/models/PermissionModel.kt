package com.nrb.offlineqrscanner.models

/**
 * Permission codes shared with the PC QR Generator (see docs/QR_FORMAT.md).
 * The wildcard code "*" expands to every permission.
 */
enum class PermissionModel(val code: String, val label: String) {
    VIEW_DEVICE_INFO("view_device_info", "View Device Information"),
    VIEW_TECH_SPEC("view_tech_spec", "View Technical Specifications"),
    VIEW_DOCS("view_docs", "View Documents & Manuals"),
    DOWNLOAD_EXPORT("download_export", "Download / Export Files"),
    VIEW_DEVICE_RELATED("view_device_related", "View Other Device Information");

    companion object {
        const val WILDCARD = "*"

        fun fromCode(code: String): PermissionModel? = values().firstOrNull { it.code == code }

        fun isValidCode(code: String): Boolean = code == WILDCARD || fromCode(code) != null

        /** Expands a list of codes (possibly containing "*") into concrete permissions. */
        fun expand(codes: Collection<String>): Set<PermissionModel> =
            if (codes.contains(WILDCARD)) values().toSet() else codes.mapNotNull { fromCode(it) }.toSet()
    }
}
