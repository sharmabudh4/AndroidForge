package com.nrb.offlineqrscanner.models

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/** Thrown for any malformed QR / import payload. The message is safe to show to the user. */
class PayloadException(message: String) : Exception(message)

const val QR_FORMAT = "NRB-FEC-QR-1.0"
const val IMPORT_FORMAT = "NRB-FEC-IMPORT-1.0"

data class QrPayload(
    val deviceId: String,
    val deviceName: String,
    val authorizedUser: String,
    val permissions: List<String>,
    val issuedAt: Long,
    val expiresAt: Long,
    val deviceAddress: String?,
    val deviceSerial: String?
)

data class ImportDevice(
    val deviceId: String,
    val deviceName: String,
    val authorizedUser: String,
    val permissions: List<String>,
    val deviceAddress: String?,
    val deviceSerial: String?
)

data class ImportPayload(
    val generatedAt: Long,
    val appVersion: String,
    val devices: List<ImportDevice>
)

/**
 * Strict field-by-field parser (snake_case JSON as specified in docs/).
 * Deliberately does NOT use reflection-based Gson mapping, so a missing field can never
 * silently become null / a default value.
 */
object PayloadParser {
    private val DEVICE_ID = Regex("^NRB-DEV-\\d{3,5}$")
    const val MAX_QR_CHARS = 8192

    fun parseObject(raw: String): JsonObject {
        val element = try {
            JsonParser.parseString(raw)
        } catch (e: Exception) {
            throw PayloadException("Not valid JSON")
        }
        if (!element.isJsonObject) throw PayloadException("JSON root must be an object")
        return element.asJsonObject
    }

    fun parseQr(obj: JsonObject): QrPayload {
        val format = reqString(obj, "format")
        if (format != QR_FORMAT) throw PayloadException("Unsupported QR format: $format")
        if (reqLong(obj, "version") != 1L) throw PayloadException("Unsupported QR version")
        return QrPayload(
            deviceId = reqDeviceId(obj),
            deviceName = reqString(obj, "device_name"),
            authorizedUser = reqString(obj, "authorized_user"),
            permissions = permissions(obj, required = false),
            issuedAt = optLong(obj, "issued_at"),
            expiresAt = optLong(obj, "expires_at"),
            deviceAddress = optString(obj, "device_address"),
            deviceSerial = optString(obj, "device_serial")
        )
    }

    fun parseImport(obj: JsonObject): ImportPayload {
        val format = reqString(obj, "format")
        if (format != IMPORT_FORMAT) throw PayloadException("Unsupported import format: $format")
        if (reqLong(obj, "version") != 1L) throw PayloadException("Unsupported import version")
        val generatedAt = reqLong(obj, "generated_at")
        val appVersion = reqString(obj, "app_version")
        val arr = obj.get("devices")
        if (arr == null || !arr.isJsonArray) throw PayloadException("'devices' must be an array")
        if (arr.asJsonArray.size() == 0) throw PayloadException("No device records found in file")

        val seen = HashSet<String>()
        val devices = arr.asJsonArray.mapIndexed { i, el ->
            if (!el.isJsonObject) throw PayloadException("devices[$i] must be an object")
            val d = el.asJsonObject
            val id = reqDeviceId(d)
            if (!seen.add(id)) throw PayloadException("Duplicate device_id: $id")
            ImportDevice(
                deviceId = id,
                deviceName = reqString(d, "device_name"),
                authorizedUser = reqString(d, "authorized_user"),
                permissions = permissions(d, required = true),
                deviceAddress = optString(d, "device_address"),
                deviceSerial = optString(d, "device_serial")
            )
        }
        return ImportPayload(generatedAt, appVersion, devices)
    }

    // ---- helpers -------------------------------------------------------------------------

    private fun reqDeviceId(o: JsonObject): String {
        val id = reqString(o, "device_id")
        if (!DEVICE_ID.matches(id)) throw PayloadException("Invalid device_id format: $id")
        return id
    }

    private fun prim(o: JsonObject, key: String): JsonElement? {
        val e = o.get(key) ?: return null
        if (e.isJsonNull) return null
        if (!e.isJsonPrimitive) throw PayloadException("Field '$key' has the wrong type")
        return e
    }

    private fun reqString(o: JsonObject, key: String): String {
        val e = prim(o, key) ?: throw PayloadException("Missing field: $key")
        if (!e.asJsonPrimitive.isString) throw PayloadException("Field '$key' must be a string")
        val s = e.asString.trim()
        if (s.isEmpty()) throw PayloadException("Field '$key' is empty")
        return s
    }

    private fun optString(o: JsonObject, key: String): String? {
        val e = prim(o, key) ?: return null
        if (!e.asJsonPrimitive.isString) throw PayloadException("Field '$key' must be a string")
        return e.asString.trim().ifEmpty { null }
    }

    private fun longOf(e: JsonElement, key: String): Long {
        val p = e.asJsonPrimitive
        if (!p.isNumber) throw PayloadException("Field '$key' must be an integer")
        return try {
            p.asBigDecimal.longValueExact()
        } catch (ex: ArithmeticException) {
            throw PayloadException("Field '$key' must be an integer")
        }
    }

    private fun reqLong(o: JsonObject, key: String): Long =
        longOf(prim(o, key) ?: throw PayloadException("Missing field: $key"), key)

    private fun optLong(o: JsonObject, key: String): Long {
        val v = longOf(prim(o, key) ?: return 0L, key)
        if (v < 0) throw PayloadException("Field '$key' must not be negative")
        return v
    }

    private fun permissions(o: JsonObject, required: Boolean): List<String> {
        val e = o.get("permissions")
        if (e == null || e.isJsonNull) {
            if (required) throw PayloadException("Missing field: permissions")
            return emptyList()
        }
        if (!e.isJsonArray) throw PayloadException("'permissions' must be an array")
        val out = ArrayList<String>()
        for (item in e.asJsonArray) {
            if (!item.isJsonPrimitive || !item.asJsonPrimitive.isString)
                throw PayloadException("'permissions' must contain strings")
            val code = item.asString
            if (!PermissionModel.isValidCode(code)) throw PayloadException("Unknown permission code: $code")
            if (code !in out) out.add(code)
        }
        return out
    }
}
