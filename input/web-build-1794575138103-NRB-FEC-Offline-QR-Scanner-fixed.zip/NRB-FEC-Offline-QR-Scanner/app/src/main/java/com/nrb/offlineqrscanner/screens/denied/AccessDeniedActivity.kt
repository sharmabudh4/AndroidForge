package com.nrb.offlineqrscanner.screens.denied

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAccessDeniedBinding
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.utils.Extras

class AccessDeniedActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAccessDeniedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccessDeniedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvDeviceName.text = intent.getStringExtra(Extras.DEVICE_NAME) ?: getString(R.string.unknown_device)
        binding.tvDeviceId.text = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        binding.tvReason.text = intent.getStringExtra(Extras.REASON) ?: getString(R.string.access_denied_reason)

        binding.btnScanAgain.setOnClickListener {
            startActivity(Intent(this, ScanQRActivity::class.java))
            finish()
        }
        binding.btnHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            finish()
        }
    }
}
