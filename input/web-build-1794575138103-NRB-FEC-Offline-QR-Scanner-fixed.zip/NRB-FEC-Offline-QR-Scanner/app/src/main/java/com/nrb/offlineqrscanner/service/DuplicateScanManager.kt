package com.nrb.offlineqrscanner.service

/** In-memory cooldown that stops the same QR code being processed repeatedly within a few seconds. */
class DuplicateScanManager(
    private val cooldownMs: Long = 3_000L,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val lastSeen = HashMap<String, Long>()

    /** Returns true if [key] was accepted less than the cooldown ago. Otherwise records it and returns false. */
    @Synchronized
    fun isDuplicate(key: String): Boolean {
        val now = clock()
        lastSeen.entries.removeAll { now - it.value >= cooldownMs }
        if (lastSeen.containsKey(key)) return true
        lastSeen[key] = now
        return false
    }
}
