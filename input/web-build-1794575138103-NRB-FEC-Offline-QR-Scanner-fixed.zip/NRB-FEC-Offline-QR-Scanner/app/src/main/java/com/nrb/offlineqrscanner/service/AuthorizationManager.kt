package com.nrb.offlineqrscanner.service

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nrb.offlineqrscanner.database.AppDatabase
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity
import com.nrb.offlineqrscanner.models.PayloadException
import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.TrustedKeyStore
import com.nrb.offlineqrscanner.security.Verification

sealed class ScanOutcome {
    data class Granted(
        val deviceId: String,
        val deviceName: String,
        val authorizedUser: String,
        val permissionCodes: List<String>,
        val unsignedDemo: Boolean
    ) : ScanOutcome()

    data class Denied(val deviceId: String?, val deviceName: String?, val reason: String) : ScanOutcome()
}

/** Full scan pipeline: parse -> authenticate -> local DB rules -> audit log. Entirely offline. */
class AuthorizationManager(
    private val db: AppDatabase,
    private val keyStore: TrustedKeyStore,
    private val settings: AppSettings,
    private val authenticator: PayloadAuthenticator
) {
    private val gson = Gson()
    private val listType = object : TypeToken<List<String>>() {}.type

    suspend fun authorize(raw: String): ScanOutcome {
        if (raw.length > PayloadParser.MAX_QR_CHARS) return deny(null, null, "QR code is too large", ScanResultCode.FAILURE)

        val obj = try { PayloadParser.parseObject(raw) } catch (e: PayloadException) {
            return deny(null, null, "Not an NRB FEC QR code (${e.message})", ScanResultCode.FAILURE)
        }
        val qr = try { PayloadParser.parseQr(obj) } catch (e: PayloadException) {
            return deny(null, null, "Invalid QR code: ${e.message}", ScanResultCode.FAILURE)
        }

        val verification = authenticator.authenticate(obj, keyStore.load(), settings.allowUnsigned)
        if (verification is Verification.Rejected)
            return deny(qr.deviceId, qr.deviceName, verification.reason, ScanResultCode.FAILURE)

        val entity = db.deviceDao().getById(qr.deviceId)
        val record = entity?.let {
            DeviceRecord(it.id, it.name, it.authorizedUsername, gson.fromJson<List<String>>(it.permissionsJson, listType), it.isActive)
        }

        return when (val decision = AuthorizationEngine.decide(qr, record, System.currentTimeMillis() / 1000)) {
            is Decision.Deny -> deny(qr.deviceId, entity?.name ?: qr.deviceName, decision.reason, decision.resultCode)
            is Decision.Grant -> {
                val name = entity!!.name
                log(qr.deviceId, name, ScanResultCode.SUCCESS, "Access granted")
                ScanOutcome.Granted(
                    deviceId = qr.deviceId,
                    deviceName = name,
                    authorizedUser = entity.authorizedUsername,
                    permissionCodes = decision.permissions.map { it.code },
                    unsignedDemo = verification is Verification.UnsignedAccepted
                )
            }
        }
    }

    private suspend fun deny(deviceId: String?, name: String?, reason: String, code: Int): ScanOutcome.Denied {
        log(deviceId ?: "UNKNOWN", name ?: "Unknown", code, reason)
        return ScanOutcome.Denied(deviceId, name, reason)
    }

    // Never stores the raw QR content - only the outcome.
    private suspend fun log(deviceId: String, name: String, code: Int, reason: String) {
        db.scanHistoryDao().insert(ScanHistoryEntity(deviceId = deviceId, deviceName = name, result = code, reason = reason))
    }
}
