package com.nrb.offlineqrscanner.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.nrb.offlineqrscanner.database.dao.DeviceDao
import com.nrb.offlineqrscanner.database.dao.ImportRecordDao
import com.nrb.offlineqrscanner.database.dao.ScanHistoryDao
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ImportRecordEntity
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity

/**
 * Local authorization database.
 * No destructive-migration fallback on purpose: silently wiping authorizations is worse than a
 * crash during development. Add a real Migration when the schema changes.
 */
@Database(
    entities = [DeviceEntity::class, ImportRecordEntity::class, ScanHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun importRecordDao(): ImportRecordDao
    abstract fun scanHistoryDao(): ScanHistoryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "nrb_fec_offline_db")
                .build().also { instance = it }
        }
    }
}
