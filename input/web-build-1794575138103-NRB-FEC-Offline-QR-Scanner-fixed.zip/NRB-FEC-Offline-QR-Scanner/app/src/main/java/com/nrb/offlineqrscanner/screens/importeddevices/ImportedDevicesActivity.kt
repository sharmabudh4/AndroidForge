package com.nrb.offlineqrscanner.screens.importeddevices

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nrb.offlineqrscanner.databinding.ActivityImportedDevicesBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.deviceinfo.DeviceInfoActivity
import com.nrb.offlineqrscanner.screens.importdata.ImportDatabaseActivity
import com.nrb.offlineqrscanner.utils.Extras
import kotlinx.coroutines.launch

class ImportedDevicesActivity : AppCompatActivity() {
    private lateinit var binding: ActivityImportedDevicesBinding
    private val adapter = DeviceAdapter { device ->
        startActivity(Intent(this, DeviceInfoActivity::class.java).putExtra(Extras.DEVICE_ID, device.id))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImportedDevicesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = adapter
        binding.btnImportMore.setOnClickListener { startActivity(Intent(this, ImportDatabaseActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            val devices = nrbApp.database.deviceDao().getAll()
            adapter.submitList(devices)
            binding.tvEmpty.visibility = if (devices.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
