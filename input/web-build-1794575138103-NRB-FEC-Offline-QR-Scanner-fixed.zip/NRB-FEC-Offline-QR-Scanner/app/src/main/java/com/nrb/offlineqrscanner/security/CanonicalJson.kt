package com.nrb.offlineqrscanner.security

import com.google.gson.JsonElement

/**
 * Canonical JSON serialisation used as the byte string that gets signed.
 *
 * Rules (identical to Python's
 * `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`):
 *  - object keys sorted ascending, no whitespace
 *  - strings: escape `"` `\` and control chars (\b \f \n \r \t, others as \u00xx lower-case hex);
 *    all other characters are emitted as-is
 *  - numbers: emitted exactly as they appear in the source JSON (use integers only)
 *  - output is encoded as UTF-8
 *
 * [excludeTopLevel] removes the named keys from the top-level object only
 * (used to drop `signature` and `sha256` before signing / hashing).
 */
object CanonicalJson {

    fun serialize(element: JsonElement, excludeTopLevel: Set<String> = emptySet()): String {
        val sb = StringBuilder()
        write(element, sb, excludeTopLevel)
        return sb.toString()
    }

    fun toBytes(element: JsonElement, excludeTopLevel: Set<String> = emptySet()): ByteArray =
        serialize(element, excludeTopLevel).toByteArray(Charsets.UTF_8)

    private fun write(e: JsonElement, sb: StringBuilder, exclude: Set<String>) {
        when {
            e.isJsonNull -> sb.append("null")
            e.isJsonPrimitive -> {
                val p = e.asJsonPrimitive
                when {
                    p.isBoolean -> sb.append(if (p.asBoolean) "true" else "false")
                    p.isNumber -> sb.append(p.asString)
                    else -> writeString(p.asString, sb)
                }
            }
            e.isJsonArray -> {
                sb.append('[')
                e.asJsonArray.forEachIndexed { i, item ->
                    if (i > 0) sb.append(',')
                    write(item, sb, emptySet())
                }
                sb.append(']')
            }
            else -> {
                val obj = e.asJsonObject
                sb.append('{')
                var first = true
                for (key in obj.keySet().filter { it !in exclude }.sorted()) {
                    if (!first) sb.append(',')
                    first = false
                    writeString(key, sb)
                    sb.append(':')
                    write(obj.get(key), sb, emptySet())
                }
                sb.append('}')
            }
        }
    }

    private fun writeString(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\b' -> sb.append("\\b")
                c == '\u000c' -> sb.append("\\f")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}
