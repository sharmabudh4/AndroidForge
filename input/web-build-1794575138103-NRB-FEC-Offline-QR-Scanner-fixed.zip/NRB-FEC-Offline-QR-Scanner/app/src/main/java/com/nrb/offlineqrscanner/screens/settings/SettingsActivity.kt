package com.nrb.offlineqrscanner.screens.settings

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.withTransaction
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivitySettingsBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.service.ScanResultCode
import com.nrb.offlineqrscanner.utils.csvField
import com.nrb.offlineqrscanner.utils.formatDateTime
import com.nrb.offlineqrscanner.utils.readLimited
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    private val keyPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::confirmKey) }
    private val csvSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> uri?.let(::exportHistory) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.tvAppVersion.text = getString(
            R.string.version_fmt,
            packageManager.getPackageInfo(packageName, 0).versionName
        )

        binding.btnInstallKey.setOnClickListener { keyPicker.launch(arrayOf("*/*")) }
        binding.btnExport.setOnClickListener { csvSaver.launch("nrb_fec_scan_history.csv") }
        binding.btnClearDb.setOnClickListener { confirmClearDatabase() }

        binding.switchAllowUnsigned.isChecked = nrbApp.settings.allowUnsigned
        binding.switchAllowUnsigned.setOnCheckedChangeListener { button, checked ->
            if (checked && nrbApp.settings.allowUnsigned.not()) {
                button.isChecked = false // only turn on after confirmation
                AlertDialog.Builder(this)
                    .setTitle(R.string.allow_unsigned)
                    .setMessage(R.string.allow_unsigned_warning)
                    .setPositiveButton(R.string.enable) { _, _ ->
                        nrbApp.settings.allowUnsigned = true
                        button.isChecked = true
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            } else if (!checked) {
                nrbApp.settings.allowUnsigned = false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val count = nrbApp.database.deviceDao().countActive()
            binding.tvDbDeviceCount.text = resources.getQuantityString(R.plurals.devices_imported, count, count)
        }
        val fp = nrbApp.keyStore.fingerprint()
        binding.tvKeyStatus.text = if (fp == null) getString(R.string.status_no_key)
        else getString(R.string.key_fingerprint_fmt, fp.chunked(8).joinToString(" "))
    }

    private fun confirmKey(uri: Uri) {
        val pem = try {
            contentResolver.openInputStream(uri)?.use { it.readLimited(16 * 1024) }?.toString(Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
        val key = try { pem?.let { nrbApp.keyStore.parse(it) } } catch (e: Exception) { null }
        if (pem == null || key == null) {
            toast(getString(R.string.key_invalid))
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.install_trusted_key)
            .setMessage(getString(R.string.key_confirm_fmt, PemUtils.algorithmName(key), PemUtils.fingerprint(key).chunked(8).joinToString(" ")))
            .setPositiveButton(R.string.install) { _, _ ->
                nrbApp.keyStore.install(pem)
                refresh()
                toast(getString(R.string.key_installed))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun exportHistory(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val rows = nrbApp.database.scanHistoryDao().getRecent(Int.MAX_VALUE)
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { w ->
                        w.write("time,device_id,device_name,result,reason\r\n")
                        for (r in rows) {
                            w.write(listOf(formatDateTime(r.scanTime), r.deviceId, r.deviceName, resultName(r.result), r.reason)
                                .joinToString(",") { csvField(it) })
                            w.write("\r\n")
                        }
                    } != null
                } catch (e: Exception) {
                    false
                }
            }
            toast(getString(if (ok) R.string.export_done else R.string.export_failed))
        }
    }

    private fun resultName(code: Int) = when (code) {
        ScanResultCode.SUCCESS -> "granted"
        ScanResultCode.DUPLICATE -> "duplicate"
        ScanResultCode.EXPIRED -> "expired"
        ScanResultCode.UNKNOWN -> "unknown device"
        else -> "denied"
    }

    private fun confirmClearDatabase() {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_clear_db)
            .setPositiveButton(R.string.clear_database) { _, _ ->
                lifecycleScope.launch {
                    val db = nrbApp.database
                    db.withTransaction {
                        db.deviceDao().deleteAll()
                        db.scanHistoryDao().clearAll()
                        db.importRecordDao().deleteAll()
                    }
                    nrbApp.settings.lastImportGeneratedAt = 0L
                    refresh()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
