package com.nrb.offlineqrscanner.utils

import android.content.Context
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

fun Context.toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

fun formatDateTime(epochMillis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(Date(epochMillis))

/** RFC 4180 field quoting, plus a leading apostrophe against spreadsheet formula injection. */
fun csvField(value: String): String {
    val safe = if (value.isNotEmpty() && value[0] in "=+-@\t\r") "'$value" else value
    return "\"" + safe.replace("\"", "\"\"") + "\""
}

/** Reads at most [maxBytes]; returns null if the stream is larger. */
fun java.io.InputStream.readLimited(maxBytes: Int): ByteArray? {
    val out = java.io.ByteArrayOutputStream()
    val buf = ByteArray(8192)
    while (true) {
        val n = read(buf)
        if (n < 0) break
        out.write(buf, 0, n)
        if (out.size() > maxBytes) return null
    }
    return out.toByteArray()
}
