package com.nrb.offlineqrscanner.service

import androidx.room.withTransaction
import com.google.gson.Gson
import com.nrb.offlineqrscanner.database.AppDatabase
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ImportRecordEntity
import com.nrb.offlineqrscanner.models.PayloadException
import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.TrustedKeyStore
import com.nrb.offlineqrscanner.security.Verification

sealed class ImportResult {
    data class Success(val deviceCount: Int, val unsignedDemo: Boolean) : ImportResult()
    data class Error(val message: String) : ImportResult()
}

/**
 * Imports a PC-generated authorization file.
 * The file is a full snapshot: devices missing from it are deactivated, so revocations propagate.
 * All-or-nothing: any validation failure leaves the database untouched.
 */
class ImportService(
    private val db: AppDatabase,
    private val keyStore: TrustedKeyStore,
    private val settings: AppSettings,
    private val authenticator: PayloadAuthenticator
) {
    companion object { const val MAX_IMPORT_BYTES = 10 * 1024 * 1024 }

    private val gson = Gson()

    suspend fun importFile(bytes: ByteArray, fileName: String): ImportResult {
        val result = try {
            validateAndStore(bytes)
        } catch (e: PayloadException) {
            ImportResult.Error(e.message ?: "Invalid file")
        } catch (e: Exception) {
            ImportResult.Error("Import failed: ${e.message}")
        }
        // The audit row is written after (and outside) the data transaction, so failures are logged too.
        db.importRecordDao().insert(
            when (result) {
                is ImportResult.Success -> ImportRecordEntity(fileName = fileName, deviceCount = result.deviceCount, success = true, message = "Imported")
                is ImportResult.Error -> ImportRecordEntity(fileName = fileName, deviceCount = 0, success = false, message = result.message)
            }
        )
        return result
    }

    private suspend fun validateAndStore(bytes: ByteArray): ImportResult {
        if (bytes.size > MAX_IMPORT_BYTES) return ImportResult.Error("File is too large")
        val obj = PayloadParser.parseObject(bytes.toString(Charsets.UTF_8))
        val payload = PayloadParser.parseImport(obj)

        val verification = authenticator.authenticate(obj, keyStore.load(), settings.allowUnsigned)
        if (verification is Verification.Rejected) return ImportResult.Error(verification.reason)

        if (payload.generatedAt < settings.lastImportGeneratedAt)
            return ImportResult.Error("This file is older than the one already imported (rollback refused)")

        val now = System.currentTimeMillis()
        val entities = payload.devices.map {
            DeviceEntity(
                id = it.deviceId,
                name = it.deviceName,
                authorizedUsername = it.authorizedUser,
                permissionsJson = gson.toJson(it.permissions),
                deviceAddress = it.deviceAddress,
                deviceSerial = it.deviceSerial,
                importedAt = now,
                isActive = true
            )
        }
        db.withTransaction {
            db.deviceDao().deactivateAll()
            db.deviceDao().upsertAll(entities)
        }
        settings.lastImportGeneratedAt = payload.generatedAt
        return ImportResult.Success(entities.size, verification is Verification.UnsignedAccepted)
    }
}
