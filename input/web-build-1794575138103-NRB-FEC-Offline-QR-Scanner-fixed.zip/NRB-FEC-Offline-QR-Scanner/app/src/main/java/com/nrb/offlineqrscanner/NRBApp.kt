package com.nrb.offlineqrscanner

import android.app.Application
import android.content.Context
import com.nrb.offlineqrscanner.database.AppDatabase
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.security.TrustedKeyStore
import com.nrb.offlineqrscanner.security.androidBase64
import com.nrb.offlineqrscanner.service.AppSettings
import com.nrb.offlineqrscanner.service.AuthorizationManager
import com.nrb.offlineqrscanner.service.DuplicateScanManager
import com.nrb.offlineqrscanner.service.ImportService

/** Application class doubling as a tiny service locator (no DI framework needed for this size). */
class NRBApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val settings: AppSettings by lazy { AppSettings(this) }
    val keyStore: TrustedKeyStore by lazy { TrustedKeyStore(this) }
    val duplicates = DuplicateScanManager()

    private val authenticator by lazy { PayloadAuthenticator(SignatureVerifier(androidBase64)) }
    val authorization: AuthorizationManager by lazy { AuthorizationManager(database, keyStore, settings, authenticator) }
    val importService: ImportService by lazy { ImportService(database, keyStore, settings, authenticator) }
}

val Context.nrbApp: NRBApp get() = applicationContext as NRBApp
