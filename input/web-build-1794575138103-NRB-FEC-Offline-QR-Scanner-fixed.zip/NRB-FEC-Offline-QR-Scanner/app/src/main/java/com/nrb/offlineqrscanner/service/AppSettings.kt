package com.nrb.offlineqrscanner.service

import android.content.Context

class AppSettings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("nrb_settings", Context.MODE_PRIVATE)

    /** Demo mode: accept QR codes / import files that carry no verifiable signature. Off by default. */
    var allowUnsigned: Boolean
        get() = prefs.getBoolean("allow_unsigned", false)
        set(v) = prefs.edit().putBoolean("allow_unsigned", v).apply()

    /** generated_at (epoch seconds) of the newest accepted import file - used to refuse rollbacks. */
    var lastImportGeneratedAt: Long
        get() = prefs.getLong("last_import_generated_at", 0L)
        set(v) = prefs.edit().putLong("last_import_generated_at", v).apply()
}
