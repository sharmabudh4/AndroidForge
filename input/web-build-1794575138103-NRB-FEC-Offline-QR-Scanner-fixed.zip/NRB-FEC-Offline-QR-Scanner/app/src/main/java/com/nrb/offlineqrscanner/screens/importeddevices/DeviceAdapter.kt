package com.nrb.offlineqrscanner.screens.importeddevices

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.databinding.ItemDeviceBinding

class DeviceAdapter(private val onClick: (DeviceEntity) -> Unit) :
    ListAdapter<DeviceEntity, DeviceAdapter.Holder>(object : DiffUtil.ItemCallback<DeviceEntity>() {
        override fun areItemsTheSame(a: DeviceEntity, b: DeviceEntity) = a.id == b.id
        override fun areContentsTheSame(a: DeviceEntity, b: DeviceEntity) = a == b
    }) {

    class Holder(val binding: ItemDeviceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val d = getItem(position)
        holder.binding.tvDeviceName.text = d.name
        holder.binding.tvDeviceId.text = holder.itemView.context.getString(R.string.device_line_fmt, d.id, d.authorizedUsername)
        holder.binding.tvDeviceStatus.setText(if (d.isActive) R.string.status_active else R.string.status_revoked)
        holder.itemView.setOnClickListener { onClick(d) }
    }
}
