# Release builds currently run with minifyEnabled false. If you enable minification, the
# app needs no extra rules for its own code (no reflection-based JSON mapping is used);
# Room, CameraX and ML Kit ship their own consumer rules.
