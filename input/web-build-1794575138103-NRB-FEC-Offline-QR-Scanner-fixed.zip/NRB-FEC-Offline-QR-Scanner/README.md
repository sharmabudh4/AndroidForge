# NRB FEC Offline QR Scanner

Android app (Kotlin, min SDK 24) that scans QR codes and decides **offline** whether the holder is authorized for a device, using a signed authorization database exported by the companion PC QR Generator.

## How it works
1. **Install the trusted public key** of the PC generator (Settings > Install Trusted Key; confirm the fingerprint).
2. **Import** the signed authorization file (`NRB-FEC-IMPORT-1.0`). Import is all-or-nothing and replaces the device list (missing devices are revoked).
3. **Scan** a signed QR code (`NRB-FEC-QR-1.0`). The app verifies the signature, expiry, device/user in the local database and grants only the *intersection* of QR and database permissions. Every attempt is written to the scan history.

No network permission, no cloud. Without a trusted key (or with an invalid signature) everything is denied; an explicit demo switch in Settings allows unsigned data for testing.

## Build
Open in Android Studio (Hedgehog or newer, JDK 17) or run `./gradlew assembleDebug`. Unit tests (security core, authorization rules): `./gradlew testDebugUnitTest`.

## Signing (PC side)
See `docs/QR_FORMAT.md` section 5 and `docs/IMPORT_EXPORT_FORMAT.md`. Reference implementation and samples:
```
python tools/nrb_sign.py genkey private.pem public.pem
python tools/nrb_sign.py sign-qr     private.pem qr.json     > qr_signed.json
python tools/nrb_sign.py sign-import private.pem import.json > import_signed.json
```
Install `public.pem` on the phone. Keep `private.pem` secret. (`docs/examples/` holds sample files signed with a throw-away key.)

## Project layout
`security/` canonical JSON, signature verification, key store - `models/` strict payload parsing - `service/` authorization rules, import, duplicate-scan guard - `database/` Room - `screens/` UI.

## Status
Security core and rules are unit-tested on the JVM. The Android UI (camera scanning, screens) has not been run on a device by the author of this revision: test on hardware before relying on it.
