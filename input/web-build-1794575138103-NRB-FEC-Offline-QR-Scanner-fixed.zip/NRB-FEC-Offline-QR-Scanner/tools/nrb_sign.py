#!/usr/bin/env python3
"""Reference signer for the NRB FEC Offline QR Scanner (use the same logic in the PC QR Generator).

  python nrb_sign.py genkey  private.pem public.pem
  python nrb_sign.py sign-qr     private.pem qr_unsigned.json     > qr_signed.json
  python nrb_sign.py sign-import private.pem import_unsigned.json > import_signed.json

Signed bytes = canonical JSON of the object WITHOUT its "signature" and "sha256" fields:
sorted keys, no whitespace, UTF-8, integers only. Signature = ECDSA P-256 / SHA-256, DER, Base64.
Install public.pem on the phone via Settings > Install trusted key.
"""
import base64, hashlib, json, sys
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

EXCLUDED = ("signature", "sha256")


def canonical(obj):
    body = {k: v for k, v in obj.items() if k not in EXCLUDED}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def load_private(path):
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def sign(obj, key, with_checksum):
    out = {k: v for k, v in obj.items() if k not in EXCLUDED}
    if with_checksum:
        out["algorithm"] = "ECDSA-P256"      # part of the signed data, so it cannot be swapped
    data = canonical(out)
    if with_checksum:
        out["sha256"] = hashlib.sha256(data).hexdigest()
    out["signature"] = base64.b64encode(key.sign(data, ec.ECDSA(hashes.SHA256()))).decode()
    return out


def main(argv):
    if len(argv) >= 4 and argv[1] == "genkey":
        key = ec.generate_private_key(ec.SECP256R1())
        with open(argv[2], "wb") as f:
            f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                      serialization.NoEncryption()))
        with open(argv[3], "wb") as f:
            f.write(key.public_key().public_bytes(serialization.Encoding.PEM,
                                                  serialization.PublicFormat.SubjectPublicKeyInfo))
        return 0
    if len(argv) == 4 and argv[1] in ("sign-qr", "sign-import"):
        with open(argv[3], encoding="utf-8") as f:
            obj = json.load(f)
        print(json.dumps(sign(obj, load_private(argv[2]), argv[1] == "sign-import"), indent=2, ensure_ascii=False))
        return 0
    print(__doc__)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
