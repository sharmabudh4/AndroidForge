package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.service.DeviceRegistration
import com.nrb.offlineqrscanner.service.DeviceRepo
import com.nrb.offlineqrscanner.service.KeyStoreLike
import com.nrb.offlineqrscanner.service.ScanAuditRepo
import com.nrb.offlineqrscanner.service.SettingsLike
import com.nrb.offlineqrscanner.service.UserAccount
import com.nrb.offlineqrscanner.service.UserRepo
import java.security.PublicKey

/** In-memory fakes of the pure repo/keystore/settings interfaces, used to exercise the real
 * production UserService / DeviceService / AuthorizationManager classes on the JVM. */

class FakeUserRepo : UserRepo {
    private val byId = LinkedHashMap<String, UserAccount>() // preserves insertion order like a fresh table
    override suspend fun insert(user: UserAccount) {
        require(!byId.keys.any { it.equals(user.userId, true) }) { "duplicate" }
        byId[user.userId] = user
    }
    override suspend fun update(user: UserAccount) { byId[findKey(user.userId) ?: user.userId] = user }
    override suspend fun getById(userId: String): UserAccount? = findKey(userId)?.let { byId[it] }
    override suspend fun getAll(): List<UserAccount> = byId.values.sortedBy { it.userId.lowercase() }
    override suspend fun count(): Int = byId.size
    private fun findKey(userId: String) = byId.keys.firstOrNull { it.equals(userId, true) }
}

class FakeDeviceRepo : DeviceRepo {
    private val byId = HashMap<String, DeviceRegistration>()
    override suspend fun insert(device: DeviceRegistration) {
        require(!byId.keys.any { it.equals(device.id, true) }) { "duplicate" }
        byId[device.id] = device
    }
    override suspend fun update(device: DeviceRegistration) { byId[findKey(device.id) ?: device.id] = device }
    override suspend fun getById(id: String): DeviceRegistration? = findKey(id)?.let { byId[it] }
    private fun findKey(id: String) = byId.keys.firstOrNull { it.equals(id, true) }
}

class FakeScanAuditRepo : ScanAuditRepo {
    data class Entry(val deviceId: String, val deviceName: String, val userId: String, val resultCode: Int, val reason: String)
    val entries = mutableListOf<Entry>()
    override suspend fun record(deviceId: String, deviceName: String, userId: String, resultCode: Int, reason: String) {
        entries += Entry(deviceId, deviceName, userId, resultCode, reason)
    }
}

class FakeKeyStore(private var key: PublicKey?) : KeyStoreLike {
    override fun load(): PublicKey? = key
    fun set(k: PublicKey?) { key = k }
}

class FakeSettings(override var allowUnsigned: Boolean = false) : SettingsLike
