package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.service.CreateUserResult
import com.nrb.offlineqrscanner.service.FirstAdminResult
import com.nrb.offlineqrscanner.service.LoginResult
import com.nrb.offlineqrscanner.service.ResetPasswordResult
import com.nrb.offlineqrscanner.service.SetActiveResult
import com.nrb.offlineqrscanner.service.UserService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Exercises the real UserService against an in-memory fake repo - task 1, 3, 9. */
class UserServiceTest {
    private fun service() = UserService(FakeUserRepo())

    @Test fun noDefaultAdminAndFirstRunCreatesExactlyOneAdmin() = runBlocking {
        val svc = service()
        assertTrue(!svc.hasAnyUsers()) // nothing seeded - no hardcoded default credential
        val result = svc.createFirstAdmin("admin", "a-strong-pass".toCharArray())
        assertEquals(FirstAdminResult.Success, result)
        assertTrue(svc.hasAnyUsers())
        val login = svc.login("admin", "a-strong-pass".toCharArray())
        assertEquals(LoginResult.Success(isAdmin = true, mustChangePassword = false), login)
    }

    @Test fun firstRunSetupClosesAfterFirstAccountExists() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "a-strong-pass".toCharArray())
        val second = svc.createFirstAdmin("someoneElse", "another-pass".toCharArray())
        assertEquals(FirstAdminResult.AlreadySetUp, second)
    }

    @Test fun successfulAndUnsuccessfulLogin() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "correct-password".toCharArray())
        assertEquals(LoginResult.Success(true, false), svc.login("admin", "correct-password".toCharArray()))
        assertEquals(LoginResult.InvalidCredentials, svc.login("admin", "wrong-password".toCharArray()))
        assertEquals(LoginResult.InvalidCredentials, svc.login("nosuchuser", "whatever".toCharArray()))
    }

    @Test fun deactivatedAccountCannotLogIn() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        svc.createUser("bob", "bobpass1".toCharArray(), isAdmin = false)
        svc.setActive("admin", "bob", active = false)
        assertEquals(LoginResult.AccountDeactivated, svc.login("bob", "bobpass1".toCharArray()))
    }

    @Test fun adminCreatesUserForcedToChangePassword() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        assertEquals(CreateUserResult.Success, svc.createUser("bob", "bobpass1".toCharArray(), isAdmin = false))
        assertEquals(CreateUserResult.DuplicateUserId, svc.createUser("bob", "other-pass".toCharArray(), isAdmin = false))
        val login = svc.login("bob", "bobpass1".toCharArray()) as LoginResult.Success
        assertTrue(login.mustChangePassword)
    }

    @Test fun changePasswordClearsMustChangeFlag() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        svc.createUser("bob", "bobpass1".toCharArray(), isAdmin = false)
        svc.changePassword("bob", "new-password-1".toCharArray())
        val login = svc.login("bob", "new-password-1".toCharArray()) as LoginResult.Success
        assertTrue(!login.mustChangePassword)
        assertEquals(LoginResult.InvalidCredentials, svc.login("bob", "bobpass1".toCharArray()))
    }

    @Test fun adminResetsAnotherUsersPassword() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        svc.createUser("bob", "bobpass1".toCharArray(), isAdmin = false)
        assertEquals(ResetPasswordResult.Success, svc.resetPassword("bob", "temp-password-1".toCharArray()))
        val login = svc.login("bob", "temp-password-1".toCharArray()) as LoginResult.Success
        assertTrue(login.mustChangePassword)
    }

    @Test fun cannotDeactivateSelfOrLastActiveAdmin() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        assertEquals(SetActiveResult.CannotDeactivateSelf, svc.setActive("admin", "admin", active = false))

        svc.createUser("bob", "bobpass1".toCharArray(), isAdmin = false)
        // "admin" is the only admin account that exists - deactivating it must be refused
        // regardless of who is asking, or every admin screen would become unreachable.
        assertEquals(SetActiveResult.CannotDeactivateLastActiveAdmin, svc.setActive("bob", "admin", active = false))

        svc.createUser("carol", "carolpass1".toCharArray(), isAdmin = true) // second admin
        // now that carol is also an active admin, deactivating "admin" is safe and must succeed
        assertEquals(SetActiveResult.Success, svc.setActive("bob", "admin", active = false))
    }

    @Test fun userIdAndPasswordValidation() = runBlocking {
        val svc = service()
        svc.createFirstAdmin("admin", "adminpass1".toCharArray())
        assertTrue(svc.createUser("a", "longenough1".toCharArray(), false) is CreateUserResult.InvalidInput) // too short id
        assertTrue(svc.createUser("validid", "short".toCharArray(), false) is CreateUserResult.InvalidInput) // too short password
    }
}
