package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.service.Session
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Task 2: logout must clear only the in-memory session, nothing else - and Session itself
 * holds nothing but that. */
class SessionTest {
    @Test fun startThenClearResetsExactlyTheSessionFields() {
        val session = Session()
        assertFalse(session.isLoggedIn)
        assertNull(session.userId)

        session.start("alice", isAdmin = true)
        assertTrue(session.isLoggedIn)
        assertEquals("alice", session.userId)
        assertTrue(session.isAdmin)

        session.clear()
        assertFalse(session.isLoggedIn)
        assertNull(session.userId)
        assertFalse(session.isAdmin) // admin flag does not leak into the next (logged-out) state
    }

    @Test fun sessionHoldsNoPersistableState() {
        // Session.kt deliberately has no SharedPreferences/file/DB writes - this is a structural
        // check that it exposes only userId/isAdmin, so "logout" (clear()) cannot possibly
        // touch accounts, devices or scan history, which live in completely separate classes.
        val fields = Session::class.java.declaredFields.map { it.name }.toSet()
        assertEquals(setOf("userId", "isAdmin"), fields)
    }
}
