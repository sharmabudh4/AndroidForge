package com.nrb.offlineqrscanner

import com.google.gson.JsonObject
import com.nrb.offlineqrscanner.models.PayloadException
import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.security.CanonicalJson
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.security.Verification
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

/** Uses vectors produced by tools/nrb_sign.py so the Kotlin and Python implementations stay in sync. */
class SecurityCoreTest {
    private val b64: (String) -> ByteArray = { Base64.getMimeDecoder().decode(it) }
    private val key by lazy { PemUtils.parsePublicKey(resource("public.pem"), b64) }
    private val auth = PayloadAuthenticator(SignatureVerifier(b64))

    private fun resource(name: String) =
        javaClass.classLoader!!.getResource(name)!!.readText()

    private fun obj(name: String): JsonObject = PayloadParser.parseObject(resource(name))

    @Test fun canonicalJsonSortsKeysAndEscapes() {
        val o = PayloadParser.parseObject("""{"b":1,"a":{"z":[true,null,"x\"y\n"],"y":"é"},"signature":"s"}""")
        assertEquals("""{"a":{"y":"é","z":[true,null,"x\"y\n"]},"b":1}""".replace("\n", "\\n"),
            CanonicalJson.serialize(o, setOf("signature")))
    }

    @Test fun pythonSignedQrVerifies() {
        assertEquals(Verification.Verified, auth.authenticate(obj("qr_signed.json"), key, false))
    }

    @Test fun tamperedQrIsRejected() {
        val o = obj("qr_signed.json")
        o.addProperty("authorized_user", "mallory")
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
        // demo mode must NOT bypass a signature that is present but wrong
        assertTrue(auth.authenticate(o, key, true) is Verification.Rejected)
    }

    @Test fun unsignedRejectedUnlessDemoMode() {
        val o = obj("qr_signed.json").also { it.remove("signature") }
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
        assertEquals(Verification.UnsignedAccepted, auth.authenticate(o, key, true))
    }

    @Test fun noTrustedKeyRejectsSignedPayload() {
        assertTrue(auth.authenticate(obj("qr_signed.json"), null, false) is Verification.Rejected)
    }

    @Test fun anyFieldChangeInvalidatesSignature_wholeObjectIsCovered() {
        // The authenticator signs canonical JSON of the WHOLE object (minus only "signature"),
        // not a hardcoded subset of fields - so even an unexpected extra field the format
        // doesn't define still invalidates the signature. This is how "the PC-signed payload
        // matches the Android format exactly" is enforced: there is no field the verifier could
        // forget to check.
        val o = obj("qr_signed.json").also { it.addProperty("unexpected_extra_field", "anything") }
        assertTrue(auth.authenticate(o, key, false) is Verification.Rejected)
    }

    @Test fun deniesScanningBeforeATrustedKeyIsInstalled() {
        val result = auth.authenticate(obj("qr_signed.json"), null, false)
        assertTrue(result is Verification.Rejected)
        assertTrue((result as Verification.Rejected).reason.contains("trusted public key", ignoreCase = true))
    }

    @Test fun claimedAuthorizedUserIsOptionalAndNotUsedForVerification() {
        // confirms the QR's "authorized_user" claim can be absent or anything - it plays no role
        // in signature verification (the authorization decision itself is tested in RulesTest).
        val payload = PayloadParser.parseQr(PayloadParser.parseObject(
            """{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001","device_name":"x"}"""
        ))
        assertEquals(null, payload.claimedAuthorizedUser)
    }

    @Test fun parserRejectsBadInput() {
        fun bad(json: String) {
            try { PayloadParser.parseQr(PayloadParser.parseObject(json)); fail("accepted: $json") }
            catch (e: PayloadException) { /* expected */ }
        }
        bad("{}")
        bad("[1]")
        bad("""{"format":"WRONG-FORMAT","version":1,"device_id":"NRB-DEV-001","device_name":"x"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":2,"device_id":"NRB-DEV-001","device_name":"x"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"","device_name":"x"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001"}""")
        bad("""{"format":"NRB-FEC-QR-1.0","version":1,"device_id":"NRB-DEV-001","device_name":"x","expires_at":1.5}""")
    }

    @Test fun deviceIdValidationAcceptsAdminChosenIdsAndRejectsBadOnes() {
        assertTrue(PayloadParser.isValidDeviceId("NRB-MACHINE-001"))
        assertTrue(PayloadParser.isValidDeviceId("pos7"))
        assertTrue(PayloadParser.isValidDeviceId(""+"A".repeat(40)))
        assertFalse(PayloadParser.isValidDeviceId(""))
        assertFalse(PayloadParser.isValidDeviceId("-leading-hyphen"))
        assertFalse(PayloadParser.isValidDeviceId("has space"))
        assertFalse(PayloadParser.isValidDeviceId("A".repeat(41)))
    }
}
