package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.models.QrPayload
import com.nrb.offlineqrscanner.security.PasswordHasher
import com.nrb.offlineqrscanner.service.AuthorizationEngine
import com.nrb.offlineqrscanner.service.Decision
import com.nrb.offlineqrscanner.service.DeviceRecord
import com.nrb.offlineqrscanner.service.DuplicateScanManager
import com.nrb.offlineqrscanner.service.ScanResultCode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RulesTest {
    private val now = 1_800_000_000L
    private fun qr(issued: Long = now - 10, expires: Long = 0) =
        QrPayload("NRB-DEV-001", "POS", "alice", issued, expires)
    private fun dev(authorizedUserId: String = "alice", active: Boolean = true) =
        DeviceRecord("NRB-DEV-001", "POS", authorizedUserId, active)

    @Test fun grantsWhenLoggedInUserMatchesDeviceRecord() {
        val d = AuthorizationEngine.decide(qr(), dev(), "alice", now) as Decision.Grant
        assertEquals("POS", d.deviceName)
    }

    @Test fun matchIsCaseInsensitive() {
        assertTrue(AuthorizationEngine.decide(qr(), dev("Alice"), "ALICE", now) is Decision.Grant)
    }

    @Test fun ignoresQrsClaimedAuthorizedUser_onlyLocalRecordCounts() {
        // the QR's claimed authorized user is "alice" (see qr()), but the local record says "bob" -
        // the logged-in user is bob, so access must be GRANTED, not denied, proving the claim is ignored.
        val d = AuthorizationEngine.decide(qr(), dev(authorizedUserId = "bob"), "bob", now)
        assertTrue(d is Decision.Grant)
    }

    @Test fun deniesUnknownInactiveMismatchedExpiredFuture() {
        assertEquals(ScanResultCode.UNKNOWN, (AuthorizationEngine.decide(qr(), null, "alice", now) as Decision.Deny).resultCode)
        assertTrue(AuthorizationEngine.decide(qr(), dev(active = false), "alice", now) is Decision.Deny)
        assertTrue(AuthorizationEngine.decide(qr(), dev(), "mallory", now) is Decision.Deny)
        assertEquals(ScanResultCode.EXPIRED, (AuthorizationEngine.decide(qr(expires = now - 1), dev(), "alice", now) as Decision.Deny).resultCode)
        assertTrue(AuthorizationEngine.decide(qr(issued = now + 10_000), dev(), "alice", now) is Decision.Deny)
    }

    @Test fun duplicateCooldown() {
        var t = 0L
        val m = DuplicateScanManager(3000) { t }
        assertFalse(m.isDuplicate("a"))
        t = 1000; assertTrue(m.isDuplicate("a")); assertFalse(m.isDuplicate("b"))
        t = 3500; assertFalse(m.isDuplicate("a"))
    }

    @Test fun passwordHashingRoundTripsAndRejectsWrongPassword() {
        val stored = PasswordHasher.hash("correct horse battery staple".toCharArray())
        assertTrue(PasswordHasher.verify("correct horse battery staple".toCharArray(), stored))
        assertFalse(PasswordHasher.verify("wrong password".toCharArray(), stored))
    }

    @Test fun eachHashUsesAFreshRandomSalt() {
        val a = PasswordHasher.hash("same password".toCharArray())
        val b = PasswordHasher.hash("same password".toCharArray())
        assertTrue(a != b) // salts differ even for an identical password
        assertTrue(PasswordHasher.verify("same password".toCharArray(), a))
        assertTrue(PasswordHasher.verify("same password".toCharArray(), b))
    }

    @Test fun rejectsMalformedStoredCredential() {
        assertFalse(PasswordHasher.verify("x".toCharArray(), "not-a-valid-format"))
    }
}
