package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.security.SignatureVerifier
import com.nrb.offlineqrscanner.service.AuthorizationManager
import com.nrb.offlineqrscanner.service.DeviceRegistration
import com.nrb.offlineqrscanner.service.ScanOutcome
import com.nrb.offlineqrscanner.service.ScanResultCode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

/**
 * Exercises the real, production AuthorizationManager.authorize() end-to-end against in-memory
 * fakes - not a reimplementation of its logic. Covers tasks 6 (signature checked before User
 * ID), 10 (matching/mismatching User IDs) and 11 (tampered QR / invalid signature).
 */
class AuthorizationManagerTest {
    private val b64: (String) -> ByteArray = { Base64.getMimeDecoder().decode(it) }
    private val resource = { name: String -> javaClass.classLoader!!.getResource(name)!!.readText() }
    private val publicKey by lazy { PemUtils.parsePublicKey(resource("public.pem"), b64) }
    private val signedQrRaw by lazy { resource("qr_signed.json") } // device_id NRB-DEV-001, see test/resources
    private val expiredSignedQrRaw by lazy { resource("qr_expired_signed.json") } // same device, expires_at=60 (epoch seconds) - always in the past

    private fun manager(key: java.security.PublicKey?, allowUnsigned: Boolean = false): Triple<AuthorizationManager, FakeDeviceRepo, FakeScanAuditRepo> {
        val devices = FakeDeviceRepo()
        val audit = FakeScanAuditRepo()
        val mgr = AuthorizationManager(devices, audit, FakeKeyStore(key), FakeSettings(allowUnsigned), PayloadAuthenticator(SignatureVerifier(b64)))
        return Triple(mgr, devices, audit)
    }

    private suspend fun registerDevice(devices: FakeDeviceRepo, authorizedUserId: String, active: Boolean = true) {
        devices.insert(DeviceRegistration("NRB-DEV-001", "POS", authorizedUserId, null, null, emptyList(), "admin", 0, null, active))
    }

    @Test fun grantsWhenSignatureValidAndUserMatches() = runBlocking {
        val (mgr, devices, audit) = manager(publicKey)
        registerDevice(devices, "alice")
        val outcome = mgr.authorize(signedQrRaw, "alice")
        assertTrue(outcome is ScanOutcome.Granted)
        assertEquals(ScanResultCode.SUCCESS, audit.entries.last().resultCode)
    }

    @Test fun deniesOnMismatchedUserEvenThoughSignatureIsValid() = runBlocking {
        val (mgr, devices, _) = manager(publicKey)
        registerDevice(devices, "bob") // device belongs to bob, but mallory is logged in
        val outcome = mgr.authorize(signedQrRaw, "mallory") as ScanOutcome.Denied
        assertEquals("User ID does not match the authorized User ID", outcome.reason)
    }

    @Test fun grantsRegardlessOfWhatTheQrsOwnClaimedUserIs() = runBlocking {
        // the fixture QR's own "authorized_user" field says "alice" (see qr_unsigned.json),
        // but the LOCAL device record says "bob" is authorized - logging in as bob must grant,
        // proving the QR's claim is never consulted (task: ignore QR-claimed user).
        val (mgr, devices, _) = manager(publicKey)
        registerDevice(devices, "bob")
        val outcome = mgr.authorize(signedQrRaw, "bob")
        assertTrue(outcome is ScanOutcome.Granted)
    }

    @Test fun deniesTamperedQr_signatureCheckedBeforeUserIdEvenWhenUserWouldOtherwiseMatch() = runBlocking {
        val (mgr, devices, _) = manager(publicKey)
        registerDevice(devices, "alice") // user WOULD match if we got that far
        val tampered = signedQrRaw.replace("\"device_name\": \"Point-of-Sale Terminal \\\"A\\\" \u00e9\"", "\"device_name\": \"Tampered\"")
        assertTrue("fixture replace did not match - test is broken", tampered != signedQrRaw)
        val outcome = mgr.authorize(tampered, "alice") as ScanOutcome.Denied
        // the denial reason must be about the SIGNATURE, not about the user, proving signature
        // verification runs (and fails) before the engine ever compares User IDs
        assertTrue("expected a signature-related denial, got: ${outcome.reason}", outcome.reason.contains("signature", ignoreCase = true))
    }

    @Test fun deniesWhenNoTrustedKeyInstalled() = runBlocking {
        val (mgr, devices, _) = manager(key = null)
        registerDevice(devices, "alice")
        val outcome = mgr.authorize(signedQrRaw, "alice") as ScanOutcome.Denied
        assertTrue(outcome.reason.contains("key", ignoreCase = true) || outcome.reason.contains("signature", ignoreCase = true))
    }

    @Test fun demoModeNeverOverridesAPresentButWrongSignature() = runBlocking {
        val (mgr, devices, _) = manager(publicKey, allowUnsigned = true)
        registerDevice(devices, "alice")
        val tampered = signedQrRaw.replace("\"device_name\": \"Point-of-Sale Terminal \\\"A\\\" \u00e9\"", "\"device_name\": \"Tampered\"")
        val outcome = mgr.authorize(tampered, "alice")
        assertTrue(outcome is ScanOutcome.Denied) // demo mode only waives a MISSING signature, never a wrong one
    }

    @Test fun deactivatedDeviceIsDenied() = runBlocking {
        val (mgr, devices, _) = manager(publicKey)
        registerDevice(devices, "alice", active = false)
        val outcome = mgr.authorize(signedQrRaw, "alice") as ScanOutcome.Denied
        assertEquals("This device has been deactivated", outcome.reason)
    }

    @Test fun unknownDeviceGetsAClearMessage() = runBlocking {
        val (mgr, _, _) = manager(publicKey) // no device registered at all
        val outcome = mgr.authorize(signedQrRaw, "alice") as ScanOutcome.Denied
        assertEquals("Device is not registered on this phone", outcome.reason)
    }

    @Test fun expiredQrGetsAClearMessage() = runBlocking {
        val (mgr, devices, audit) = manager(publicKey)
        registerDevice(devices, "alice")
        val outcome = mgr.authorize(expiredSignedQrRaw, "alice") as ScanOutcome.Denied
        assertEquals("QR code has expired", outcome.reason)
        assertEquals(ScanResultCode.EXPIRED, audit.entries.last().resultCode)
    }

    @Test fun mismatchedUserGetsAClearMessage() = runBlocking {
        val (mgr, devices, audit) = manager(publicKey)
        registerDevice(devices, "bob")
        val outcome = mgr.authorize(signedQrRaw, "mallory") as ScanOutcome.Denied
        assertEquals("User ID does not match the authorized User ID", outcome.reason)
        assertEquals(ScanResultCode.FAILURE, audit.entries.last().resultCode)
    }

    @Test fun missingSignatureGetsAClearMessage() = runBlocking {
        val (mgr, devices, _) = manager(publicKey, allowUnsigned = false)
        registerDevice(devices, "alice")
        val unsigned = signedQrRaw.replace(Regex(",\\s*\"signature\":[^}]*"), "")
        val outcome = mgr.authorize(unsigned, "alice") as ScanOutcome.Denied
        assertEquals("This QR code has no digital signature", outcome.reason)
    }

    @Test fun invalidSignatureGetsAClearMessage() = runBlocking {
        val (mgr, devices, _) = manager(publicKey)
        registerDevice(devices, "alice")
        val tampered = signedQrRaw.replace("\"device_name\": \"Point-of-Sale Terminal \\\"A\\\" \u00e9\"", "\"device_name\": \"Tampered\"")
        val outcome = mgr.authorize(tampered, "alice") as ScanOutcome.Denied
        assertEquals("Invalid signature - this QR code was altered or did not come from a trusted source", outcome.reason)
    }
}
