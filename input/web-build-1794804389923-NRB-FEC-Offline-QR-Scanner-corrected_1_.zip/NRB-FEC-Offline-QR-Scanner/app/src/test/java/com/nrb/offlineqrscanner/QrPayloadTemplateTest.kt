package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.models.QrPayloadTemplate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Task 5: Android's device-registration export and the PC signer (tools/nrb_sign.py) must
 * produce/consume exactly the same field set. This asserts the template Android exports has
 * exactly the fields docs/QR_FORMAT.md defines, and that it parses back cleanly (everything but
 * the signature, which this template deliberately omits - see its KDoc).
 */
class QrPayloadTemplateTest {
    @Test fun templateFieldsMatchDocumentedFormatExactly() {
        val obj = QrPayloadTemplate.build("NRB-DEV-001", "POS", "alice")
        assertEquals(QrPayloadTemplate.FIELD_NAMES.toSet(), obj.keySet())
        assertEquals(QrPayloadTemplate.FIELD_NAMES.size, obj.keySet().size) // no accidental extra/missing field
    }

    @Test fun templateHasNoSignatureField_mustBeSignedOnThePcBeforeUse() {
        val obj = QrPayloadTemplate.build("NRB-DEV-001", "POS", "alice")
        assertTrue(!obj.has("signature"))
    }

    @Test fun templateParsesCleanlyAsAQrPayload() {
        val obj = QrPayloadTemplate.build("NRB-MACHINE-001", "Lathe 1", "alice", expiresAt = 1999999999L)
        val parsed = PayloadParser.parseQr(obj) // throws on any mismatch with the documented format
        assertEquals("NRB-MACHINE-001", parsed.deviceId)
        assertEquals("Lathe 1", parsed.deviceName)
        assertEquals("alice", parsed.claimedAuthorizedUser)
        assertEquals(1999999999L, parsed.expiresAt)
    }

    @Test fun compactAndPrettyJsonBothRoundTrip() {
        val obj = QrPayloadTemplate.build("NRB-DEV-002", "Printer", "bob")
        val compact = QrPayloadTemplate.compactJson(obj)
        val pretty = QrPayloadTemplate.prettyJson(obj)
        assertTrue(!compact.contains("\n"))
        assertTrue(pretty.contains("\n"))
        assertEquals(PayloadParser.parseQr(PayloadParser.parseObject(compact)), PayloadParser.parseQr(PayloadParser.parseObject(pretty)))
    }
}
