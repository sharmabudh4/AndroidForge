package com.nrb.offlineqrscanner

import com.nrb.offlineqrscanner.service.AddDeviceResult
import com.nrb.offlineqrscanner.service.DeviceService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Exercises the real DeviceService against an in-memory fake repo - task 4, 7. */
class DeviceServiceTest {
    private fun service() = DeviceService(FakeDeviceRepo())

    @Test fun registersADeviceWithExactlyOneAuthorizedUser() = runBlocking {
        val svc = service()
        val result = svc.addDevice("NRB-MACHINE-001", "Lathe 1", "alice", "192.168.1.5", "SN-1", listOf("manual.pdf"), "admin")
        assertEquals(AddDeviceResult.Success, result)
        val device = svc.getById("NRB-MACHINE-001")!!
        assertEquals("alice", device.authorizedUserId)
    }

    @Test fun rejectsDuplicateDeviceId() = runBlocking {
        val svc = service()
        svc.addDevice("NRB-MACHINE-001", "Lathe 1", "alice", null, null, emptyList(), "admin")
        val dup = svc.addDevice("NRB-MACHINE-001", "Different name", "bob", null, null, emptyList(), "admin")
        assertEquals(AddDeviceResult.DuplicateDeviceId, dup)
    }

    @Test fun rejectsMoreThanOneAuthorizedUserAtInputTime() = runBlocking {
        val svc = service()
        for (bad in listOf("alice,bob", "alice bob", "alice;bob", "  ")) {
            val result = svc.addDevice("NRB-MACHINE-00${bad.hashCode() and 0xff}", "Device", bad, null, null, emptyList(), "admin")
            assertTrue("expected rejection for '$bad' but got $result", result is AddDeviceResult.InvalidInput)
        }
    }

    @Test fun rejectsBadDeviceIdAndBlankName() = runBlocking {
        val svc = service()
        assertTrue(svc.addDevice("", "Device", "alice", null, null, emptyList(), "admin") is AddDeviceResult.InvalidInput)
        assertTrue(svc.addDevice("has space", "Device", "alice", null, null, emptyList(), "admin") is AddDeviceResult.InvalidInput)
        assertTrue(svc.addDevice("NRB-OK-1", "", "alice", null, null, emptyList(), "admin") is AddDeviceResult.InvalidInput)
    }

    @Test fun setActiveDeactivatesAndReactivates() = runBlocking {
        val svc = service()
        svc.addDevice("NRB-MACHINE-001", "Lathe 1", "alice", null, null, emptyList(), "admin")
        svc.setActive("NRB-MACHINE-001", false)
        assertTrue(!svc.getById("NRB-MACHINE-001")!!.isActive)
        svc.setActive("NRB-MACHINE-001", true)
        assertTrue(svc.getById("NRB-MACHINE-001")!!.isActive)
    }
}
