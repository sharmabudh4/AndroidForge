package com.nrb.offlineqrscanner.screens.users

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityManageUsersBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.adduser.AddUserActivity
import com.nrb.offlineqrscanner.service.ResetPasswordResult
import com.nrb.offlineqrscanner.service.SetActiveResult
import com.nrb.offlineqrscanner.service.UserAccount
import com.nrb.offlineqrscanner.utils.requireAdminOrFinish
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

class ManageUsersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityManageUsersBinding
    private val adapter = UserAdapter { user -> showManageDialog(user) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        if (!requireAdminOrFinish()) return
        binding = ActivityManageUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.rvUsers.layoutManager = LinearLayoutManager(this)
        binding.rvUsers.adapter = adapter
        binding.fabAddUser.setOnClickListener { startActivity(Intent(this, AddUserActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        if (!::binding.isInitialized) return // onCreate already redirected/finished
        reload()
    }

    private fun reload() {
        lifecycleScope.launch { adapter.submitList(nrbApp.userService.listUsers()) }
    }

    private fun showManageDialog(user: UserAccount) {
        val toggleLabel = getString(if (user.isActive) R.string.deactivate_user else R.string.reactivate_user)
        val options = arrayOf(getString(R.string.reset_password), toggleLabel)
        AlertDialog.Builder(this)
            .setTitle(user.userId)
            .setItems(options) { _, which ->
                if (which == 0) promptResetPassword(user) else toggleActive(user)
            }
            .show()
    }

    private fun promptResetPassword(user: UserAccount) {
        val input = android.widget.EditText(this).apply { hint = getString(R.string.new_password) }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.reset_password_for_fmt, user.userId))
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                lifecycleScope.launch {
                    when (val result = nrbApp.userService.resetPassword(user.userId, input.text.toString().toCharArray())) {
                        ResetPasswordResult.Success -> { toast(getString(R.string.password_reset_done)); reload() }
                        is ResetPasswordResult.InvalidInput -> toast(result.message)
                        ResetPasswordResult.UserNotFound -> toast(getString(R.string.error_general))
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun toggleActive(user: UserAccount) {
        val actingUserId = requireLoggedInUserOrRedirect() ?: return
        lifecycleScope.launch {
            when (nrbApp.userService.setActive(actingUserId, user.userId, active = !user.isActive)) {
                SetActiveResult.Success -> reload()
                SetActiveResult.CannotDeactivateSelf -> toast(getString(R.string.cannot_deactivate_self))
                SetActiveResult.CannotDeactivateLastActiveAdmin -> toast(getString(R.string.cannot_deactivate_last_admin))
                SetActiveResult.UserNotFound -> toast(getString(R.string.error_general))
            }
        }
    }
}
