package com.nrb.offlineqrscanner.service

import java.security.PublicKey

/**
 * Pure (Room-free, Android-free) data and repository contracts for the business logic in this
 * package. Keeping UserService/DeviceService/AuthorizationManager dependent only on these -
 * rather than directly on Room DAOs or android.content.Context - means the actual production
 * logic (not a reimplementation of it) can run and be asserted against in plain JVM unit tests.
 * The real app wires these to Room via the adapters in database/dao/RoomRepoAdapters.kt.
 */

data class UserAccount(
    val userId: String,
    val credential: String,
    val isAdmin: Boolean,
    val mustChangePassword: Boolean,
    val isActive: Boolean,
    val createdAt: Long
)

data class DeviceRegistration(
    val id: String,
    val name: String,
    val authorizedUserId: String,
    val deviceAddress: String?,
    val deviceSerial: String?,
    val docs: List<String>,
    val addedBy: String,
    val addedAt: Long,
    val lastAccessedAt: Long?,
    val isActive: Boolean
)

interface UserRepo {
    suspend fun insert(user: UserAccount)
    suspend fun update(user: UserAccount)
    suspend fun getById(userId: String): UserAccount?
    suspend fun getAll(): List<UserAccount>
    suspend fun count(): Int
}

interface DeviceRepo {
    suspend fun insert(device: DeviceRegistration)
    suspend fun update(device: DeviceRegistration)
    suspend fun getById(id: String): DeviceRegistration?
}

interface ScanAuditRepo {
    suspend fun record(deviceId: String, deviceName: String, userId: String, resultCode: Int, reason: String)
}

/** Satisfied by security.TrustedKeyStore. */
interface KeyStoreLike {
    fun load(): PublicKey?
}

/** Satisfied by service.AppSettings. */
interface SettingsLike {
    val allowUnsigned: Boolean
}
