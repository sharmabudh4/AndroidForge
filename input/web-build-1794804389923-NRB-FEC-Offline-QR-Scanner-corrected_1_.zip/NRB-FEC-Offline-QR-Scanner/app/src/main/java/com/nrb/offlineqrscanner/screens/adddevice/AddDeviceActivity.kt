package com.nrb.offlineqrscanner.screens.adddevice

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAddDeviceBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.deviceqr.DeviceQrExportActivity
import com.nrb.offlineqrscanner.service.AddDeviceResult
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.requireAdminOrFinish
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

class AddDeviceActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddDeviceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        // Defense in depth: the Devices screen already hides the "Add Device" button from a
        // non-admin, but this screen must refuse on its own too, not rely on that alone.
        if (!requireAdminOrFinish()) return
        binding = ActivityAddDeviceBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSave.setOnClickListener { submit() }
    }

    private fun submit() {
        val admin = requireLoggedInUserOrRedirect() ?: return
        val id = binding.etDeviceId.text.toString()
        val name = binding.etDeviceName.text.toString()
        val authorizedUser = binding.etAuthorizedUserId.text.toString()
        val address = binding.etAddress.text.toString()
        val serial = binding.etSerial.text.toString()
        val docs = binding.etDocs.text.toString().split(",")
        val deviceIdTrimmed = id.trim()

        lifecycleScope.launch {
            when (val result = nrbApp.deviceService.addDevice(id, name, authorizedUser, address, serial, docs, admin)) {
                AddDeviceResult.Success -> {
                    toast(getString(R.string.device_added))
                    AlertDialog.Builder(this@AddDeviceActivity)
                        .setMessage(R.string.view_qr_payload_prompt)
                        .setPositiveButton(R.string.export_qr_payload) { _, _ ->
                            startActivity(Intent(this@AddDeviceActivity, DeviceQrExportActivity::class.java).putExtra(Extras.DEVICE_ID, deviceIdTrimmed))
                            finish()
                        }
                        .setNegativeButton(R.string.cancel) { _, _ -> finish() }
                        .show()
                }
                AddDeviceResult.DuplicateDeviceId -> toast(getString(R.string.device_id_taken))
                is AddDeviceResult.InvalidInput -> toast(result.message)
            }
        }
    }
}
