package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.security.PasswordHasher

sealed class LoginResult {
    data class Success(val isAdmin: Boolean, val mustChangePassword: Boolean) : LoginResult()
    object InvalidCredentials : LoginResult()
    object AccountDeactivated : LoginResult()
}

sealed class CreateUserResult {
    object Success : CreateUserResult()
    object DuplicateUserId : CreateUserResult()
    data class InvalidInput(val message: String) : CreateUserResult()
}

sealed class FirstAdminResult {
    object Success : FirstAdminResult()
    object AlreadySetUp : FirstAdminResult()
    data class InvalidInput(val message: String) : FirstAdminResult()
}

sealed class SetActiveResult {
    object Success : SetActiveResult()
    object UserNotFound : SetActiveResult()
    object CannotDeactivateSelf : SetActiveResult()
    object CannotDeactivateLastActiveAdmin : SetActiveResult()
}

sealed class ResetPasswordResult {
    object Success : ResetPasswordResult()
    object UserNotFound : ResetPasswordResult()
    data class InvalidInput(val message: String) : ResetPasswordResult()
}

/**
 * There is no cloud signup and no hardcoded default credential. The very first account on a
 * phone is created by [createFirstAdmin] (see screens.firstrun.FirstRunSetupActivity, shown
 * instead of Login until a user exists). From then on, only an existing admin can create more
 * accounts ([createUser]), reset a password ([resetPassword]) or deactivate/reactivate an
 * account ([setActive]).
 */
class UserService(private val repo: UserRepo) {
    companion object {
        val USER_ID = Regex("^[A-Za-z0-9][A-Za-z0-9_.-]{2,29}$")
        const val MIN_PASSWORD_LENGTH = 6
    }

    suspend fun hasAnyUsers(): Boolean = repo.count() > 0

    /** Fails with [FirstAdminResult.AlreadySetUp] if any account already exists (closes the setup window). */
    suspend fun createFirstAdmin(userId: String, password: CharArray): FirstAdminResult {
        if (repo.count() > 0) return FirstAdminResult.AlreadySetUp
        val id = userId.trim()
        if (!USER_ID.matches(id)) return FirstAdminResult.InvalidInput("User ID must be 3-30 letters, numbers, '.', '_' or '-'")
        if (password.size < MIN_PASSWORD_LENGTH) return FirstAdminResult.InvalidInput("Password must be at least $MIN_PASSWORD_LENGTH characters")
        // Re-check under the "lock" of a fresh count() read to narrow (not eliminate, without a
        // DB transaction) the window for two concurrent first-run setups to both succeed.
        if (repo.count() > 0) return FirstAdminResult.AlreadySetUp
        repo.insert(UserAccount(id, PasswordHasher.hash(password), isAdmin = true, mustChangePassword = false, isActive = true, createdAt = System.currentTimeMillis()))
        return FirstAdminResult.Success
    }

    suspend fun login(userId: String, password: CharArray): LoginResult {
        val user = repo.getById(userId.trim()) ?: return LoginResult.InvalidCredentials
        if (!PasswordHasher.verify(password, user.credential)) return LoginResult.InvalidCredentials
        if (!user.isActive) return LoginResult.AccountDeactivated
        return LoginResult.Success(user.isAdmin, user.mustChangePassword)
    }

    suspend fun changePassword(userId: String, newPassword: CharArray) {
        val user = repo.getById(userId) ?: return
        repo.update(user.copy(credential = PasswordHasher.hash(newPassword), mustChangePassword = false))
    }

    suspend fun createUser(userId: String, password: CharArray, isAdmin: Boolean): CreateUserResult {
        val id = userId.trim()
        if (!USER_ID.matches(id))
            return CreateUserResult.InvalidInput("User ID must be 3-30 letters, numbers, '.', '_' or '-'")
        if (password.size < MIN_PASSWORD_LENGTH)
            return CreateUserResult.InvalidInput("Password must be at least $MIN_PASSWORD_LENGTH characters")
        if (repo.getById(id) != null) return CreateUserResult.DuplicateUserId
        repo.insert(UserAccount(id, PasswordHasher.hash(password), isAdmin, mustChangePassword = true, isActive = true, createdAt = System.currentTimeMillis()))
        return CreateUserResult.Success
    }

    /** An admin assigns a temporary password; the account must change it at next login. */
    suspend fun resetPassword(targetUserId: String, temporaryPassword: CharArray): ResetPasswordResult {
        val user = repo.getById(targetUserId) ?: return ResetPasswordResult.UserNotFound
        if (temporaryPassword.size < MIN_PASSWORD_LENGTH)
            return ResetPasswordResult.InvalidInput("Password must be at least $MIN_PASSWORD_LENGTH characters")
        repo.update(user.copy(credential = PasswordHasher.hash(temporaryPassword), mustChangePassword = true))
        return ResetPasswordResult.Success
    }

    /**
     * Deactivating yourself, or deactivating the last remaining active admin, is refused so an
     * admin can never lock every admin out of the app.
     */
    suspend fun setActive(actingUserId: String, targetUserId: String, active: Boolean): SetActiveResult {
        val target = repo.getById(targetUserId) ?: return SetActiveResult.UserNotFound
        if (!active) {
            if (target.userId.equals(actingUserId, ignoreCase = true)) return SetActiveResult.CannotDeactivateSelf
            if (target.isAdmin) {
                val remainingActiveAdmins = repo.getAll().count { it.isAdmin && it.isActive && !it.userId.equals(target.userId, ignoreCase = true) }
                if (remainingActiveAdmins == 0) return SetActiveResult.CannotDeactivateLastActiveAdmin
            }
        }
        repo.update(target.copy(isActive = active))
        return SetActiveResult.Success
    }

    suspend fun listUsers(): List<UserAccount> = repo.getAll()
}
