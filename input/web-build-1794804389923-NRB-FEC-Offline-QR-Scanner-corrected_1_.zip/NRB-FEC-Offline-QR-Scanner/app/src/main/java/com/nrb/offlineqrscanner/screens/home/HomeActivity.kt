package com.nrb.offlineqrscanner.screens.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityHomeBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.history.ScanHistoryAdapter
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.screens.settings.SettingsActivity
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.setupBottomNav
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private val recentAdapter = ScanHistoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupBottomNav(binding.bottomNav, R.id.nav_home)

        binding.ivSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnScanQr.setOnClickListener { startActivity(Intent(this, ScanQRActivity::class.java)) }
        binding.rvRecentScans.layoutManager = LinearLayoutManager(this)
        binding.rvRecentScans.adapter = recentAdapter
        binding.rvRecentScans.isNestedScrollingEnabled = false
    }

    override fun onResume() {
        super.onResume()
        if (!::binding.isInitialized) return // onCreate redirected to Login before inflating
        val userId = requireLoggedInUserOrRedirect() ?: return
        binding.tvWelcome.text = getString(R.string.welcome_user_fmt, userId)
        lifecycleScope.launch {
            val deviceCount = nrbApp.database.deviceDao().countActive()
            binding.tvDeviceCount.text = getString(R.string.registered_devices_count_fmt, deviceCount)
            val recent = nrbApp.database.scanHistoryDao().getRecent(5)
            recentAdapter.submitList(recent)
            binding.tvNoRecentScans.visibility = if (recent.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }
}
