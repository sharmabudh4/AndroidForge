package com.nrb.offlineqrscanner.screens.splash

import android.content.Intent
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.databinding.ActivitySplashBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.firstrun.FirstRunSetupActivity
import com.nrb.offlineqrscanner.screens.login.LoginActivity
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ivAppIcon.scaleX = 0.4f
        binding.ivAppIcon.scaleY = 0.4f
        binding.ivAppIcon.alpha = 0f
        binding.tvAppName.alpha = 0f
        binding.tvAppSubtitle.alpha = 0f

        binding.ivAppIcon.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(500).setInterpolator(AccelerateDecelerateInterpolator())
            .withEndAction {
                binding.tvAppName.animate().alpha(1f).setDuration(300).start()
                binding.tvAppSubtitle.animate().alpha(1f).setDuration(300).setStartDelay(100)
                    .withEndAction { proceed() }.start()
            }.start()
    }

    private fun proceed() {
        binding.root.postDelayed({
            lifecycleScope.launch {
                // No account exists yet on this phone -> secure first-run setup, never a
                // hardcoded default credential.
                val target = if (nrbApp.userService.hasAnyUsers()) LoginActivity::class.java else FirstRunSetupActivity::class.java
                startActivity(Intent(this@SplashActivity, target))
                finish()
            }
        }, 500)
    }
}
