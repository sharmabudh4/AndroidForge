package com.nrb.offlineqrscanner.screens.firstrun

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityFirstRunSetupBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.login.LoginActivity
import com.nrb.offlineqrscanner.service.FirstAdminResult
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

/**
 * Shown instead of Login until this phone has zero accounts. There is no hardcoded default
 * credential anywhere in this app: the admin chooses their own User ID and password right here,
 * which is then the one and only account until they create more from Settings > Manage Users.
 */
class FirstRunSetupActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFirstRunSetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFirstRunSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnCreateAdmin.setOnClickListener { submit() }
    }

    private fun submit() {
        val userId = binding.etAdminUserId.text.toString()
        val password = binding.etAdminPassword.text.toString()
        val confirm = binding.etAdminConfirmPassword.text.toString()
        binding.tvError.visibility = android.view.View.GONE

        if (password != confirm) {
            showError(getString(R.string.password_mismatch)); return
        }

        binding.btnCreateAdmin.isEnabled = false
        lifecycleScope.launch {
            when (val result = nrbApp.userService.createFirstAdmin(userId, password.toCharArray())) {
                FirstAdminResult.Success -> {
                    toast(getString(R.string.admin_account_created))
                    startActivity(Intent(this@FirstRunSetupActivity, LoginActivity::class.java))
                    finish()
                }
                FirstAdminResult.AlreadySetUp -> {
                    // another process/session finished setup first - fall through to Login rather than error
                    startActivity(Intent(this@FirstRunSetupActivity, LoginActivity::class.java))
                    finish()
                }
                is FirstAdminResult.InvalidInput -> {
                    binding.btnCreateAdmin.isEnabled = true
                    showError(result.message)
                }
            }
        }
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = android.view.View.VISIBLE
    }
}
