package com.nrb.offlineqrscanner.screens.adduser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAddUserBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.service.CreateUserResult
import com.nrb.offlineqrscanner.utils.requireAdminOrFinish
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

class AddUserActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddUserBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        if (!requireAdminOrFinish()) return
        binding = ActivityAddUserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.btnSave.setOnClickListener { submit() }
    }

    private fun submit() {
        val userId = binding.etUserId.text.toString()
        val password = binding.etPassword.text.toString()
        val isAdmin = binding.switchIsAdmin.isChecked
        lifecycleScope.launch {
            when (val result = nrbApp.userService.createUser(userId, password.toCharArray(), isAdmin)) {
                CreateUserResult.Success -> { toast(getString(R.string.user_added)); finish() }
                CreateUserResult.DuplicateUserId -> toast(getString(R.string.user_id_taken))
                is CreateUserResult.InvalidInput -> toast(result.message)
            }
        }
    }
}
