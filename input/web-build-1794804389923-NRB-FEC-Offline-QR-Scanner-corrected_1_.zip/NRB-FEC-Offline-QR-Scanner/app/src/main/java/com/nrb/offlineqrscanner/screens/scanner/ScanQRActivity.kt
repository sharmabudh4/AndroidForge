package com.nrb.offlineqrscanner.screens.scanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.animation.doOnEnd
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityScanBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.denied.AccessDeniedActivity
import com.nrb.offlineqrscanner.screens.granted.AccessGrantedActivity
import com.nrb.offlineqrscanner.screens.settings.SettingsActivity
import com.nrb.offlineqrscanner.service.ScanOutcome
import com.nrb.offlineqrscanner.utils.CryptoUtils
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.setupBottomNav
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Live camera scanning (CameraX + bundled ML Kit model: works fully offline), plus a gallery fallback. */
class ScanQRActivity : AppCompatActivity() {
    private lateinit var binding: ActivityScanBinding
    private lateinit var analysisExecutor: ExecutorService
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var torchOn = false
    private val busy = AtomicBoolean(false)
    private var lineAnimator: android.animation.ValueAnimator? = null

    private val scanner by lazy {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else binding.tvStatus.setText(R.string.camera_permission_denied)
    }

    private val galleryPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let(::decodeFromGallery)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // If the process was killed and this screen is being restored directly (session lives
        // only in memory - see service/Session.kt), there is no logged-in user: bounce to
        // Login immediately rather than let the rest of this screen set up a camera for no one.
        if (requireLoggedInUserOrRedirect() == null) return

        setupBottomNav(binding.bottomNav, R.id.nav_scanner)
        analysisExecutor = Executors.newSingleThreadExecutor()
        binding.btnBack.setOnClickListener { finish() }
        binding.btnGallery.setOnClickListener { galleryPicker.launch("image/*") }
        binding.btnFlash.setOnClickListener { toggleTorch() }
        binding.btnGoToSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.tvStatus.setText(R.string.scan_hint)
        startScanLineAnimation()

        // A trusted key is verified to be installed BEFORE scanning even starts - not just
        // discovered after wasting a scan - unless demo mode is deliberately on.
        if (nrbApp.keyStore.load() == null && !nrbApp.settings.allowUnsigned) {
            binding.containerNoKey.visibility = android.view.View.VISIBLE
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        // Covers returning from Settings after installing a key (or toggling demo mode)
        // without the activity having been destroyed.
        if (!::analysisExecutor.isInitialized) return
        if (binding.containerNoKey.visibility == android.view.View.VISIBLE &&
            (nrbApp.keyStore.load() != null || nrbApp.settings.allowUnsigned)
        ) {
            binding.containerNoKey.visibility = android.view.View.GONE
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                startCamera()
            } else {
                cameraPermission.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun startScanLineAnimation() {
        val frameHeight = 260 * resources.displayMetrics.density
        lineAnimator = android.animation.ValueAnimator.ofFloat(0f, frameHeight).apply {
            duration = 1800
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.RESTART
            addUpdateListener { binding.scanLine.translationY = it.animatedValue as Float }
            start()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(analysisExecutor, ::analyze) }
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                binding.tvStatus.setText(R.string.camera_error)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleTorch() {
        val cam = camera ?: return
        if (cam.cameraInfo.hasFlashUnit()) {
            torchOn = !torchOn
            cam.cameraControl.enableTorch(torchOn)
        }
    }

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || busy.get()) {
            proxy.close()
            return
        }
        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(input)
            .addOnSuccessListener { codes -> codes.firstNotNullOfOrNull { it.rawValue }?.let(::onQrDecoded) }
            .addOnCompleteListener { proxy.close() }
    }

    private fun decodeFromGallery(uri: Uri) {
        val input = try { InputImage.fromFilePath(this, uri) } catch (e: Exception) { null }
        if (input == null) { toast(getString(R.string.no_qr_found_in_image)); return }
        scanner.process(input)
            .addOnSuccessListener { codes ->
                val value = codes.firstNotNullOfOrNull { it.rawValue }
                if (value == null) toast(getString(R.string.no_qr_found_in_image)) else onQrDecoded(value)
            }
            .addOnFailureListener { toast(getString(R.string.no_qr_found_in_image)) }
    }

    private fun onQrDecoded(raw: String) {
        if (!busy.compareAndSet(false, true)) return
        if (nrbApp.duplicates.isDuplicate(CryptoUtils.sha256Hex(raw))) {
            binding.tvStatus.setText(R.string.duplicate_scan)
            busy.set(false)
            return
        }
        // Re-check the session right before using it: logout can only happen from Settings in
        // this app, but a QR callback can land after the activity has been torn down for other
        // reasons (process death, etc.), so never assume the session is still there.
        val userId = requireLoggedInUserOrRedirect()
        if (userId == null) {
            busy.set(false) // reset scanner state before this screen is replaced by Login
            return
        }
        binding.tvStatus.setText(R.string.verifying)
        lifecycleScope.launch {
            val outcome = try {
                nrbApp.authorization.authorize(raw, userId)
            } catch (e: Exception) {
                ScanOutcome.Denied(null, null, getString(R.string.error_general))
            }
            when (outcome) {
                is ScanOutcome.Granted -> startActivity(Intent(this@ScanQRActivity, AccessGrantedActivity::class.java).apply {
                    putExtra(Extras.DEVICE_ID, outcome.deviceId)
                    putExtra(Extras.DEVICE_NAME, outcome.deviceName)
                })
                is ScanOutcome.Denied -> startActivity(Intent(this@ScanQRActivity, AccessDeniedActivity::class.java).apply {
                    putExtra(Extras.DEVICE_ID, outcome.deviceId)
                    putExtra(Extras.DEVICE_NAME, outcome.deviceName)
                    putExtra(Extras.REASON, outcome.reason)
                })
            }
            finish()
        }
    }

    override fun onDestroy() {
        lineAnimator?.cancel()
        cameraProvider?.unbindAll()
        scanner.close() // `scanner` is `by lazy`, so accessing it here is always safe even if scanning never started
        // `analysisExecutor` is not lazy: onCreate can return early (no session, or no trusted
        // key yet) before it is ever created.
        if (::analysisExecutor.isInitialized) analysisExecutor.shutdown()
        super.onDestroy()
    }
}
