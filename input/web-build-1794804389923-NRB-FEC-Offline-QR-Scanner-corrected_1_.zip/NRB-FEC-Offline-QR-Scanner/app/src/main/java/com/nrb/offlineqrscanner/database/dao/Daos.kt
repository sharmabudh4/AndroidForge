package com.nrb.offlineqrscanner.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity
import com.nrb.offlineqrscanner.database.entities.UserEntity

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: UserEntity)

    @Update
    suspend fun update(user: UserEntity)

    @Query("SELECT * FROM users WHERE userId = :userId COLLATE NOCASE LIMIT 1")
    suspend fun getById(userId: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY userId COLLATE NOCASE ASC")
    suspend fun getAll(): List<UserEntity>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int
}

@Dao
interface DeviceDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(device: DeviceEntity)

    @Update
    suspend fun update(device: DeviceEntity)

    @Query("SELECT * FROM devices WHERE id = :id COLLATE NOCASE LIMIT 1")
    suspend fun getById(id: String): DeviceEntity?

    @Query("SELECT * FROM devices ORDER BY name COLLATE NOCASE ASC")
    suspend fun getAll(): List<DeviceEntity>

    @Query("SELECT COUNT(*) FROM devices WHERE isActive = 1")
    suspend fun countActive(): Int
}

@Dao
interface ScanHistoryDao {
    @Insert
    suspend fun insert(entity: ScanHistoryEntity)

    @Query("SELECT * FROM scan_history ORDER BY scanTime DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<ScanHistoryEntity>

    @Query("SELECT * FROM scan_history WHERE deviceId = :deviceId ORDER BY scanTime DESC LIMIT :limit")
    suspend fun getRecentForDevice(deviceId: String, limit: Int): List<ScanHistoryEntity>

    @Query("SELECT COUNT(*) FROM scan_history")
    suspend fun count(): Int

    @Query("DELETE FROM scan_history")
    suspend fun clearAll()
}
