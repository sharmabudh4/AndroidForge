package com.nrb.offlineqrscanner.models

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser

/** Thrown for any malformed QR payload. The message is safe to show to the user. */
class PayloadException(message: String) : Exception(message)

const val QR_FORMAT = "NRB-FEC-QR-1.0"

/**
 * A scanned QR code's claims. [claimedAuthorizedUser] is carried for display/debugging only -
 * the access decision never trusts it; only the phone's own [database.entities.DeviceEntity]
 * (added on-device by an admin) says who is actually authorized for [deviceId].
 */
data class QrPayload(
    val deviceId: String,
    val deviceName: String,
    val claimedAuthorizedUser: String?,
    val issuedAt: Long,
    val expiresAt: Long
)

/**
 * Strict field-by-field parser (snake_case JSON, see docs/QR_FORMAT.md). Deliberately does NOT
 * use reflection-based Gson mapping, so a missing field can never silently become null.
 */
object PayloadParser {
    private val DEVICE_ID = Regex("^[A-Za-z0-9][A-Za-z0-9_-]{1,39}$")
    const val MAX_QR_CHARS = 8192

    fun parseObject(raw: String): JsonObject {
        val element = try {
            JsonParser.parseString(raw)
        } catch (e: Exception) {
            throw PayloadException("Not valid JSON")
        }
        if (!element.isJsonObject) throw PayloadException("JSON root must be an object")
        return element.asJsonObject
    }

    fun parseQr(obj: JsonObject): QrPayload {
        val format = reqString(obj, "format")
        if (format != QR_FORMAT) throw PayloadException("Unsupported QR format: $format")
        if (reqLong(obj, "version") != 1L) throw PayloadException("Unsupported QR version")
        return QrPayload(
            deviceId = reqDeviceId(obj),
            deviceName = reqString(obj, "device_name"),
            claimedAuthorizedUser = optString(obj, "authorized_user"),
            issuedAt = optLong(obj, "issued_at"),
            expiresAt = optLong(obj, "expires_at")
        )
    }

    /** Validates a device ID typed by an admin in the Add Device screen. */
    fun isValidDeviceId(id: String): Boolean = DEVICE_ID.matches(id)

    // ---- helpers -------------------------------------------------------------------------

    private fun reqDeviceId(o: JsonObject): String {
        val id = reqString(o, "device_id")
        if (!isValidDeviceId(id)) throw PayloadException("Invalid device_id format: $id")
        return id
    }

    private fun prim(o: JsonObject, key: String): JsonElement? {
        val e = o.get(key) ?: return null
        if (e.isJsonNull) return null
        if (!e.isJsonPrimitive) throw PayloadException("Field '$key' has the wrong type")
        return e
    }

    private fun reqString(o: JsonObject, key: String): String {
        val e = prim(o, key) ?: throw PayloadException("Missing field: $key")
        if (!e.asJsonPrimitive.isString) throw PayloadException("Field '$key' must be a string")
        val s = e.asString.trim()
        if (s.isEmpty()) throw PayloadException("Field '$key' is empty")
        return s
    }

    private fun optString(o: JsonObject, key: String): String? {
        val e = prim(o, key) ?: return null
        if (!e.asJsonPrimitive.isString) throw PayloadException("Field '$key' must be a string")
        return e.asString.trim().ifEmpty { null }
    }

    private fun longOf(e: JsonElement, key: String): Long {
        val p = e.asJsonPrimitive
        if (!p.isNumber) throw PayloadException("Field '$key' must be an integer")
        return try {
            p.asBigDecimal.longValueExact()
        } catch (ex: ArithmeticException) {
            throw PayloadException("Field '$key' must be an integer")
        }
    }

    private fun reqLong(o: JsonObject, key: String): Long =
        longOf(prim(o, key) ?: throw PayloadException("Missing field: $key"), key)

    private fun optLong(o: JsonObject, key: String): Long {
        val v = longOf(prim(o, key) ?: return 0L, key)
        if (v < 0) throw PayloadException("Field '$key' must not be negative")
        return v
    }
}
