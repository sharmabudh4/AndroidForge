package com.nrb.offlineqrscanner.screens.granted

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAccessGrantedBinding
import com.nrb.offlineqrscanner.screens.deviceinfo.DeviceInfoActivity
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect

class AccessGrantedActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAccessGrantedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val userId = requireLoggedInUserOrRedirect() ?: return
        binding = ActivityAccessGrantedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val deviceId = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        binding.tvDeviceName.text = intent.getStringExtra(Extras.DEVICE_NAME)
        binding.tvLoggedInUser.text = getString(R.string.logged_in_user_fmt, userId)

        binding.btnContinue.setOnClickListener {
            startActivity(Intent(this, DeviceInfoActivity::class.java).putExtra(Extras.DEVICE_ID, deviceId))
            finish()
        }
    }

    override fun onBackPressed() {
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}
