package com.nrb.offlineqrscanner.screens.devices

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.databinding.ItemDeviceBinding
import com.nrb.offlineqrscanner.utils.formatDateTime

class DeviceAdapter(private val onClick: (DeviceEntity) -> Unit) :
    ListAdapter<DeviceEntity, DeviceAdapter.Holder>(object : DiffUtil.ItemCallback<DeviceEntity>() {
        override fun areItemsTheSame(a: DeviceEntity, b: DeviceEntity) = a.id == b.id
        override fun areContentsTheSame(a: DeviceEntity, b: DeviceEntity) = a == b
    }) {

    class Holder(val binding: ItemDeviceBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val d = getItem(position)
        val ctx = holder.itemView.context
        holder.binding.tvDeviceName.text = d.name
        holder.binding.tvDeviceId.text = "${d.id}  ·  ${d.authorizedUserId}"
        holder.binding.tvDeviceStatus.setText(if (d.isActive) R.string.status_active else R.string.status_revoked)
        holder.binding.tvLastAccessed.text = d.lastAccessedAt?.let { ctx.getString(R.string.last_accessed_fmt, formatDateTime(it)) }
            ?: ctx.getString(R.string.last_accessed_never)
        holder.itemView.setOnClickListener { onClick(d) }
    }
}
