package com.nrb.offlineqrscanner.screens.deviceqr

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityDeviceQrExportBinding
import com.nrb.offlineqrscanner.models.QrPayloadTemplate
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.QrCodeGenerator
import com.nrb.offlineqrscanner.utils.requireAdminOrFinish
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.launch

/**
 * Shows the unsigned QR payload template for a registered device - admin-only, reached from
 * Device Info or right after Add Device. This is a transport convenience, not a working
 * authorization QR: it has no signature, so AuthorizationManager always rejects it (unless an
 * admin has knowingly turned on demo mode). The admin takes this JSON (or scans the QR shown
 * here with a PC webcam) into `tools/nrb_sign.py` on the PC, which signs it with the private
 * key that never leaves the PC - see docs/QR_FORMAT.md and docs/SECURITY.md.
 */
class DeviceQrExportActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDeviceQrExportBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        if (!requireAdminOrFinish()) return
        binding = ActivityDeviceQrExportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val deviceId = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        lifecycleScope.launch {
            val device = nrbApp.deviceService.getById(deviceId)
            if (device == null) { toast(getString(R.string.unknown_device)); finish(); return@launch }

            val payload = QrPayloadTemplate.build(device.id, device.name, device.authorizedUserId)
            val pretty = QrPayloadTemplate.prettyJson(payload)
            val compact = QrPayloadTemplate.compactJson(payload)

            binding.tvJson.text = pretty
            binding.ivQrPreview.setImageBitmap(QrCodeGenerator.generate(compact))
            binding.btnCopyJson.setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("NRB FEC unsigned QR payload", compact))
                toast(getString(R.string.copied_to_clipboard))
            }
        }
    }
}
