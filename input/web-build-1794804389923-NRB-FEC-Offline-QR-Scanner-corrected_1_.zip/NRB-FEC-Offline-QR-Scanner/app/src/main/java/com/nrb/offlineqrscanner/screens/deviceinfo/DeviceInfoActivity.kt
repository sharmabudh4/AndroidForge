package com.nrb.offlineqrscanner.screens.deviceinfo

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.databinding.ActivityDeviceInfoBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.deviceqr.DeviceQrExportActivity
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.formatDateTime
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import kotlinx.coroutines.launch

class DeviceInfoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDeviceInfoBinding
    private lateinit var deviceId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        binding = ActivityDeviceInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        deviceId = intent.getStringExtra(Extras.DEVICE_ID).orEmpty()
        val isAdmin = nrbApp.session.isAdmin
        binding.btnExportQr.visibility = if (isAdmin) View.VISIBLE else View.GONE
        binding.btnExportQr.setOnClickListener {
            startActivity(Intent(this, DeviceQrExportActivity::class.java).putExtra(Extras.DEVICE_ID, deviceId))
        }
        binding.btnToggleActive.visibility = if (isAdmin) View.VISIBLE else View.GONE
        binding.btnToggleActive.setOnClickListener { confirmToggleActive() }

        load()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) load()
    }

    private fun load() {
        lifecycleScope.launch {
            val device = nrbApp.database.deviceDao().getById(deviceId)
            if (device == null) {
                binding.tvDeviceName.setText(R.string.unknown_device)
                binding.btnToggleActive.visibility = View.GONE
                return@launch
            }
            bind(device)
        }
    }

    private fun bind(device: DeviceEntity) {
        binding.tvDeviceName.text = device.name
        binding.tvDeviceId.text = device.id
        binding.tvAuthorizedUser.text = device.authorizedUserId
        binding.tvStatus.setText(if (device.isActive) R.string.status_active else R.string.status_revoked)
        binding.tvCreatedAt.text = formatDateTime(device.addedAt)
        binding.tvAddress.text = device.deviceAddress ?: getString(R.string.not_available)
        binding.tvSerial.text = device.deviceSerial ?: getString(R.string.not_available)
        binding.tvLastAccessed.text = device.lastAccessedAt?.let { formatDateTime(it) } ?: getString(R.string.last_accessed_never)
        if (nrbApp.session.isAdmin) binding.btnToggleActive.setText(if (device.isActive) R.string.deactivate_device else R.string.reactivate_device)

        val docs: List<String> = try {
            Gson().fromJson(device.docsJson, object : TypeToken<List<String>>() {}.type)
        } catch (e: Exception) { emptyList() }
        binding.tvNoDocuments.visibility = if (docs.isEmpty()) View.VISIBLE else View.GONE
        binding.containerDocs.removeAllViews()
        for (doc in docs) {
            val tv = android.widget.TextView(this@DeviceInfoActivity)
            tv.text = "\u2022 $doc"
            tv.setTextColor(getColor(R.color.text_primary))
            tv.setPadding(0, 8, 0, 8)
            binding.containerDocs.addView(tv)
        }
    }

    private fun confirmToggleActive() {
        lifecycleScope.launch {
            val device = nrbApp.database.deviceDao().getById(deviceId) ?: return@launch
            val makeActive = !device.isActive
            AlertDialog.Builder(this@DeviceInfoActivity)
                .setMessage(if (makeActive) R.string.confirm_reactivate_device else R.string.confirm_deactivate_device)
                .setPositiveButton(if (makeActive) R.string.reactivate_device else R.string.deactivate_device) { _, _ ->
                    lifecycleScope.launch {
                        nrbApp.deviceService.setActive(deviceId, makeActive)
                        load()
                    }
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }
}
