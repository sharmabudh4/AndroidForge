package com.nrb.offlineqrscanner.service

import android.content.Context

class AppSettings(context: Context) : SettingsLike {
    private val prefs = context.applicationContext.getSharedPreferences("nrb_settings", Context.MODE_PRIVATE)

    /** Demo mode: accept QR codes that carry no verifiable signature. Off by default. */
    override var allowUnsigned: Boolean
        get() = prefs.getBoolean("allow_unsigned", false)
        set(v) = prefs.edit().putBoolean("allow_unsigned", v).apply()
}
