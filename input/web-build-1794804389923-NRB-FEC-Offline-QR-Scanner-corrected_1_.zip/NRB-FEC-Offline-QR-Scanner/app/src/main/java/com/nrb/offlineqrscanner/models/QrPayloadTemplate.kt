package com.nrb.offlineqrscanner.models

import com.google.gson.GsonBuilder
import com.google.gson.JsonObject

/**
 * Builds the exact unsigned QR JSON structure the PC QR Generator must sign for a device
 * registered on this phone (see docs/QR_FORMAT.md). This is the single place that defines the
 * field set Android produces/expects, so Android's device-registration screen and the PC
 * signer can never silently drift apart - QrPayloadTemplateTest asserts this object's keys are
 * exactly the fields PayloadParser.parseQr accepts.
 *
 * The result is UNSIGNED (no "signature" field) and is never itself accepted as an
 * authorization QR - AuthorizationManager always requires a valid signature. It exists purely
 * to be exported to the PC, signed there with `tools/nrb_sign.py` (keeping the private key off
 * the phone, per docs/SECURITY.md), and turned into the final scannable QR code.
 */
object QrPayloadTemplate {
    private val compactGson = com.google.gson.Gson()
    private val prettyGson = GsonBuilder().setPrettyPrinting().create()

    /** The field set an admin provides here; order matches docs/QR_FORMAT.md section 2 exactly. */
    val FIELD_NAMES = listOf("format", "version", "device_id", "device_name", "authorized_user", "issued_at", "expires_at")

    fun build(deviceId: String, deviceName: String, authorizedUserId: String, expiresAt: Long = 0L): JsonObject {
        val obj = JsonObject()
        obj.addProperty("format", QR_FORMAT)
        obj.addProperty("version", 1)
        obj.addProperty("device_id", deviceId)
        obj.addProperty("device_name", deviceName)
        obj.addProperty("authorized_user", authorizedUserId)
        obj.addProperty("issued_at", System.currentTimeMillis() / 1000)
        obj.addProperty("expires_at", expiresAt)
        return obj
    }

    fun compactJson(obj: JsonObject): String = compactGson.toJson(obj)

    fun prettyJson(obj: JsonObject): String = prettyGson.toJson(obj)
}
