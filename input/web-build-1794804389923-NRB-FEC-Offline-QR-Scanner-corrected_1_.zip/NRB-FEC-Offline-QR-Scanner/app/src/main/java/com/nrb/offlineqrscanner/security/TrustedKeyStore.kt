package com.nrb.offlineqrscanner.security

import android.content.Context
import android.util.Base64
import com.nrb.offlineqrscanner.service.KeyStoreLike
import java.io.File
import java.security.PublicKey

val androidBase64: Base64Decoder = { Base64.decode(it, Base64.DEFAULT) }

/**
 * Holds the single trusted public key used to verify QR codes and import files.
 * Installed key (app-private file) takes precedence over an optional bundled
 * `assets/trusted_public_key.pem`.
 */
class TrustedKeyStore(private val context: Context) : KeyStoreLike {
    private val file get() = File(context.filesDir, "trusted_public_key.pem")

    override fun load(): PublicKey? {
        val pem = when {
            file.exists() -> file.readText()
            else -> try {
                context.assets.open("trusted_public_key.pem").use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (e: Exception) {
                return null
            }
        }
        return try { PemUtils.parsePublicKey(pem, androidBase64) } catch (e: Exception) { null }
    }

    /** Validates [pem] (throws IllegalArgumentException if unusable) without installing it. */
    fun parse(pem: String): PublicKey = try {
        PemUtils.parsePublicKey(pem, androidBase64)
    } catch (e: IllegalArgumentException) {
        throw e
    } catch (e: Exception) {
        throw IllegalArgumentException("Not a valid PEM public key")
    }

    fun install(pem: String) {
        parse(pem)
        file.writeText(pem)
    }

    fun fingerprint(): String? = load()?.let { PemUtils.fingerprint(it) }
}
