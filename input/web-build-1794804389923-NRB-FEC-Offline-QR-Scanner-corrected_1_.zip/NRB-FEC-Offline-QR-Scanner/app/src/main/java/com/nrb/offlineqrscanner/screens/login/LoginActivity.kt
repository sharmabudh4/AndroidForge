package com.nrb.offlineqrscanner.screens.login

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.databinding.ActivityLoginBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.changepassword.ChangePasswordActivity
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.service.LoginResult
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val userId = binding.etUserId.text.toString().trim()
        val password = binding.etPassword.text.toString()
        if (userId.isEmpty() || password.isEmpty()) {
            binding.tvError.text = getString(com.nrb.offlineqrscanner.R.string.invalid_credentials)
            binding.tvError.visibility = android.view.View.VISIBLE
            return
        }
        binding.btnLogin.isEnabled = false
        binding.tvError.visibility = android.view.View.GONE

        lifecycleScope.launch {
            when (val result = nrbApp.userService.login(userId, password.toCharArray())) {
                is LoginResult.Success -> {
                    nrbApp.session.start(userId, result.isAdmin)
                    if (result.mustChangePassword) {
                        startActivity(Intent(this@LoginActivity, ChangePasswordActivity::class.java).putExtra("required", true))
                    } else {
                        startActivity(Intent(this@LoginActivity, HomeActivity::class.java))
                    }
                    finish()
                }
                LoginResult.InvalidCredentials -> {
                    binding.btnLogin.isEnabled = true
                    binding.tvError.text = getString(com.nrb.offlineqrscanner.R.string.invalid_credentials)
                    binding.tvError.visibility = android.view.View.VISIBLE
                }
                LoginResult.AccountDeactivated -> {
                    binding.btnLogin.isEnabled = true
                    binding.tvError.text = getString(com.nrb.offlineqrscanner.R.string.account_deactivated)
                    binding.tvError.visibility = android.view.View.VISIBLE
                }
            }
        }
    }
}
