package com.nrb.offlineqrscanner.utils

import android.app.Activity
import android.content.Intent
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.login.LoginActivity

/**
 * Returns the logged-in user's ID, or null after safely redirecting to Login (clearing the back
 * stack) if the session is missing - for example because the app process was killed and the
 * system restored this screen directly, bypassing Home's own login check. Session is in-memory
 * only (see service/Session.kt) so this can legitimately happen to any screen, not just one.
 *
 * Call sites must treat a null result as "this screen is finishing now": stop whatever they were
 * doing (reset any in-progress flag/state) and return, rather than silently doing nothing.
 */
fun Activity.requireLoggedInUserOrRedirect(): String? {
    val userId = nrbApp.session.userId
    if (userId != null) return userId
    startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    finish()
    return null
}

/**
 * Admin-only screens (Add Device, Manage Users, Add User, Device QR Export) must refuse on
 * their own if the current session is not an admin - not rely solely on another screen having
 * hidden the button that leads here. Call after [requireLoggedInUserOrRedirect] has already
 * confirmed someone is logged in. Returns false (and finishes the activity) if refused.
 */
fun Activity.requireAdminOrFinish(): Boolean {
    if (nrbApp.session.isAdmin) return true
    toast(getString(com.nrb.offlineqrscanner.R.string.admin_only_notice))
    finish()
    return false
}
