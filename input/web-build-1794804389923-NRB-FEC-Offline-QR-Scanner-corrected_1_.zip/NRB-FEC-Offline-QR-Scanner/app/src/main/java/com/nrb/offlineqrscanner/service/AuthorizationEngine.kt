package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.models.QrPayload

/** Result codes stored in scan_history.result. */
object ScanResultCode {
    const val SUCCESS = 0
    const val DUPLICATE = 1
    const val FAILURE = 2
    const val EXPIRED = 3
    const val UNKNOWN = 4
}

/** The phone's own record of who may access a device - the only source of truth for that. */
data class DeviceRecord(val id: String, val name: String, val authorizedUserId: String, val isActive: Boolean)

sealed class Decision {
    data class Grant(val deviceName: String) : Decision()
    data class Deny(val reason: String, val resultCode: Int) : Decision()
}

object AuthorizationEngine {
    const val CLOCK_SKEW_SECONDS = 300L

    /**
     * [loggedInUserId] is the only identity used for the decision. The QR's own claimed
     * "authorized_user" field is never consulted here - see models.QrPayload.
     */
    fun decide(qr: QrPayload, device: DeviceRecord?, loggedInUserId: String, nowSeconds: Long): Decision {
        if (qr.expiresAt != 0L && nowSeconds > qr.expiresAt)
            return Decision.Deny("QR code has expired", ScanResultCode.EXPIRED)
        if (qr.issuedAt > nowSeconds + CLOCK_SKEW_SECONDS)
            return Decision.Deny("QR code is dated in the future (check this device's clock)", ScanResultCode.FAILURE)
        if (device == null)
            return Decision.Deny("Device is not registered on this phone", ScanResultCode.UNKNOWN)
        if (!device.isActive)
            return Decision.Deny("This device has been deactivated", ScanResultCode.FAILURE)
        if (!device.authorizedUserId.equals(loggedInUserId, ignoreCase = true))
            return Decision.Deny("User ID does not match the authorized User ID", ScanResultCode.FAILURE)
        return Decision.Grant(device.name)
    }
}
