package com.nrb.offlineqrscanner.screens.denied

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityAccessDeniedBinding
import com.nrb.offlineqrscanner.screens.home.HomeActivity
import com.nrb.offlineqrscanner.screens.scanner.ScanQRActivity
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect

class AccessDeniedActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAccessDeniedBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val userId = requireLoggedInUserOrRedirect() ?: return
        binding = ActivityAccessDeniedBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvDeviceName.text = intent.getStringExtra(Extras.DEVICE_NAME) ?: getString(R.string.unknown_device)
        binding.tvLoggedInUser.text = getString(R.string.logged_in_user_fmt, userId)
        // A clear, specific reason for every denial case (unknown device, invalid/expired
        // signature, expired QR, mismatched User ID, etc.) comes straight from
        // AuthorizationManager/AuthorizationEngine - see their KDoc and
        // AuthorizationManagerTest for the exact wording of each case.
        binding.tvReason.text = intent.getStringExtra(Extras.REASON)?.ifBlank { null } ?: getString(R.string.access_denied_reason)

        binding.btnScanAgain.setOnClickListener {
            startActivity(Intent(this, ScanQRActivity::class.java))
            finish()
        }
        binding.btnHome.setOnClickListener { goHome() }
    }

    override fun onBackPressed() = goHome()

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}
