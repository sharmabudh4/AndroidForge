package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.models.PayloadParser

sealed class AddDeviceResult {
    object Success : AddDeviceResult()
    object DuplicateDeviceId : AddDeviceResult()
    data class InvalidInput(val message: String) : AddDeviceResult()
}

/**
 * Devices are registered on-device by an admin; there is no file-import workflow.
 * [authorizedUserId] is a single User ID, not a list - "Each device must have exactly one
 * authorized User ID" is enforced both by the schema (one string column, see
 * database.entities.DeviceEntity) and here at input time (no whitespace/commas allowed, which
 * would silently smuggle in more than one).
 */
class DeviceService(private val deviceDao: DeviceRepo) {

    suspend fun addDevice(
        id: String, name: String, authorizedUserId: String,
        address: String?, serial: String?, docs: List<String>, addedBy: String
    ): AddDeviceResult {
        val deviceId = id.trim()
        if (!PayloadParser.isValidDeviceId(deviceId))
            return AddDeviceResult.InvalidInput("Device ID must be 2-40 letters, numbers, '_' or '-'")
        if (name.isBlank()) return AddDeviceResult.InvalidInput("Device name is required")
        val authorizedUser = authorizedUserId.trim()
        if (authorizedUser.isBlank()) return AddDeviceResult.InvalidInput("Authorized User ID is required")
        if (authorizedUser.any { it.isWhitespace() || it == ',' || it == ';' })
            return AddDeviceResult.InvalidInput("Exactly one Authorized User ID is allowed - no spaces, commas or semicolons")
        if (deviceDao.getById(deviceId) != null) return AddDeviceResult.DuplicateDeviceId

        deviceDao.insert(
            DeviceRegistration(
                id = deviceId,
                name = name.trim(),
                authorizedUserId = authorizedUser,
                deviceAddress = address?.trim()?.ifEmpty { null },
                deviceSerial = serial?.trim()?.ifEmpty { null },
                docs = docs.map { it.trim() }.filter { it.isNotEmpty() },
                addedBy = addedBy,
                addedAt = System.currentTimeMillis(),
                lastAccessedAt = null,
                isActive = true
            )
        )
        return AddDeviceResult.Success
    }

    suspend fun setActive(id: String, active: Boolean) {
        val device = deviceDao.getById(id) ?: return
        deviceDao.update(device.copy(isActive = active))
    }

    suspend fun getById(id: String): DeviceRegistration? = deviceDao.getById(id)
}
