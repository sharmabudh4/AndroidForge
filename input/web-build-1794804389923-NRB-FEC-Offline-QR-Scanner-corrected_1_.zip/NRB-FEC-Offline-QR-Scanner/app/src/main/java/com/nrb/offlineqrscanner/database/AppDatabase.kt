package com.nrb.offlineqrscanner.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.nrb.offlineqrscanner.database.dao.DeviceDao
import com.nrb.offlineqrscanner.database.dao.ScanHistoryDao
import com.nrb.offlineqrscanner.database.dao.UserDao
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity
import com.nrb.offlineqrscanner.database.entities.UserEntity

/** Local, offline-only database: accounts, devices registered by an admin, and the scan audit trail. */
@Database(
    entities = [UserEntity::class, DeviceEntity::class, ScanHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun deviceDao(): DeviceDao
    abstract fun scanHistoryDao(): ScanHistoryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "nrb_fec_offline_db")
                .build().also { instance = it }
        }
    }
}
