package com.nrb.offlineqrscanner.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local account. [credential] is a self-describing PBKDF2 string (see security.PasswordHasher);
 * the plain password is never stored. [mustChangePassword] forces a change after an admin
 * resets someone's password. [isActive] lets an admin disable an account without deleting its
 * history; a deactivated account cannot log in.
 */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String,
    val credential: String,
    val isAdmin: Boolean,
    val mustChangePassword: Boolean = false,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * A device registered on this phone by an admin. [authorizedUserId] is the single source of
 * truth for who may access it - the value a scanned QR code carries for this is informational
 * only and is never trusted for the access decision.
 */
@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val authorizedUserId: String,
    val deviceAddress: String? = null,
    val deviceSerial: String? = null,
    val docsJson: String = "[]",
    val addedBy: String,
    val addedAt: Long = System.currentTimeMillis(),
    val lastAccessedAt: Long? = null,
    val isActive: Boolean = true
)

/** Audit trail of scan attempts. [result] uses [com.nrb.offlineqrscanner.service.ScanResultCode]. */
@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val deviceId: String,
    val deviceName: String,
    val scannedByUserId: String,
    val scanTime: Long = System.currentTimeMillis(),
    val result: Int,
    val reason: String
)
