package com.nrb.offlineqrscanner.service

/** In-memory only - never persisted, so the app always starts at Login and "logout" is absolute. */
class Session {
    var userId: String? = null
        private set
    var isAdmin: Boolean = false
        private set

    val isLoggedIn: Boolean get() = userId != null

    fun start(userId: String, isAdmin: Boolean) {
        this.userId = userId
        this.isAdmin = isAdmin
    }

    fun clear() {
        userId = null
        isAdmin = false
    }
}
