package com.nrb.offlineqrscanner.database.dao

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.nrb.offlineqrscanner.database.entities.DeviceEntity
import com.nrb.offlineqrscanner.database.entities.ScanHistoryEntity
import com.nrb.offlineqrscanner.database.entities.UserEntity
import com.nrb.offlineqrscanner.service.DeviceRegistration
import com.nrb.offlineqrscanner.service.DeviceRepo
import com.nrb.offlineqrscanner.service.ScanAuditRepo
import com.nrb.offlineqrscanner.service.UserAccount
import com.nrb.offlineqrscanner.service.UserRepo

/**
 * Adapters wiring the Room DAOs to the pure repo interfaces the business logic (UserService,
 * DeviceService, AuthorizationManager) depends on. Kept separate from those classes so the
 * business logic itself never imports Room and can be unit-tested on a plain JVM - see
 * service/Models.kt.
 */

class RoomUserRepo(private val dao: UserDao) : UserRepo {
    override suspend fun insert(user: UserAccount) = dao.insert(user.toEntity())
    override suspend fun update(user: UserAccount) = dao.update(user.toEntity())
    override suspend fun getById(userId: String) = dao.getById(userId)?.toAccount()
    override suspend fun getAll() = dao.getAll().map { it.toAccount() }
    override suspend fun count() = dao.count()

    private fun UserAccount.toEntity() = UserEntity(userId, credential, isAdmin, mustChangePassword, isActive, createdAt)
    private fun UserEntity.toAccount() = UserAccount(userId, credential, isAdmin, mustChangePassword, isActive, createdAt)
}

class RoomDeviceRepo(private val dao: DeviceDao) : DeviceRepo {
    private val gson = Gson()
    private val listType = object : TypeToken<List<String>>() {}.type

    override suspend fun insert(device: DeviceRegistration) = dao.insert(device.toEntity())
    override suspend fun update(device: DeviceRegistration) = dao.update(device.toEntity())
    override suspend fun getById(id: String) = dao.getById(id)?.toRegistration()

    private fun DeviceRegistration.toEntity() = DeviceEntity(
        id = id, name = name, authorizedUserId = authorizedUserId, deviceAddress = deviceAddress,
        deviceSerial = deviceSerial, docsJson = gson.toJson(docs), addedBy = addedBy,
        addedAt = addedAt, lastAccessedAt = lastAccessedAt, isActive = isActive
    )

    private fun DeviceEntity.toRegistration() = DeviceRegistration(
        id = id, name = name, authorizedUserId = authorizedUserId, deviceAddress = deviceAddress,
        deviceSerial = deviceSerial,
        docs = try { gson.fromJson<List<String>>(docsJson, listType) ?: emptyList() } catch (e: Exception) { emptyList() },
        addedBy = addedBy, addedAt = addedAt, lastAccessedAt = lastAccessedAt, isActive = isActive
    )
}

class RoomScanAuditRepo(private val dao: ScanHistoryDao) : ScanAuditRepo {
    override suspend fun record(deviceId: String, deviceName: String, userId: String, resultCode: Int, reason: String) {
        dao.insert(ScanHistoryEntity(deviceId = deviceId, deviceName = deviceName, scannedByUserId = userId, result = resultCode, reason = reason))
    }
}
