package com.nrb.offlineqrscanner.screens.users

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ItemUserBinding
import com.nrb.offlineqrscanner.service.UserAccount

class UserAdapter(private val onClick: (UserAccount) -> Unit) :
    ListAdapter<UserAccount, UserAdapter.Holder>(object : DiffUtil.ItemCallback<UserAccount>() {
        override fun areItemsTheSame(a: UserAccount, b: UserAccount) = a.userId == b.userId
        override fun areContentsTheSame(a: UserAccount, b: UserAccount) = a == b
    }) {
    class Holder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        Holder(ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val u = getItem(position)
        holder.binding.tvUserId.text = u.userId
        val role = holder.itemView.context.getString(if (u.isAdmin) R.string.role_admin else R.string.role_user)
        holder.binding.tvUserRole.text = if (u.isActive) role else holder.itemView.context.getString(R.string.role_deactivated_fmt, role)
        holder.binding.tvMustChange.visibility = if (u.mustChangePassword) android.view.View.VISIBLE else android.view.View.GONE
        holder.itemView.alpha = if (u.isActive) 1f else 0.5f
        holder.itemView.setOnClickListener { onClick(u) }
    }
}
