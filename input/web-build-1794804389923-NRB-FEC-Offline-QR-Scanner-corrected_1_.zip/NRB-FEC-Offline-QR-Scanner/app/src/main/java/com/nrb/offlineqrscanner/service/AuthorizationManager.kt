package com.nrb.offlineqrscanner.service

import com.nrb.offlineqrscanner.models.PayloadException
import com.nrb.offlineqrscanner.models.PayloadParser
import com.nrb.offlineqrscanner.security.PayloadAuthenticator
import com.nrb.offlineqrscanner.security.Verification

sealed class ScanOutcome {
    data class Granted(val deviceId: String, val deviceName: String) : ScanOutcome()
    data class Denied(val deviceId: String?, val deviceName: String?, val reason: String) : ScanOutcome()
}

/**
 * Full scan pipeline, entirely offline: parse -> verify signature -> ONLY THEN look up the
 * device this phone has registered -> compare the logged-in user against that device's
 * authorized user -> audit log. The signature check happens before anything about the device
 * or the user is even read from the database, so a tampered or unsigned QR is rejected before
 * a User ID comparison is ever reached (see the `return deny(...)` right after
 * `authenticator.authenticate` below, and AuthorizationManagerTest for a runtime check of this
 * ordering using fakes). The QR's own claimed authorized-user field is parsed but never used
 * for the decision - only the locally registered device record is.
 */
class AuthorizationManager(
    private val deviceDao: DeviceRepo,
    private val scanHistoryDao: ScanAuditRepo,
    private val keyStore: KeyStoreLike,
    private val settings: SettingsLike,
    private val authenticator: PayloadAuthenticator
) {
    suspend fun authorize(raw: String, loggedInUserId: String): ScanOutcome {
        if (raw.length > PayloadParser.MAX_QR_CHARS) return deny(null, null, loggedInUserId, "QR code is too large", ScanResultCode.FAILURE)

        val obj = try { PayloadParser.parseObject(raw) } catch (e: PayloadException) {
            return deny(null, null, loggedInUserId, "Not an NRB FEC QR code (${e.message})", ScanResultCode.FAILURE)
        }
        val qr = try { PayloadParser.parseQr(obj) } catch (e: PayloadException) {
            return deny(null, null, loggedInUserId, "Invalid QR code: ${e.message}", ScanResultCode.FAILURE)
        }

        // --- Signature verified BEFORE any device/user lookup happens. ---
        val verification = authenticator.authenticate(obj, keyStore.load(), settings.allowUnsigned)
        if (verification is Verification.Rejected)
            return deny(qr.deviceId, qr.deviceName, loggedInUserId, verification.reason, ScanResultCode.FAILURE)

        val entity = deviceDao.getById(qr.deviceId)
        val record = entity?.let { DeviceRecord(it.id, it.name, it.authorizedUserId, it.isActive) }

        return when (val decision = AuthorizationEngine.decide(qr, record, loggedInUserId, System.currentTimeMillis() / 1000)) {
            is Decision.Deny -> deny(qr.deviceId, entity?.name ?: qr.deviceName, loggedInUserId, decision.reason, decision.resultCode)
            is Decision.Grant -> {
                deviceDao.update(entity!!.copy(lastAccessedAt = System.currentTimeMillis()))
                log(qr.deviceId, decision.deviceName, loggedInUserId, ScanResultCode.SUCCESS, "Access granted")
                ScanOutcome.Granted(qr.deviceId, decision.deviceName)
            }
        }
    }

    private suspend fun deny(deviceId: String?, name: String?, userId: String, reason: String, code: Int): ScanOutcome.Denied {
        log(deviceId ?: "UNKNOWN", name ?: "Unknown device", userId, code, reason)
        return ScanOutcome.Denied(deviceId, name, reason)
    }

    // Never stores the raw QR content - only the outcome.
    private suspend fun log(deviceId: String, name: String, userId: String, code: Int, reason: String) {
        scanHistoryDao.record(deviceId, name, userId, code, reason)
    }
}
