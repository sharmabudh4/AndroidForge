package com.nrb.offlineqrscanner.security

import com.google.gson.JsonObject
import java.security.PublicKey

sealed class Verification {
    /** Signature present and valid for the trusted key. */
    object Verified : Verification()

    /** No verifiable signature, accepted only because "allow unsigned" demo mode is on. */
    object UnsignedAccepted : Verification()

    data class Rejected(val reason: String) : Verification()
}

/**
 * Authenticates a QR code against docs/QR_FORMAT.md exactly: the signed bytes are the canonical
 * JSON of the object WITHOUT only its `signature` field - nothing else is special-cased or
 * assumed. This is deliberate: it means the PC signer and this verifier can never silently
 * disagree about which fields matter, because every field that is present (whatever the field
 * is) becomes part of what gets verified. See tools/nrb_sign.py for the matching PC-side
 * implementation and SecurityCoreTest for a test that an unrelated/unexpected extra field still
 * invalidates the signature, proving the whole object is covered.
 */
class PayloadAuthenticator(private val verifier: SignatureVerifier) {

    companion object {
        val EXCLUDED_FIELDS = setOf("signature")
    }

    fun authenticate(obj: JsonObject, key: PublicKey?, allowUnsigned: Boolean): Verification {
        val canonical = CanonicalJson.toBytes(obj, EXCLUDED_FIELDS)

        val sigEl = obj.get("signature")
        val signature = if (sigEl == null || sigEl.isJsonNull) null else {
            if (!sigEl.isJsonPrimitive || !sigEl.asJsonPrimitive.isString) return Verification.Rejected("This QR code's signature field is malformed")
            sigEl.asString.ifBlank { null }
        }

        if (signature == null) {
            return if (allowUnsigned) Verification.UnsignedAccepted
            else Verification.Rejected("This QR code has no digital signature")
        }
        if (key == null) {
            return if (allowUnsigned) Verification.UnsignedAccepted
            else Verification.Rejected("No trusted public key is installed on this phone. Go to Settings and install the trusted key before scanning.")
        }

        return if (verifier.verify(canonical, signature, key)) Verification.Verified
        else Verification.Rejected("Invalid signature - this QR code was altered or did not come from a trusted source")
    }
}
