package com.nrb.offlineqrscanner.screens.devices

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivityRegisteredDevicesBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.adddevice.AddDeviceActivity
import com.nrb.offlineqrscanner.screens.deviceinfo.DeviceInfoActivity
import com.nrb.offlineqrscanner.utils.Extras
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.setupBottomNav
import kotlinx.coroutines.launch

class RegisteredDevicesActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisteredDevicesBinding
    private val adapter = DeviceAdapter { device ->
        startActivity(Intent(this, DeviceInfoActivity::class.java).putExtra(Extras.DEVICE_ID, device.id))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        binding = ActivityRegisteredDevicesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupBottomNav(binding.bottomNav, R.id.nav_devices)
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = adapter
        binding.fabAddDevice.setOnClickListener { startActivity(Intent(this, AddDeviceActivity::class.java)) }
        binding.fabAddDevice.visibility = if (nrbApp.session.isAdmin) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (!::binding.isInitialized) return
        lifecycleScope.launch {
            val devices = nrbApp.database.deviceDao().getAll()
            adapter.submitList(devices)
            binding.tvEmpty.visibility = if (devices.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
