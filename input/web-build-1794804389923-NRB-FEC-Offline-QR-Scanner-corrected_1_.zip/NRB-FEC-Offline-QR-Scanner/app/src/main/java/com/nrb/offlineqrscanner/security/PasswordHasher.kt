package com.nrb.offlineqrscanner.security

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * PBKDF2-HMAC-SHA256 password hashing. Never stores or logs the plain password.
 * Stored form: "pbkdf2$<iterations>$<base64 salt>$<base64 hash>" - self-describing so the
 * iteration count can be raised later without breaking existing accounts.
 */
object PasswordHasher {
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256
    private const val SALT_BYTES = 16
    private const val PREFIX = "pbkdf2"

    fun hash(password: CharArray): String {
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val digest = derive(password, salt, ITERATIONS)
        return listOf(PREFIX, ITERATIONS, Base64.getEncoder().encodeToString(salt), Base64.getEncoder().encodeToString(digest))
            .joinToString("$")
    }

    fun verify(password: CharArray, stored: String): Boolean {
        val parts = stored.split("$")
        if (parts.size != 4 || parts[0] != PREFIX) return false
        val iterations = parts[1].toIntOrNull() ?: return false
        val salt = try { Base64.getDecoder().decode(parts[2]) } catch (e: Exception) { return false }
        val expected = try { Base64.getDecoder().decode(parts[3]) } catch (e: Exception) { return false }
        val actual = derive(password, salt, iterations)
        return constantTimeEquals(actual, expected)
    }

    private fun derive(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, KEY_LENGTH_BITS)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var diff = 0
        for (i in a.indices) diff = diff or (a[i].toInt() xor b[i].toInt())
        return diff == 0
    }
}
