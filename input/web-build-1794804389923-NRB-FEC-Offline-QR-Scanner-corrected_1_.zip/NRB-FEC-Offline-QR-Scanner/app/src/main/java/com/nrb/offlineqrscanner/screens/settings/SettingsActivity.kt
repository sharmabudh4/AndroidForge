package com.nrb.offlineqrscanner.screens.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.nrb.offlineqrscanner.R
import com.nrb.offlineqrscanner.databinding.ActivitySettingsBinding
import com.nrb.offlineqrscanner.nrbApp
import com.nrb.offlineqrscanner.screens.changepassword.ChangePasswordActivity
import com.nrb.offlineqrscanner.screens.login.LoginActivity
import com.nrb.offlineqrscanner.screens.users.ManageUsersActivity
import com.nrb.offlineqrscanner.security.PemUtils
import com.nrb.offlineqrscanner.service.ScanResultCode
import com.nrb.offlineqrscanner.utils.csvField
import com.nrb.offlineqrscanner.utils.formatDateTime
import com.nrb.offlineqrscanner.utils.readLimited
import com.nrb.offlineqrscanner.utils.requireLoggedInUserOrRedirect
import com.nrb.offlineqrscanner.utils.setupBottomNav
import com.nrb.offlineqrscanner.utils.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding

    private val keyPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::confirmKey) }
    private val csvSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> uri?.let(::exportHistory) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (requireLoggedInUserOrRedirect() == null) return
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupBottomNav(binding.bottomNav, R.id.nav_settings)

        binding.tvAppVersion.text = getString(R.string.app_version_fmt, packageManager.getPackageInfo(packageName, 0).versionName)

        binding.btnChangePassword.setOnClickListener { startActivity(Intent(this, ChangePasswordActivity::class.java)) }
        binding.btnManageUsers.setOnClickListener { startActivity(Intent(this, ManageUsersActivity::class.java)) }
        binding.btnInstallKey.setOnClickListener { keyPicker.launch(arrayOf("*/*")) }
        binding.btnExport.setOnClickListener { csvSaver.launch("nrb_fec_scan_history.csv") }
        binding.btnLogout.setOnClickListener { confirmLogout() }

        binding.switchAllowUnsigned.isChecked = nrbApp.settings.allowUnsigned
        binding.switchAllowUnsigned.setOnCheckedChangeListener { button, checked ->
            if (checked && !nrbApp.settings.allowUnsigned) {
                button.isChecked = false
                AlertDialog.Builder(this)
                    .setMessage(R.string.allow_unsigned_warning)
                    .setPositiveButton(R.string.enable) { _, _ -> nrbApp.settings.allowUnsigned = true; button.isChecked = true }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            } else if (!checked) {
                nrbApp.settings.allowUnsigned = false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!::binding.isInitialized) return // onCreate already redirected to Login
        val userId = requireLoggedInUserOrRedirect() ?: return
        binding.tvLoggedInAs.text = getString(R.string.logged_in_as_fmt, userId)
        binding.tvRole.setText(if (nrbApp.session.isAdmin) R.string.role_admin else R.string.role_user)
        binding.btnManageUsers.visibility = if (nrbApp.session.isAdmin) View.VISIBLE else View.GONE
        refresh()
    }

    private fun refresh() {
        lifecycleScope.launch {
            val deviceCount = nrbApp.database.deviceDao().countActive()
            val scanCount = nrbApp.database.scanHistoryDao().count()
            binding.tvDbSummary.text = getString(R.string.database_summary_fmt, deviceCount, scanCount)
        }
        val fp = nrbApp.keyStore.fingerprint()
        binding.tvKeyStatus.text = if (fp == null) getString(R.string.status_no_key)
        else getString(R.string.key_fingerprint_fmt, fp.chunked(8).joinToString(" "))
    }

    private fun confirmKey(uri: Uri) {
        val pem = try { contentResolver.openInputStream(uri)?.use { it.readLimited(16 * 1024) }?.toString(Charsets.UTF_8) } catch (e: Exception) { null }
        val key = try { pem?.let { nrbApp.keyStore.parse(it) } } catch (e: Exception) { null }
        if (pem == null || key == null) { toast(getString(R.string.key_invalid)); return }
        AlertDialog.Builder(this)
            .setTitle(R.string.install_trusted_key)
            .setMessage(getString(R.string.key_confirm_fmt, PemUtils.algorithmName(key), PemUtils.fingerprint(key).chunked(8).joinToString(" ")))
            .setPositiveButton(R.string.install) { _, _ -> nrbApp.keyStore.install(pem); refresh(); toast(getString(R.string.key_installed)) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun exportHistory(uri: Uri) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val rows = nrbApp.database.scanHistoryDao().getRecent(Int.MAX_VALUE)
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { w ->
                        w.write("time,device_id,device_name,scanned_by,result,reason\r\n")
                        for (r in rows) {
                            w.write(listOf(formatDateTime(r.scanTime), r.deviceId, r.deviceName, r.scannedByUserId, resultName(r.result), r.reason)
                                .joinToString(",") { csvField(it) })
                            w.write("\r\n")
                        }
                    } != null
                } catch (e: Exception) { false }
            }
            toast(getString(if (ok) R.string.export_done else R.string.export_failed))
        }
    }

    private fun resultName(code: Int) = when (code) {
        ScanResultCode.SUCCESS -> "granted"
        ScanResultCode.DUPLICATE -> "duplicate"
        ScanResultCode.EXPIRED -> "expired"
        ScanResultCode.UNKNOWN -> "unknown device"
        else -> "denied"
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this)
            .setMessage(R.string.confirm_logout)
            .setPositiveButton(R.string.logout) { _, _ ->
                nrbApp.session.clear()
                startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
