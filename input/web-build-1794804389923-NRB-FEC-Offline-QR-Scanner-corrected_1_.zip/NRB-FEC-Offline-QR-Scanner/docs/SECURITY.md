# NRB FEC Offline QR Scanner - Security Overview

## 1. Threat model and what this app protects against

- A QR code photographed, leaked, printed or redisplayed should not grant access by itself.
- The database should not be editable by anyone other than an admin using the app.
- Nothing should ever leave the phone (no network access at all).

## 2. Authentication (who is using the phone)

- Accounts are stored in Room as `userId` + a PBKDF2-HMAC-SHA256 password hash
  (`security/PasswordHasher.kt`: 120,000 iterations, random 16-byte salt per account,
  constant-time comparison on verify). Plain passwords are never stored or logged.
- The built-in `admin` / `admin123` account is forced to change its password on first login.
  Any account an admin creates is similarly forced to change its password on first login.
- Login state (`service/Session.kt`) lives in memory only - it is never written to disk, so the
  app always starts at the Login screen and "Logout" is absolute (no token to revoke, nothing to
  clear but memory).

## 3. QR authorization (who may access a device)

See `QR_FORMAT.md` for the full signature scheme. In short: a QR's signature proves it came from
the PC QR Generator and was not altered; it does **not** by itself prove who should be let in.
The QR's own `authorized_user` field is parsed but never used in the access decision - only the
Device record an admin registered on the phone, compared against whoever is currently logged in,
decides that (`ARCHITECTURE.md` section 3). This means a leaked or re-displayed QR code is
harmless on its own: whoever scans it still has to be logged in as the one User ID the phone's
admin authorized for that device.

- Fail-closed: no trusted key installed, or a present-but-invalid signature, always denies.
  The only override is the explicit, off-by-default "Allow unsigned QR codes (demo mode)"
  switch in Settings - intended for testing only, and it never overrides a signature that is
  present but wrong.
- `expires_at` / `issued_at` are enforced against the phone's clock.

## 4. Local database security

- The Room/SQLite database lives in the app-private directory (protected by Android's per-app
  sandbox and device encryption). It is **not** additionally encrypted by the app; on a rooted
  device, or with the screen lock disabled, it can be read. Consider SQLCipher if that is in
  your threat model.
- `android:allowBackup="false"`, plus `data_extraction_rules.xml` excluding cloud backup and
  device transfer, so the database and trusted key never leave the device.
- No data is transmitted: the app declares no `INTERNET` permission.
- Raw QR contents are never stored; scan history keeps only device ID, name, time, who scanned
  it, outcome and reason.

## 5. Trusted key

The trust anchor is one public key, installed via Settings (the admin confirms its SHA-256
fingerprint against the PC application) or bundled as `assets/trusted_public_key.pem`. Anyone
with unlocked physical access to the phone could replace it; protect the device (screen lock)
accordingly - this is also why the admin account forces a password change away from the default.

## 6. Mitigations summary

| Risk | Mitigation |
|---|---|
| Stolen/leaked/replayed QR code | Access still requires being logged in as the device's one authorized user; a QR grants nothing by itself |
| Forged or tampered QR code | ECDSA/RSA signature verification, fail-closed |
| Default admin credential left in place | Forced password change on first login |
| Password exposure | PBKDF2 hash + random salt, never plaintext, never logged |
| Database extraction | App sandbox + backups disabled (database itself not encrypted) |
| Data leaving the device | No `INTERNET` permission; nothing is ever transmitted |
| Malformed QR payload | Strict, non-reflective field-by-field parsing (`models/Payloads.kt`) |

## 7. First-time setup

There is no default or preset credential anywhere in the source. `FirstRunSetupActivity` is
shown in place of Login until the phone has zero accounts, and the admin sets their own User ID
and password there; `UserService.createFirstAdmin` refuses to run a second time once an account
exists, closing the setup window. From then on, only an existing admin can create more accounts.
