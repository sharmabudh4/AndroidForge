# NRB FEC Offline QR Scanner - Architecture Overview

## 1. Authorization model

There is no file-import workflow. Instead:

- **Accounts**: one built-in `admin` account is seeded on first launch (`admin` / `admin123`,
  must change password at first login). An admin can create further accounts, each either a
  standard user or another admin, from Settings > Manage Users.
- **Devices**: an admin registers each device on the phone itself (Devices > Add Device): Device
  ID, name, the single authorized User ID, and optional address/serial/documents.
- **Scanning**: the phone verifies the QR's signature, looks up the device by `device_id` in its
  own local database, and compares the **currently logged-in User ID** against that device's
  registered `authorizedUserId`. The QR's own `authorized_user` field is never consulted for
  this (see `QR_FORMAT.md` section 4).

```
Login (UserService, PasswordHasher)
        |
        v
HomeActivity --- ScanQRActivity --- AuthorizationManager --- AuthorizationEngine (pure, unit-tested)
        |                                 |
        v                                 v
RegisteredDevicesActivity          AppDatabase (Room): users, devices, scan_history
        |
        v
AddDeviceActivity (admin only)
```

## 2. Key components

- `security/` - `CanonicalJson`, `SignatureVerifier`, `PemUtils`, `PayloadAuthenticator`,
  `TrustedKeyStore`: QR signature verification, unchanged in spirit from the signing scheme in
  `QR_FORMAT.md`. `PasswordHasher`: PBKDF2-HMAC-SHA256 account password hashing.
- `models/Payloads.kt` - strict, hand-written JSON parsing for the QR payload (no reflection, so
  a missing field can never silently become null).
- `service/` - `AuthorizationEngine` (pure decision logic, see below), `AuthorizationManager`
  (parses + verifies + calls the engine + logs), `UserService`, `DeviceService`,
  `DuplicateScanManager`, `Session` (in-memory login state only - never persisted, so the app
  always starts at Login and logout is absolute).
- `database/` - Room: `UserEntity`, `DeviceEntity`, `ScanHistoryEntity`.
- `screens/` - one Activity per screen; `utils/BottomNav.kt` wires the shared bottom navigation
  bar (Home, Scanner, Devices, History, Settings) used on those five screens.

## 3. AuthorizationEngine.decide()

Pure function, fully unit-tested on the JVM (`RulesTest.kt`), independent of Room/Android:

1. QR expired (`expires_at` in the past) → deny.
2. QR dated too far in the future (clock skew guard) → deny.
3. Device not registered on this phone → deny ("unknown device").
4. Device deactivated → deny.
5. `device.authorizedUserId` (case-insensitive) != logged-in User ID → deny ("User ID does not
   match the authorized User ID").
6. Otherwise → grant.

## 4. What is intentionally not included

- No cloud login, no network calls of any kind (no `INTERNET` permission).
- No way to self-register an account; only an existing admin can create one.
- No per-permission access lists - a device is either accessible to its one authorized user or
  it is not.

## 5. Changes in this revision

- **No hardcoded default credential.** `NRBApp` no longer seeds an `admin`/`admin123` account.
  `SplashActivity` checks `UserService.hasAnyUsers()` and routes to `FirstRunSetupActivity`
  (admin chooses their own User ID and password) until an account exists, then to Login.
- **User management completed:** an admin can reset another account's password
  (`UserService.resetPassword`, forces a change at next login) and deactivate/reactivate an
  account (`UserService.setActive`), with two guards: an admin can never deactivate themselves,
  and the last remaining *active* admin can never be deactivated by anyone.
- **Device registration <-> QR generation integration:** `models/QrPayloadTemplate.kt` builds
  the exact unsigned JSON a registered device needs, `utils/QrCodeGenerator.kt` (ZXing) renders
  it as a QR bitmap, and `screens/deviceqr/DeviceQrExportActivity` (admin-only, reached from Add
  Device and Device Info) shows both so the admin can copy the JSON or scan the QR into the PC
  signer. This never produces a working authorization QR by itself - it carries no signature, so
  `AuthorizationManager` always rejects it on its own; it is a transport convenience only.
- **Business logic decoupled from Room/Android:** `UserService`, `DeviceService` and
  `AuthorizationManager` now depend only on the plain interfaces in `service/Models.kt`
  (`UserRepo`, `DeviceRepo`, `ScanAuditRepo`, `KeyStoreLike`, `SettingsLike`), with
  `database/dao/RoomRepoAdapters.kt` wiring those to Room. This is what makes it possible to run
  the actual production login/authorization code (not a reimplementation of its rules) in plain
  JVM unit tests - see `app/src/test/java/.../UserServiceTest.kt`, `DeviceServiceTest.kt`,
  `AuthorizationManagerTest.kt`.

## 6. Final correction pass

- **Session-null handling fixed everywhere, not just the Scanner.** `utils/SessionGuard.kt`
  adds `requireLoggedInUserOrRedirect()`, used at the top of every post-login screen's
  `onCreate`/`onResume` and in `ScanQRActivity.onQrDecoded`'s callback. A missing session (e.g.
  the process was killed and Android restores a screen directly, bypassing Home) now safely
  redirects to Login and resets in-flight state (the scanner's `busy` flag) instead of silently
  doing nothing or passing a null into a format string.
- **Admin-only screens enforce it themselves.** `requireAdminOrFinish()` is checked in
  `AddDeviceActivity`, `ManageUsersActivity`, `AddUserActivity` and `DeviceQrExportActivity` -
  not just relied upon from the calling screen hiding a button.
- **The trusted key is checked before the camera ever starts**, not only when a scan is
  authorized: `ScanQRActivity` shows a blocking "install the trusted key" message instead of
  opening the camera when none is installed and demo mode is off, and re-checks on `onResume`
  (covers coming back from Settings after installing one).
- **PayloadAuthenticator simplified to exactly the documented format**: the old `sha256`/
  `algorithm` handling (left over from the removed import-file workflow) is gone. It signs/
  verifies canonical JSON of the whole object minus only `signature` - no field is special-cased,
  so the PC signer and the phone can never silently disagree about which fields matter.
- **Device deactivation now has a UI** (`DeviceInfoActivity`, admin-only) - `DeviceService.
  setActive` existed but nothing called it from a screen before this pass.
