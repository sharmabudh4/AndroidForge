# NRB FEC Offline QR Scanner - QR Code Format Specification

## Version 1.0

## 1. Overview
This document specifies the QR code format used by the NRB FEC Offline QR Scanner Android application and the companion PC QR Generator application.

Authorization is **not** decided by anything the QR code carries about who is allowed to use the
device. It is decided by comparing the User ID currently logged into the phone against the
authorized User ID the phone's admin registered locally for that device (see
`ARCHITECTURE.md`). The QR code only needs to identify the device, and to prove - via a digital
signature - that it really came from the PC QR Generator and was not tampered with.

## 2. QR Code Data Format

```json
{
  "format": "NRB-FEC-QR-1.0",
  "version": 1,
  "device_id": "NRB-MACHINE-001",
  "device_name": "Point-of-Sale Terminal A",
  "authorized_user": "alice",
  "issued_at": 1704067200,
  "expires_at": 0,
  "signature": "base64_der_signature"
}
```

## 3. Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `format` | string | Yes | QR format identifier: `NRB-FEC-QR-1.0` |
| `version` | integer | Yes | QR data format version (1) |
| `device_id` | string | Yes | The device identifier. Must match the Device ID an admin registered on the phone (Devices > Add Device). 2-40 letters, numbers, `_` or `-` |
| `device_name` | string | Yes | Human-readable device name, shown before the phone looks the device up locally |
| `authorized_user` | string | No | **Informational only.** The Android app never trusts this value for the access decision - see section 4 |
| `issued_at` | integer | No | Unix timestamp (seconds) the QR was generated. Defaults to 0 (no check) |
| `expires_at` | integer | No | Unix timestamp (seconds) after which the QR is rejected. 0 means it never expires |
| `signature` | string | Yes (unless demo mode) | Base64 signature over the canonical JSON of every other field |

## 4. Why `authorized_user` is not trusted

A QR code is a static image: once printed or displayed, anyone can photograph or redisplay it.
If the app granted access to whoever the QR *claims* is authorized, a stolen or leaked QR would
grant access to anyone who scans it, permanently. Instead, the QR only needs to say *which
device* it is for; the authorization check is "is the person logged in on this phone right now
the person this phone's admin says may use this device" - a question the QR cannot answer and
is never asked to.

## 5. Signature and Security

- `signature` = Base64 of an **ECDSA P-256 / SHA-256** signature (DER encoded, as produced by OpenSSL, Python `cryptography`, Java `SHA256withECDSA`). RSA-2048 (`SHA256withRSA`) is also accepted if the installed trusted key is an RSA key.
- **Signed bytes** = canonical JSON of the QR object *without* its `signature` field: keys sorted ascending at every level, no whitespace (`separators=(",", ":")`), UTF-8, `ensure_ascii=False`, integers only (no floats). Python: `json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`. There is no other field the signature logic treats specially - the whole object (minus `signature`) is covered, so the PC signer and the phone can never disagree about which fields matter. `QrPayloadTemplateTest` and `SecurityCoreTest.anyFieldChangeInvalidatesSignature_wholeObjectIsCovered` assert this.
- `tools/nrb_sign.py` is the reference signer; `docs/examples/` contains a signed sample and its public key. Android's `models/QrPayloadTemplate.kt` builds the exact unsigned structure above for a registered device (reachable from Device Info or after Add Device, admin-only) so there is no manual retyping step that could introduce a mismatch.
- The trusted public key must be installed (Settings > Install Trusted Key) **before** scanning: `ScanQRActivity` checks this up front and blocks the camera with a clear message otherwise, rather than only discovering it after a wasted scan.
- The scanner is **fail-closed**: a QR without a valid signature, or any QR when no trusted key is installed, is denied. The only exception is the explicit *Allow unsigned QR codes (demo mode)* switch in Settings (off by default). A signature that is present but wrong is always rejected.
- `expires_at` (non-zero) is enforced; `issued_at` more than 5 minutes in the future is rejected. These checks rely on the phone's clock.
- A valid signature only proves the QR is genuine and unmodified - it is step one of two. Step two, done entirely on the phone against its own local database, is the actual access decision described in section 4.
